# -*- coding: utf-8 -*-
"""
Created on Sun May 17 09:16:45 2020

@author: AD1012081
"""

#from pandas import read_csv
import pandas as pd
import numpy as np
from matplotlib import pyplot
#from sklearn import preprocessing as pre
from sklearn.metrics import mean_squared_error
#from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split 
#import math
import time
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import LSTM
#%matplotlib inline
from matplotlib.pylab import rcParams
rcParams['figure.figsize'] = 15,6
#import statsmodels.api as sm
#from sklearn import metrics
#import random
#import csv

def preprocess_data(file_name) :
    df_series = pd.read_csv(file_name)
    df_series =df_series.dropna()
    df_series=df_series.reset_index(drop=True)
    df_series=df_series.iloc[:,3:11]
    print(df_series.describe())
    
    df_series = df_series.astype('float32')
    
    return df_series
#df_series = pd.read_csv('RA0038_Train_LSTM.csv')

def get_lstm_regressor(input_shape=(1,1), return_sequences=False, num_outputs=1):
    
    regressor = Sequential()
    #regressor.add(LSTM(32, input_shape=(look_back, 1)))
    regressor.add(LSTM(units=32, activation='relu', return_sequences=return_sequences, input_shape=input_shape))
    regressor.add(Dropout(0.3))
    #regressor.add(LSTM(units=64,activation='relu'))
    #regressor.add(Dropout(0.5))

    
    regressor.add(Dense(units=num_outputs))
        
    regressor.summary()
    
    return regressor

data = preprocess_data('RA0038_Train_LSTM.csv')

column_names=data.columns.values
print(column_names)

# normalize features
y1= data.iloc[:,7]
X1= data.iloc[:,0:7]

y1=np.array(y1)

X1=np.array(X1)

scaler_X = MinMaxScaler(feature_range=(0, 1))
X1 = scaler_X.fit_transform(X1)

scaler_Y = MinMaxScaler(feature_range=(0, 1))
y1 = scaler_Y.fit_transform(y1.reshape(-1,1))


X_train, X_test, y_train, y_test = train_test_split(X1, y1, test_size=0.2, random_state=7) 

#X_train = X1[0:350,:]
#X_test = X1[350:416,:]
print(X_train.shape)
print(X_test.shape)

#y_train = y1[:350]
#y_test = y1[350:416]
print(y_train.shape)
print(y_test.shape)

#X_train=np.array(X_train)
#y_train=np.array(y_train)
#X_test=np.array(X_test)
#y_test=np.array(y_test)

# reshape input to be 3D [samples, timesteps, features]
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))


print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

X_train.shape[2]

# Create LSTM model
regressor = get_lstm_regressor(input_shape=(X_train.shape[1], X_train.shape[2]), num_outputs=1 )


# Compile model
start = time.time()
regressor.compile(loss='mean_squared_error', optimizer='adam', metrics = ['mse'])
print('compilation time : ', time.time() - start)

# Check point and save model
from keras.callbacks import EarlyStopping
from keras.callbacks import ModelCheckpoint
import os
es_patience=2
es = EarlyStopping(monitor="val_loss", mode="min", 
                       verbose=1, patience=es_patience)


# Add model checkpointing to save the best model
ckpt_file_path = os.path.join("model", "temp.hdf5")
ckpt = ModelCheckpoint(ckpt_file_path, monitor="val_loss", mode="min", 
                       verbose=1, save_best_only=True)


# Fit model
#regressor.fit(X_train, y_train, epochs=250, batch_size=64, verbose=1,  callbacks=[es, ckpt])  
#history = regressor.fit(X_train, y_train, epochs=1000, batch_size=32, validation_data=(X_test, y_test), verbose=1, callbacks=[es, ckpt])
history=regressor.fit(X_train, y_train, epochs=1000, batch_size=1, validation_data=(X_test, y_test),verbose=1)
#regressor.fit(X_train, y_train, epochs=200, batch_size=32, verbose=1)

# plot history
pyplot.plot(history.history['loss'], label='train')
pyplot.plot(history.history['val_loss'], label='test')
pyplot.legend()
pyplot.show()    

# Predict model
trainPredict = regressor.predict(X_train)
testPredict = regressor.predict(X_test)

print(trainPredict.shape,testPredict.shape)
testPredict.shape[1]

trainScore = mean_squared_error(y_train,trainPredict)

print('Train Score: %.4f MSE' % (trainScore))
testScore = mean_squared_error(y_test,testPredict)
print('Test Score: %.4f MSE' % (testScore))

n_train=X_train.shape[0]

pyplot.plot(range(n_train), y_train, label="train")
pyplot.plot(range(n_train, len(y_test) + n_train), y_test, '-', label="test")
#pyplot.plot(range(n_train1), y_pred_train1, '--', label="prediction train")
pyplot.plot(range(n_train, len(y_test) + n_train), testPredict, '--',label="prediction test")
pyplot.legend(loc=(1.01, 0))
pyplot.show()

pyplot.title('Prediction quality: {:.4f} MSE'.format(testScore))
pyplot.plot(y_test.reshape(-1, 1), label='Observed', color='#006699')
pyplot.plot(testPredict.reshape(-1, 1), label='Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.show()


#original= series_scalled * svalue
# Compbine X_train, y_Train, trainPredict
# Combine, X_test, y_test, testPredict

xtrain = X_train.reshape(-1,X_train.shape[1])
ytrain = y_train.reshape(-1,1)
ptrain = trainPredict.reshape(-1,1)

# invers transform
xtrain = scaler_X.inverse_transform(xtrain)
ytrain = scaler_Y.inverse_transform(ytrain)
ptrain = scaler_Y.inverse_transform(ptrain)

df = pd.DataFrame(xtrain)
df1 = pd.DataFrame(ytrain)
df2 = pd.DataFrame(ptrain)

df_xy_train = pd.concat([df,df1,], axis=1)

df_train_all = pd.concat([df_xy_train,df2], axis=1)
df_train_all.dtypes
col_names_all = list(column_names)

col_names_all.append('PRD_OIL_RATE')

df_train_all.columns =col_names_all


xtest = X_test.reshape(-1,X_test.shape[1])
ytest = y_test.reshape(-1,1)
ptest = testPredict.reshape(-1,1)

# invers transform
xtest = scaler_X.inverse_transform(xtest)
ytest = scaler_Y.inverse_transform(ytest)
ptest = scaler_Y.inverse_transform(ptest)

df3 = pd.DataFrame(xtest)
df4 = pd.DataFrame(ytest)
df5 = pd.DataFrame(ptest)

df_xy_test = pd.concat([df3,df4,], axis=1)

df_test_all = pd.concat([df_xy_test,df5], axis=1)
df_test_all.dtypes
df_test_all.columns =col_names_all


# Prepare data for CSV
df_train_all.to_csv('df_train_all.csv', encoding='utf-8')
df_test_all.to_csv('df_test_all.csv', encoding='utf-8')

# Predict values based on new dataset

# Data Preparation
v_test = pd.read_csv("RA0038_Test_LSTM.csv")
#v_test['Production_Date']=pd.to_datetime(v_test['Production_Date'])
#v_test = v_test[v_test['Production_Date']<"9/17/2019 0:00"]
v_test_selected= v_test.iloc[:,2:9]
v_test_selected = scaler_X.fit_transform(v_test_selected)
v_test_selected=np.array(v_test_selected)
v_test_selected = np.reshape(v_test_selected, (v_test_selected.shape[0], v_test_selected.shape[1], 1))

# Predict 
vPredict = regressor.predict(v_test_selected)


vPredict = vPredict.reshape(-1,1)
vPredict = scaler_Y.inverse_transform(vPredict)
df6 = pd.DataFrame(vPredict)

v_final_df = pd.concat([v_test,df6], axis=1)
v_names_all = list(v_test.columns.values)
v_names_all.append('PRD_OIL_RATE')
v_final_df.columns = v_names_all
v_final_df=v_final_df.iloc[:,[2,3,4,5,6,7,8,9,15]]
v_final_df.to_csv('df_v_all.csv', encoding='utf-8')


pyplot.title('Prediction quality ')
pyplot.plot(v_final_df.iloc[:,7], label='Observed', color='#006699')
pyplot.plot(v_final_df.iloc[:,8], label='Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.show()

from math import sqrt
rmse = sqrt(mean_squared_error(v_final_df.iloc[:,8], v_final_df.iloc[:,9]))
print('Test RMSE: %.3f' % rmse)
