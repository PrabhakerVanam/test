# -*- coding: utf-8 -*-
"""
Created on Sun May 17 09:16:45 2020

@author: AD1012081
"""

#from pandas import read_csv
import pandas as pd
import numpy as np
from matplotlib import pyplot
#from sklearn import preprocessing as pre
from sklearn.metrics import mean_squared_error
#from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split 
#import math
import time
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import LSTM

from math import sqrt

#from keras.models import load_model

#%matplotlib inline
from matplotlib.pylab import rcParams
rcParams['figure.figsize'] = 15,6
#import statsmodels.api as sm
#from sklearn import metrics
#import random
#import csv

def preprocess_data(file_name) :
    df_series = pd.read_csv(file_name)
    df_series =df_series.dropna()
    df_series=df_series.reset_index(drop=True)
    df_series=df_series.iloc[:,3:13]
    print(df_series.describe())
    
    df_series = df_series.astype('float32')
    
    return df_series
#df_series = pd.read_csv('RA0038_Train_LSTM.csv')

def get_lstm_regressor_oil(input_shape=(1,1), return_sequences=False, num_outputs=1):
    
    regressor = Sequential()
    #regressor.add(LSTM(32, input_shape=(look_back, 1)))
    regressor.add(LSTM(units=32, activation='relu', return_sequences=return_sequences, input_shape=input_shape))
    regressor.add(Dropout(0.3))
    #regressor.add(LSTM(units=64,activation='relu'))
    #regressor.add(Dropout(0.5))

    regressor.add(Dense(units=num_outputs))
        
    regressor.summary()
    
    return regressor

def get_lstm_regressor_liquid(input_shape=(1,1), return_sequences=False, num_outputs=1):
    
    regressor = Sequential()
    #regressor.add(LSTM(32, input_shape=(look_back, 1)))
    regressor.add(LSTM(units=128, activation='relu', return_sequences=return_sequences, input_shape=input_shape))
    regressor.add(Dropout(0.3))
    #regressor.add(LSTM(units=64,activation='relu'))
    #regressor.add(Dropout(0.5))
    
    regressor.add(Dense(units=num_outputs))
        
    regressor.summary()
    
    return regressor

def get_lstm_regressor_gas(input_shape=(1,1), return_sequences=False, num_outputs=1):
    
    regressor = Sequential()
    #regressor.add(LSTM(32, input_shape=(look_back, 1)))
    regressor.add(LSTM(units=64, activation='relu', return_sequences=return_sequences, input_shape=input_shape))
    regressor.add(Dropout(0.3))
    #regressor.add(LSTM(units=64,activation='relu'))
    #regressor.add(Dropout(0.5))
    
    regressor.add(Dense(units=num_outputs))
        
    regressor.summary()
    
    return regressor

data = preprocess_data('RA0038_Train_LSTM.csv')

column_names=data.columns.values
print(column_names)

# normalize features
X1= data.iloc[:,0:7]

Y= data.iloc[:,7:10]

y1= data.iloc[:,7]
y2= data.iloc[:,8]
y3= data.iloc[:,9]

y1=np.array(y1)
y2=np.array(y2)
y3=np.array(y3)

X1=np.array(X1)
Y=np.array(Y)

scaler_X = MinMaxScaler(feature_range=(0, 1))
X1 = scaler_X.fit_transform(X1)

scaler_Y1 = MinMaxScaler(feature_range=(0, 1))
y1 = scaler_Y1.fit_transform(y1.reshape(-1,1))

scaler_Y2 = MinMaxScaler(feature_range=(0, 1))
y2 = scaler_Y2.fit_transform(y2.reshape(-1,1))

scaler_Y3 = MinMaxScaler(feature_range=(0, 1))
y3 = scaler_Y3.fit_transform(y3.reshape(-1,1))

scaler_Y = MinMaxScaler(feature_range=(0, 1))
Y = scaler_Y.fit_transform(Y)


X_train, X_test, Y_train, Y_test = train_test_split(X1, Y, test_size=0.2, random_state=123)

y1_train=Y_train[:,0]
y1_train= y1_train.reshape(-1,1)

y2_train=Y_train[:,1]
y2_train= y2_train.reshape(-1,1)

y3_train=Y_train[:,2]
y3_train= y3_train.reshape(-1,1)

y1_test=Y_test[:,0]
y1_test= y1_test.reshape(-1,1)

y2_test=Y_test[:,1]
y2_test= y2_test.reshape(-1,1)

y3_test=Y_test[:,2]
y3_test= y3_test.reshape(-1,1)


# reshape input to be 3D [samples, timesteps, features]
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))

# Create LSTM model
regressor_oil = get_lstm_regressor_oil(input_shape=(X_train.shape[1], X_train.shape[2]), num_outputs=1 )
regressor_liquid = get_lstm_regressor_liquid(input_shape=(X_train.shape[1], X_train.shape[2]), num_outputs=1 )
regressor_gas = get_lstm_regressor_gas(input_shape=(X_train.shape[1], X_train.shape[2]), num_outputs=1 )

# Compile model
start = time.time()
regressor_oil.compile(loss='mean_squared_error', optimizer='adam', metrics = ['mse'])
regressor_liquid.compile(loss='mean_squared_error', optimizer='adam', metrics = ['mse'])
regressor_gas.compile(loss='mean_squared_error', optimizer='adam', metrics = ['mse'])
print('compilation time : ', time.time() - start)

# Check point and save model
from keras.callbacks import EarlyStopping
from keras.callbacks import ModelCheckpoint
import os
es_patience=2
es = EarlyStopping(monitor="val_loss", mode="min", 
                       verbose=1, patience=es_patience)

# Add model checkpointing to save the best model
ckpt_file_path = os.path.join("model", "temp.hdf5")
ckpt = ModelCheckpoint(ckpt_file_path, monitor="val_loss", mode="min", 
                       verbose=1, save_best_only=True)

# Fit model
#regressor.fit(X_train, y_train, epochs=250, batch_size=64, verbose=1,  callbacks=[es, ckpt])  
#history = regressor.fit(X_train, y_train, epochs=1000, batch_size=32, validation_data=(X_test, y_test), verbose=1, callbacks=[es, ckpt])
history1=regressor_oil.fit(X_train, y1_train, epochs=1000, batch_size=1, validation_data=(X_test, y1_test),verbose=0)
history2=regressor_liquid.fit(X_train, y2_train, epochs=500, batch_size=1, validation_data=(X_test, y2_test),verbose=0)
history3=regressor_gas.fit(X_train, y3_train, epochs=500, batch_size=1, validation_data=(X_test, y3_test),verbose=0)
# plot history
pyplot.plot(history1.history['loss'], label='train')
pyplot.plot(history1.history['val_loss'], label='test')
pyplot.legend()
pyplot.show()

pyplot.plot(history2.history['loss'], label='train')
pyplot.plot(history2.history['val_loss'], label='test')
pyplot.legend()
pyplot.show()

pyplot.plot(history3.history['loss'], label='train')
pyplot.plot(history3.history['val_loss'], label='test')
pyplot.legend()
pyplot.show() 

# Predict model (Oil)
trainPredict_oil = regressor_oil.predict(X_train)
testPredict_oil = regressor_oil.predict(X_test)

trainPredict_liquid = regressor_liquid.predict(X_train)
testPredict_liquid = regressor_liquid.predict(X_test)

trainPredict_gas = regressor_gas.predict(X_train)
testPredict_gas = regressor_gas.predict(X_test)

print("---------------------------------------------------------")
trainScore_oil = mean_squared_error(y1_train, trainPredict_oil)
print('Oil Train Score: %.4f MSE' % (trainScore_oil))
testScore_oil = mean_squared_error(y1_test,testPredict_oil)
print('Oil Test Score: %.4f MSE' % (testScore_oil))
print("---------------------------------------------------------")
trainScore_liquid = mean_squared_error(y2_train, trainPredict_liquid)
print('Liquid Train Score: %.4f MSE' % (trainScore_liquid))
testScore_liquid = mean_squared_error(y2_test,testPredict_liquid)
print('Liquid Test Score: %.4f MSE' % (testScore_liquid))
print("---------------------------------------------------------")
trainScore_gas = mean_squared_error(y3_train, trainPredict_gas)
print('GAS Train Score: %.4f MSE' % (trainScore_gas))
testScore_gas = mean_squared_error(y3_test,testPredict_gas)
print('GAS Test Score: %.4f MSE' % (testScore_gas))
print("---------------------------------------------------------")

n_train=X_train.shape[0]

# Plot on Oil Train Data
pyplot.plot(range(n_train), y1_train, label="train")
pyplot.plot(range(n_train, len(y1_test) + n_train), y1_test, '-', label="test")
pyplot.plot(range(n_train, len(y1_test) + n_train), testPredict_oil, '--',label="Oil Prediction test")
pyplot.legend(loc=(1.01, 0))
pyplot.savefig("Oil Prediction quality on Train & Test.png")
pyplot.show()

# Plot on Oil Test Data
pyplot.title('Oil Prediction quality: {:.4f} MSE'.format(testScore_oil))
pyplot.plot(y1_test.reshape(-1, 1), label='Oil Observed', color='#006699')
pyplot.plot(testPredict_oil.reshape(-1, 1), label='Oil Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.savefig("Oil Prediction quality on Test.png")
pyplot.show()


# Plot on Liquid Train Data
pyplot.plot(range(n_train), y2_train, label="train")
pyplot.plot(range(n_train, len(y2_test) + n_train), y2_test, '-', label="test")
pyplot.plot(range(n_train, len(y2_test) + n_train), testPredict_liquid, '--',label="Liquid Prediction test")
pyplot.legend(loc=(1.01, 0))
pyplot.savefig("Liquid Prediction quality on Train & Test.png")
pyplot.show()


# Plot on Liquid Test Data
pyplot.title('Liquid Prediction quality: {:.4f} MSE'.format(testScore_liquid))
pyplot.plot(y2_test.reshape(-1, 1), label='Liquid Observed', color='#006699')
pyplot.plot(testPredict_liquid.reshape(-1, 1), label='Liquid Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.savefig("Liquid Prediction quality on Test.png")
pyplot.show()


# Plot on GAS Train Data
pyplot.plot(range(n_train), y3_train, label="train")
pyplot.plot(range(n_train, len(y3_test) + n_train), y3_test, '-', label="test")
pyplot.plot(range(n_train, len(y3_test) + n_train), testPredict_gas, '--',label="GAS Prediction test")
pyplot.legend(loc=(1.01, 0))
pyplot.savefig("GAS Prediction quality on Train & Test.png")
pyplot.show()


# Plot on GAS Test Data
pyplot.title('GAS Prediction quality: {:.4f} MSE'.format(testScore_gas))
pyplot.plot(y3_test.reshape(-1, 1), label='GAS Observed', color='#006699')
pyplot.plot(testPredict_gas.reshape(-1, 1), label='GAS Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.savefig("GAS Prediction quality on Test.png")
pyplot.show()


#original= series_scalled * svalue
# Compbine X_train, y_Train, trainPredict
# Combine, X_test, y_test, testPredict

xtrain = X_train.reshape(-1,X_train.shape[1])
y1train = y1_train.reshape(-1,1)
ptrain_oil = trainPredict_oil.reshape(-1,1)

y2train = y2_train.reshape(-1,1)
ptrain_liquid = trainPredict_liquid.reshape(-1,1)

y3train = y3_train.reshape(-1,1)
ptrain_gas = trainPredict_gas.reshape(-1,1)

# invers transform
xtrain = scaler_X.inverse_transform(xtrain)
y1train = scaler_Y1.inverse_transform(y1train)
ptrain_oil = scaler_Y1.inverse_transform(ptrain_oil)

y2train = scaler_Y2.inverse_transform(y2train)
ptrain_liquid = scaler_Y2.inverse_transform(ptrain_liquid)

y3train = scaler_Y3.inverse_transform(y3train)
ptrain_gas = scaler_Y3.inverse_transform(ptrain_gas)

df = pd.DataFrame(xtrain)
df1 = pd.DataFrame(y1train)
df2 = pd.DataFrame(ptrain_oil)

df3 = pd.DataFrame(y2train)
df4 = pd.DataFrame(ptrain_liquid)

df5 = pd.DataFrame(y3train)
df6 = pd.DataFrame(ptrain_gas)

df_xy_train = pd.concat([df,df1,df2,df3,df4,df5,df6], axis=1)

#df_train_all = pd.concat([df_xy_train,df2], axis=1)
#df_train_all.dtypes
col_names_all = ['CHOKE_SIZE', 'TUBING_PRESSURE', 'TUBING_TEMPERATURE',
       'FLOWLINE_PRESSURE', 'FLOWLINE_TEMPERATURE', 'Choke_DP',
       'GAS_LIFT_VOLUME', 'OIL_RATE', 'PRD_OIL_RATE', 'LIQUID_RATE', 'PRD_LIQUID_RATE', 'GAS_RATE', 'PRD_GAS_RATE']

df_xy_train.columns =col_names_all

xtest = X_test.reshape(-1,X_test.shape[1])
y1test = y1_test.reshape(-1,1)
ptest_oil = testPredict_oil.reshape(-1,1)

y2test = y2_test.reshape(-1,1)
ptest_liquid = testPredict_liquid.reshape(-1,1)

y3test = y3_test.reshape(-1,1)
ptest_gas = testPredict_gas.reshape(-1,1)

# invers transform
xtest = scaler_X.inverse_transform(xtest)
y1test = scaler_Y1.inverse_transform(y1test)
ptest_oil = scaler_Y1.inverse_transform(ptest_oil)

y2test = scaler_Y2.inverse_transform(y2test)
ptest_liquid = scaler_Y2.inverse_transform(ptest_liquid)

y3test = scaler_Y3.inverse_transform(y1test)
ptest_gas = scaler_Y3.inverse_transform(ptest_gas)

df_tx = pd.DataFrame(xtest)
df_t1 = pd.DataFrame(y1test)
df_t2 = pd.DataFrame(ptest_oil)

df_t3 = pd.DataFrame(y2test)
df_t4 = pd.DataFrame(ptest_liquid)

df_t5 = pd.DataFrame(y3test)
df_t6 = pd.DataFrame(ptest_gas)

df_xy_test = pd.concat([df_tx,df_t1,df_t2,df_t3,df_t4,df_t5,df_t6], axis=1)

df_xy_test.columns =col_names_all

# Prepare data for CSV
df_xy_train.to_csv('df_train_all.csv', encoding='utf-8')
df_xy_test.to_csv('df_test_all.csv', encoding='utf-8')

# Predict values based on new dataset

# Data Preparation
v_test = pd.read_csv("RA0038_Test_LSTM.csv")
#v_test['Production_Date']=pd.to_datetime(v_test['Production_Date'])
#v_test = v_test[v_test['Production_Date']<"9/17/2019 0:00"]
v_test_selected= v_test.iloc[:,2:9]
v_test_selected = scaler_X.fit_transform(v_test_selected)
v_test_selected=np.array(v_test_selected)
v_test_selected = np.reshape(v_test_selected, (v_test_selected.shape[0], v_test_selected.shape[1], 1))

# Predict 
vPredict_oil = regressor_oil.predict(v_test_selected)
vPredict_liquid = regressor_liquid.predict(v_test_selected)
vPredict_gas = regressor_gas.predict(v_test_selected)


vPredict_oil = vPredict_oil.reshape(-1,1)
vPredict_oil = scaler_Y1.inverse_transform(vPredict_oil)
df_v_oil = pd.DataFrame(vPredict_oil)

vPredict_liquid = vPredict_liquid.reshape(-1,1)
vPredict_liquid = scaler_Y2.inverse_transform(vPredict_liquid)
df_v_liquid = pd.DataFrame(vPredict_liquid)

vPredict_gas = vPredict_gas.reshape(-1,1)
vPredict_gas = scaler_Y3.inverse_transform(vPredict_gas)
df_v_gas = pd.DataFrame(vPredict_gas)

v_final_df = pd.concat([v_test.iloc[:,2:10],df_v_oil, v_test.iloc[:,10],df_v_liquid,v_test.iloc[:,11], df_v_gas], axis=1)
v_final_df.columns = col_names_all

v_final_df.to_csv('df_v_all.csv', encoding='utf-8')

print("---------------------------------------------------------")
pyplot.title('Oil Prediction quality ')
pyplot.plot(v_final_df.iloc[:,7], label='Oil Observed', color='#006699')
pyplot.plot(v_final_df.iloc[:,8], label='Oil Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.savefig("Oil Prediction quality on validation.png")
pyplot.show()

rmse_oil = sqrt(mean_squared_error(v_final_df.iloc[:,7], v_final_df.iloc[:,8]))
print('Oil Test RMSE: %.3f' % rmse_oil)
print("---------------------------------------------------------")
pyplot.title('Liquid Prediction quality ')
pyplot.plot(v_final_df.iloc[:,9], label='Liquid Observed', color='#006699')
pyplot.plot(v_final_df.iloc[:,10], label='Liquid Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.savefig("Liquid Prediction quality on validation.png")
pyplot.show()

rmse_liquid = sqrt(mean_squared_error(v_final_df.iloc[:,9], v_final_df.iloc[:,10]))
print('Liquid Test RMSE: %.3f' % rmse_liquid)
print("---------------------------------------------------------")
pyplot.title('GAS Prediction quality ')
pyplot.plot(v_final_df.iloc[:,11], label='GAS Observed', color='#006699')
pyplot.plot(v_final_df.iloc[:,12], label='GAS Prediction', color='#ff0066')
pyplot.legend(loc='best');
pyplot.savefig("GAS Prediction quality on validation.png")
pyplot.show()

rmse_gas = sqrt(mean_squared_error(v_final_df.iloc[:,11], v_final_df.iloc[:,12]))
print('GAS Test RMSE: %.3f' % rmse_gas)
print("---------------------------------------------------------")

# Run Below code only for TEST OR Validate new data without training ( load model from disk)

oil_model_file_path = os.path.join("model", "ra38_oil_model.hdf5")
liquid_model_file_path = os.path.join("model", "ra38_liquid_model.hdf5")
gas_model_file_path = os.path.join("model", "ra38_gas_model.hdf5")
regressor_oil.save(oil_model_file_path)
regressor_liquid.save(liquid_model_file_path)
regressor_gas.save(gas_model_file_path)
#model = load_model(oil_model_file_path)



