# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 12:53:04 2020

This Python script provides an entry-point for building machine learning
prediction models for BAKER Cement Bond Logs. The methods extracts dlis files,
develop machine learning models by considering several combinations of the
ATC channels, and develop predictive models for
Cement Bond Quality (CQF). This script can be executed from Spyder IDE, or
from a Windows command prompt as > python entry_dlis_baker.py

Note:
    Training and predictions should run separately. Please don't provide \
    both training and prediction flags as True at the same time.

Usage:
    Following commands assume that dlis/data is provided for BAKER,
    and we are generating predictions for the Cement quality.

    Execute this file from command-line using following commands:

        * Training

        python entry_dlis_baker.py -dlis XXX.dlis -input_csv Well_Locations.csv \
        -tr True -pr False -df False -dft False

@author: Prabhaker Reddy Vanam
"""
import base64
import logging
import os
import tempfile

import dlisio
import numpy as np
import pandas as pd
import streamlit as st

from aon.dlis.io import data_reader as reader
from aon.dlis.io import io_constants as io_const
from aon.dlis.io import plot_cement_bond_log as plot_cbl
from aon.dlis.model import cbl_model_helper as ml_helper
from aon.dlis.model import model_constants as ml_const
from aon.dlis.preprocess import data_preprocessor as pre_process

st.set_option('deprecation.showfileUploaderEncoding', False)
# st.set_option('server.maxUploadSize', 500) set this as comandline param --server.maxUploadSize 500

np.random.seed(ml_const.RANDOM_SEED)

# Set encodings for dlisio
dlisio.set_encodings(['latin1'])

training_data_dir = ""

logical_file_info_dict = {}

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

STYLE = """
<style>
img {
    max-width: 100%;
}
</style>
"""
FILE_TYPES = ["dlis"]


def _max_width_():
    max_width_str = f"max-width: 2000px;"
    st.markdown(
        f"""
    <style>
    .reportview-container .main .block-container{{
        {max_width_str}
    }}
    </style>    
    """,
        unsafe_allow_html=True,
    )


def write_to_temp_file(uploaded_file, file_type):
    temp_file = tempfile.mkstemp(suffix=f'.{file_type}')
    temp_file_path = temp_file[1]
    try:
        with open(temp_file[1], 'w+b') as out:  ## Open temporary file as bytes

            out.write(uploaded_file.read())

        st.write(f"Temp File path : {temp_file_path}")
    except Exception as e:
        st.write(f"Error: {e}")

    return temp_file_path


def main():
    """Run this function to display the Streamlit app"""

    # st.info(__doc__)
    # set maxwidth
    _max_width_()
    st.markdown(STYLE, unsafe_allow_html=True)

    st.title('Cement Bond Evaluation by Machine Learning Models')

    training_data_dir = os.path.join(io_const.BASE_DATA_DIR, io_const.TRAINING_DATA_DIR)
    print(training_data_dir)

    file = st.file_uploader("Select dlis file from your local PC :", type=FILE_TYPES)
    show_file = st.empty()

    if not file:
        show_file.info("Please upload a file of type: " + ", ".join(FILE_TYPES))
        return

    if file is not None:
        temp_file = write_to_temp_file(file, 'dlis')
        extract_dlis(temp_file)


def extract_dlis(source_dlis_file):
    my_placeholder = st.empty()

    duplicate_channel_list = []
    df_zone_info_db = None
    source_dlis_file = source_dlis_file.replace('/', '\\\\')

    dlis_summary = pd.DataFrame(columns=io_const.SUMMARY_DF_COLUMN_LIST)

    with dlisio.load(source_dlis_file) as files:

        print(files.describe())

        is_casing_plotted = False
        zone_info_extracted_from_db = False
        files_count = len(files)
        print("_COUNT_START_", files_count, "_COUNT_END_")
        m = 0
        for lfile in files:
            m = m + 1

            problematic_list = lfile.problematic

            # check for duplicate channels to skip by the code
            if len(problematic_list) > 0:

                print("Its Problematic files : {}".format(problematic_list))

                prob_channel_list = [x[0] for x in problematic_list]

                for dup_chn in prob_channel_list:

                    prob_channel_name = dup_chn.name
                    # print(prob_channel_name)

                    if prob_channel_name not in duplicate_channel_list:
                        duplicate_channel_list.append(prob_channel_name)

            # Validate columns
            lfile_channels: list = reader.get_all_channel_names_of_logical_file(lfile, duplicate_channel_list)

            # 1. Validate required channels
            channel_missing = False

            for (ch, ch_i) in zip(io_const.SBT_CHANNEL_SET, io_const.SBT_CHANNEL_SET_I):

                if ch not in lfile_channels and ch_i not in lfile_channels:
                    channel_missing = True

                if channel_missing:
                    break
            fig_list = []
            casing_fig = None
            if not channel_missing:

                parameter_table = reader.summarize(lfile.parameters, name='Name', long_name='Long name',
                                                   values='Value(s)', zones='Zone(s)')

                zone_table = reader.summarize(lfile.zones, name='Name', minimum='Minimum', maximum='Maximum')

                # parameter_table['Value(s)'] = parameter_table['Value(s)'].apply(lambda x: str(x).strip('[]'))
                parameter_table['Zone(s)'] = parameter_table['Zone(s)'].apply(lambda x: str(x).strip('[]'))

                # Hide parameters containing names; see the privacy note in the Introduction. Comment out these lines
                # to show them.
                exclude_mask = ~parameter_table['Name'].isin(['RR1', 'WITN', 'ENGI'])

                parameter_table = parameter_table[exclude_mask]

                well_name = 'NOT EXISTS'
                exists = 'WN' in parameter_table["Name"].values
                if exists:
                    well_name = parameter_table[parameter_table["Name"] == "WN"]['Value(s)'].values[0]

                company_name = 'NOT EXISTS'
                exists = 'CN' in parameter_table["Name"].values
                if exists:
                    company_name = parameter_table[parameter_table["Name"] == "CN"]['Value(s)'].values[0]

                producer_name = 'NOT EXISTS'
                exists = 'LCNM' in parameter_table["Name"].values
                if exists:
                    producer_name = parameter_table[parameter_table["Name"] == "LCNM"]['Value(s)'].values[0]

                set_name = 'NOT EXISTS'
                exists = 'SET' in parameter_table["Name"].values
                if exists:
                    set_name = parameter_table[parameter_table["Name"] == "SET"]['Value(s)'].values[0]

                field_name = 'NOT EXISTS'
                exists = 'FN' in parameter_table["Name"].values
                if exists:
                    field_name = parameter_table[parameter_table["Name"] == "FN"]['Value(s)'].values[0]

                # extract Casing data from header (Params and Zones)
                cs_table = parameter_table[parameter_table['Name'].str.startswith("CS")]
                cs_table['Value(s)'] = cs_table['Value(s)'].apply(lambda x: str(x).strip('[]'))
                cs_table['Zone(s)'] = cs_table['Zone(s)'].apply(lambda x: str(x).strip('Zone()'))

                cs_table = cs_table.merge(zone_table, left_on='Zone(s)', right_on='Name')
                # print('cs_table' + cs_table)
                # print("cs_table.shape ", cs_table.shape)

                # well_name = str(well_name).strip('[]')
                company_name = str(company_name).strip('[]')
                set_name = str(set_name).strip('[]')
                set_name = str(set_name).strip('\'\'')
                producer_name = str(producer_name).strip('[]')

                well_name = pre_process.format_well_name(well_name)
                my_placeholder.text(well_name)

                if not zone_info_extracted_from_db:
                    df_zone_info_db = reader.load_zone_info_from_exprisload_zone_info_from_expris(well_name)
                    zone_info_extracted_from_db = True

                if not is_casing_plotted:
                    casing9_min, casing9_max, casing7_min, casing7_max, max_depth, min_depth, casing_df = pre_process.get_casing_plot_data(
                        cs_table)

                    casing_plot_path = "{}\\{}_{}_{}".format(io_const.OUTPUT_DATA_DIR, well_name, company_name,
                                                             io_const.CASING_PLOT_FILE_SUFFIX)
                    # casing_df = reader.prepare_casing_plot_data(casing18_min, casing18_max, casing13_min,
                    # casing13_max, casing9_min, casing9_max, casing7_min, casing7_max)
                    # casing_fig = plot_cbl.plot_well_casing(casing_df.values, min_depth, max_depth, casing_plot_path)

                    is_casing_plotted = True

                # append casing fig to the list
                fig_list.append(casing_fig)

                channel_table = reader.summarize(lfile.channels, name='Name', long_name='Long name', units='Units',
                                                 dimension='Dimension', frame='Frame')
                channel_table.sort_values('Name')

                tool_table = reader.summarize(lfile.tools, name='Name', generic_name='Generic name',
                                              trademark_name='Trademark name', description='Description')
                tool_table.sort_values('Name')
                ###print(tool_table)

                ###print(list(io_const.HEADER_PARAM_LIST))
                header_info = parameter_table.loc[parameter_table['Name'].isin(list(io_const.HEADER_PARAM_LIST))]. \
                    drop(columns='Zone(s)', axis=1)
                ###print(header_info)

                problematic_list = lfile.problematic

                if len(problematic_list) > 0:

                    ###print("Its Problematic files : {}".format(problematic_list))
                    prob_channel_list = [x[0] for x in problematic_list]

                    for dup_chn in prob_channel_list:
                        prob_channel_name = dup_chn.name
                        # print(prob_channel_name)

                        if prob_channel_name not in duplicate_channel_list:
                            duplicate_channel_list.append(prob_channel_name)

                origin, *origin_tail = lfile.origins

                if len(origin_tail):
                    logging.warning('Logical file contains multiple origins')

                for origin in lfile.origins:
                    origin.describe()

                    file_number = origin.file_nr
                    producer_name = origin.producer_name
                    if not well_name:
                        well_name = origin.well_name
                    # copy_no = origin.copynumber
                    # org_no = origin.origin
                    field_name = origin.field_name
                    # namespace_name = origin.namespace_name

                for frm in lfile.frames:

                    file_name_pattern = "{}_{}_{}_{}_{}".format(field_name, well_name, producer_name, set_name,
                                                                frm.name)

                    st.header("Processing logical file : " + file_name_pattern)

                    index_channel = next(ch for ch in frm.channels if ch.name == frm.index)

                    try:
                        frm_curves = frm.curves(strict=False)
                        curve_index = reader.index_of(frm)

                        ###print(frm_curves.shape)
                    except Exception as e:
                        logging.error("ERROR in reading curve data.... : {}".format(e))

                    try:
                        my_placeholder.text("Extracting curve data from frame")

                        selected_curves_names = reader.get_channel_names(frm, duplicate_channel_list)
                        # print(selected_curves_names)
                        # print(frm_curves[frm.index])

                        selected_curves_data = frm_curves[selected_curves_names]

                        # print("*********************************************************")
                        df_curves = pd.DataFrame(selected_curves_data, index=frm_curves[frm.index])
                        # print("Index Name : " + frm.index)

                        min_depth = frm_curves[io_const.TDEP_COLUMN].min()
                        max_depth = frm_curves[io_const.TDEP_COLUMN].max()
                        unit_depth = frm_curves[io_const.TDEP_COLUMN][1] - frm_curves[io_const.TDEP_COLUMN][0]
                        depth_range = (min_depth, max_depth)  # df_curves.shape

                        cemo_wave_channel_names: list = reader.get_wave_channel_name(frm, duplicate_channel_list)
                        # print(cemo_wave_channel_names)
                        df_full_data = df_curves.copy()
                        if len(cemo_wave_channel_names) > 1:

                            for channel_name in cemo_wave_channel_names:
                                ###print("Processing : {}".format(channel_name))

                                # cs_wave_data = frm_curves[channel_name]

                                df_wave_data = pd.DataFrame(frm_curves[channel_name], index=frm_curves[frm.index])
                                col_name_prefix = 'W_'
                                if channel_name.startswith('C'):
                                    col_name_prefix = 'C_'
                                df_wave_data.columns = [col_name_prefix + str(col) for col in df_wave_data.columns]

                                df_wave_data[io_const.TDEP_COLUMN] = df_wave_data.index
                                # df_wave_data.reset_index(drop=True)

                                ###print(df_wave_data.head())

                                file_name_sufix = io_const.CEMO_DATA_CSV_SUFFIX
                                if channel_name.lower().startswith('wave'):
                                    file_name_sufix = io_const.WAVE_DATA_CSV_SUFFIX

                                # save wave data
                                cemo_wave_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, file_name_sufix)
                                ###print("Saving wave/cemo data to : {} ".format(cemo_wave_file_name))

                                with open(cemo_wave_file_name, "w") as f:
                                    if io_const.SAVE_DATA_TO_CSV:
                                        df_wave_data.to_csv(f)

                                ###print("{} Multi dimensional DataFrame Saved to CSV : {}".format(channel_name, cemo_wave_file_name))
                                df_full_data = df_full_data.merge(df_wave_data, on=io_const.TDEP_COLUMN)

                        else:
                            logging.warning("No Multi dimensional columns found in the frame/logical file")

                        ###print(df_full_data.head(5))
                        full_data_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                   depth_range, io_const.ALL_CHANNEL_DATA_CSV_SUFFIX)
                        if io_const.SAVE_DATA_TO_CSV:
                            with open(full_data_file_name, "w") as f:
                                df_full_data.to_csv(f)

                        ###print("*********************************************************")
                        channel_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                 depth_range, io_const.CHANNEL_DATA_CSV_SUFFIX)
                        if io_const.SAVE_DATA_TO_CSV:
                            with open(channel_file_name, "w") as f:
                                df_full_data.to_csv(f)

                        ###print("DataFrame Saved to CSV : {}" + channel_file_name)

                        st.write(parameter_table)

                        param_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                               depth_range, io_const.HEADER_CSV_SUFFIX)
                        with open(param_file_name, "w") as f:
                            parameter_table.to_csv(f)

                        zone_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                              depth_range, io_const.ZONE_DATA_CSV_SUFFIX)

                        st.write(zone_table)
                        with open(zone_file_name, "w") as f:
                            zone_table.to_csv(f)

                        # depth_range = (df_curves.index[0], df_curves.index[-1])
                        logical_file_info_dict = {'Field Name': field_name, 'Well Name': well_name,
                                                  'Company': company_name, 'Producer Name': producer_name,
                                                  'Set Name': set_name, 'Frame Name': frm.name,
                                                  'Total Rows and Columns': depth_range, 'Depth Range': depth_range,
                                                  'Column Names': list(df_curves.columns) + list(
                                                      cemo_wave_channel_names)}
                        ###print(logical_file_info_dict)

                        dlis_summary = dlis_summary.append(logical_file_info_dict, ignore_index=True)

                        summary_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{file_name_pattern}" \
                                            f"{io_const.SUMMARY_DATA_CSV_SUFFIX}"

                    except Exception as e:
                        # print("*********************************************************")
                        logging.error("Got Error with dlisio library.... : {}".format(e))

                    # Convert the index to metres if needed
                    if curve_index.units == '0.1 in':
                        frm_curves[frm.index] *= 0.00254

                    channel_names = lfile_channels  # reader.get_all_channel_names(frm, duplicate_channel_list)
                    ###print("channel_names", channel_names)
                    try:
                        cemo_channel_name = io_const.CEMO_COLUMN
                        wave_channel_name = io_const.WAVE_COLUMN
                        ccl_channel_name = io_const.CCL_COLUMN
                        amav_channel_name = io_const.AMAV_COLUMN
                        atav_channel_name = io_const.ATAV_COLUMN
                        gr_channel_name = io_const.GR_COLUMN
                        dtmn_channel_name = io_const.DTMN_COLUMN
                        dtmx_channel_name = io_const.DTMX_COLUMN

                        if io_const.CCL_I_COLUMN in channel_names:
                            ccl_channel_name = io_const.CCL_I_COLUMN
                        if io_const.GR_I_COLUMN in channel_names:
                            gr_channel_name = io_const.GR_I_COLUMN
                        if io_const.AMAV_I_COLUMN in channel_names:
                            amav_channel_name = io_const.AMAV_I_COLUMN
                        if io_const.ATAV_I_COLUMN in channel_names:
                            atav_channel_name = io_const.ATAV_I_COLUMN
                        if io_const.DTMN_I_COLUMN in channel_names:
                            dtmn_channel_name = io_const.DTMN_I_COLUMN
                        if io_const.DTMX_I_COLUMN in channel_names:
                            dtmx_channel_name = io_const.DTMX_I_COLUMN

                        if io_const.CEMO_I_COLUMN in channel_names:
                            cemo_channel_name = io_const.CEMO_I_COLUMN

                        if io_const.WAVE_I_COLUMN in channel_names:
                            wave_channel_name = io_const.WAVE_I_COLUMN

                        if io_const.SAVE_INDIVIDUAL_PLOTS:
                            # Plot wave data with single column
                            cemo_plot_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                       depth_range, io_const.CEMO_PLOT_FILE_SUFFIX)
                            fig = plot_cbl.plot_single_cem_form(frm, frm_curves, cemo_channel_name, cemo_plot_file_name)
                            fig_list.append(fig)

                            # Plot wave data with single column
                            wave_plot_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                       depth_range, io_const.WAVE_PLOT_FILE_SUFFIX)
                            fig = plot_cbl.plot_single_wave_form(frm, frm_curves, wave_channel_name,
                                                                 wave_plot_file_name)
                            fig_list.append(fig)

                        atc_channel_names = []
                        try:
                            my_placeholder.text("Validate ATC channels...")
                            for (atc_ch, atc_i_ch) in zip(io_const.ATC_COLUMN_LIST, io_const.ATC_I_COLUMN_LIST):
                                ###print(atc_ch, atc_i_ch)
                                if atc_ch in channel_names:
                                    atc_channel_names = io_const.ATC_COLUMN_LIST
                                    break
                                elif atc_i_ch in channel_names:
                                    atc_channel_names = io_const.ATC_I_COLUMN_LIST
                                    break

                            if len(atc_channel_names) > 0:

                                if io_const.SAVE_INDIVIDUAL_PLOTS:
                                    ###print("Plot ATC channels")
                                    ###Plot ATC data with single column
                                    atc_plot_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR,
                                                                              file_name_pattern,
                                                                              depth_range,
                                                                              io_const.ATC_PLOT_FILE_SUFFIX)

                                    fig = plot_cbl.plot_single_atc(frm, frm_curves, atc_channel_names,
                                                                   atc_plot_file_name)
                                    fig_list.append(fig)

                                # predict the CCB
                                ccb_rf_model_file_path = os.path.join(io_const.MODELS_DIR,
                                                                      ml_const.CCB_TRAINED_RF_MODEL_JOBLIB)
                                ccb_classifier = None
                                try:
                                    ccb_classifier = ml_helper.load_model(ccb_rf_model_file_path)
                                    logging.debug(f"Existing model : {ccb_classifier}")

                                except Exception as e:
                                    logging.error(f"ERROR while loading the model....{e}")

                                if ccb_classifier is None:
                                    logging.debug(f"Training the RF model...")
                                    ccb_classifier = ml_helper.get_rf_ccb_model(ccb_rf_model_file_path)

                                feature_names = atc_channel_names
                                ###print("------------------1-------------\n", feature_names)
                                df_atc = pd.DataFrame(frm_curves[[io_const.TDEP_COLUMN] + feature_names])
                                print('df_atc', df_atc.shape)
                                ###print("------------------2-------------\n", df_atc.head(2))
                                ccb_df = ml_helper.predict_cbl_cement_to_casinge(ccb_classifier, \
                                                                                 df_atc[feature_names].values)
                                ###print("------------------3-------------\n", ccb_df.head(2))
                                print('ccb_df', ccb_df.shape)
                                ###print(f"Predicted df shape : {ccb_df.shape}")
                                ccb_ndarray = ccb_df[io_const.CCB_COLUMN].values.reshape(-1, 1)

                                # save CCB plot
                                if io_const.SAVE_INDIVIDUAL_PLOTS:
                                    ccb_plot_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR,
                                                                         file_name_pattern,
                                                                         depth_range,
                                                                         io_const.CCB_PLOT_FILE_SUFFIX)
                                    ###print("------------------4-------------\n", ccb_plot_path)
                                    plot_cbl.plot_cement_quality(ccb_ndarray, min_depth, max_depth, ccb_plot_path)

                                # Predict the FREE PIPE
                                free_pipe_rf_model_file_path = os.path.join(io_const.MODELS_DIR,
                                                                            ml_const.FREE_PIPE_TRAINED_RF_MODEL_JOBLIB)
                                fp_classifier = None
                                try:
                                    fp_classifier = ml_helper.load_model(free_pipe_rf_model_file_path)
                                    logging.debug(f"Existing model : {fp_classifier}")
                                except Exception as e:
                                    logging.error(f"ERROR while loading the model....{e}")

                                if fp_classifier is None:
                                    my_placeholder.text(f"Training the RF model...")
                                    fp_classifier = ml_helper.get_rf_free_pipe_model(free_pipe_rf_model_file_path)

                                my_placeholder.text(fp_classifier)

                                df_wave = pd.DataFrame(frm_curves[wave_channel_name])
                                print('df_wave', df_wave.shape)
                                ###print("------------------5-------------\n", df_wave.head(2))
                                fp_df = ml_helper.predict_cbl_free_pipe(fp_classifier, \
                                                                        df_wave.iloc[:, 29:140].values)

                                ###print(f"Predicted Free Pipe df shape : {fp_df.shape}")
                                fp_ndarray = fp_df[io_const.FREE_PIPE_COLUMN].values.reshape(-1, 1)

                                # save CCB plot
                                if io_const.SAVE_INDIVIDUAL_PLOTS:
                                    fp_plot_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                        file_name_pattern, \
                                                                        depth_range, \
                                                                        io_const.FP_PLOT_FILE_SUFFIX)
                                    ###print("------------------7-------------\n", fp_plot_path)
                                    plot_cbl.plot_free_pipe(fp_ndarray, min_depth, max_depth, fp_plot_path)

                                df_atav = pd.DataFrame(frm_curves[[io_const.TDEP_COLUMN] + [atav_channel_name]])
                                print('dm_atav', df_atav.shape)
                                ###print(f"Bond Index Calculation : {df_atav.shape}")

                                free_pipe_atten_9, free_pipe_atten_7, hi_cutoff_9, hi_cutoff_7 = pre_process.get_bi_header_info(
                                    header_info, zone_table)

                                ###print("Casing Depths: ", casing9_min, casing9_max, casing7_min, casing7_max)
                                df_bi = pre_process.bond_index_calculation(df_atav, atav_channel_name, int(casing9_min), \
                                                                           int(casing9_max), int(casing7_min), \
                                                                           int(casing7_max), float(free_pipe_atten_9), \
                                                                           float(free_pipe_atten_7), float(hi_cutoff_9), \
                                                                           float(hi_cutoff_7))
                                # df_bi.to_csv('bi.csv')
                                print('df_bi', df_bi.shape)

                                df_final_flag = pre_process.get_final_cement_bond_flags(ccb_df, fp_df)
                                print('df_final_flag', df_final_flag.shape)
                                print(len(np.arange(min_depth, max_depth + unit_depth, unit_depth)))
                                df_final_flag[io_const.TDEP_COLUMN] = np.arange(min_depth, max_depth + unit_depth,
                                                                                unit_depth)
                                # print(df_final_flag.head(5))
                                df_final_flag.to_csv("{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                          file_name_pattern, \
                                                                          depth_range, \
                                                                          io_const.FINAL_FLAG_DATA_CSV_SUFFIX))

                                final_flag_ndarray = df_final_flag[io_const.FINAL_FLAG_COLUMN].values.reshape(-1, 1)
                                ###print("===============================================================================")
                                ###save all plots to one pdf
                                merged_plot_pdf_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                            file_name_pattern, \
                                                                            depth_range, \
                                                                            io_const.ALL_PLOTS_FILE_SUFFIX)
                                fig = plot_cbl.plot_combo_grid(casing_df, frm, ccb_ndarray, fp_ndarray,
                                                               df_bi, final_flag_ndarray, \
                                                               wave_channel_name, cemo_channel_name, atc_channel_names, \
                                                               ccl_channel_name, gr_channel_name, amav_channel_name, \
                                                               atav_channel_name, dtmn_channel_name, dtmx_channel_name, \
                                                               min_depth, max_depth, df_zone_info_db,
                                                               merged_plot_pdf_path)

                                # with open(merged_plot_pdf_path, "rb") as pdf_file:
                                #     base64_pdf = base64.b64encode(pdf_file.read()).decode('utf-8')
                                #
                                #     #pdf_display = f'<iframe src="data:application/pdf;base64,{base64_pdf}" allowfullscreen="allowfullscreen" width="98%" height="600" frameborder="0" scrolling="no" id="iframe" align="center" style="border:none;"> </iframe> '
                                #     pdf_display = f'<embed src="data:application/pdf;base64,{base64_pdf}" type="application/pdf" allowfullscreen="allowfullscreen" width="98%" height="600" frameborder="0" scrolling="no" id="iframe" align="center" style="border:none;"> '
                                #     st.markdown(pdf_display, unsafe_allow_html=True)

                                st.write(fig)

                                # save zone info from DB
                                zone_info_from_db_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{file_name_pattern}" \
                                                              f"{io_const.ZONE_INFO_DB_DATA_CSV_SUFFIX}"
                                df_zone_info_db.to_csv(zone_info_from_db_file_name)

                                # Calculate Travel time Anomaly
                                df_dtminmax = pd.DataFrame(
                                    frm_curves[[io_const.TDEP_COLUMN, dtmn_channel_name, dtmx_channel_name]])
                                print('df_dtminmax', df_dtminmax.shape)
                                df_tt_anomaly = pre_process.calculate_travel_time_anomaly(df_dtminmax,
                                                                                          dtmn_channel_name,
                                                                                          dtmx_channel_name)
                                print('df_tt_anomaly', df_tt_anomaly.shape)
                                travel_time_anomaly_csv_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                                    file_name_pattern, \
                                                                                    depth_range, \
                                                                                    io_const.TRAVEL_TIME_DATA_CSV_SUFFIX)
                                df_tt_anomaly.to_csv(travel_time_anomaly_csv_path, index=False)

                                st.write(df_tt_anomaly)

                                # Calculate CCL
                                df_calculated_ccl = pre_process.calculate_ccl(df_dtminmax, dtmn_channel_name,
                                                                              dtmx_channel_name)
                                print('df_calculated_ccl', df_calculated_ccl.shape)
                                calculated_ccl_csv_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                               file_name_pattern, \
                                                                               depth_range, \
                                                                               io_const.CALCULATED_CCL_DATA_CSV_SUFFIX)
                                df_calculated_ccl.to_csv(calculated_ccl_csv_path, index=False)

                                # st.write(df_calculated_ccl)

                                # Calculate Cement Quality by Excluding CCL
                                df_cement_quality = pre_process.generate_final_cement_quality(df_final_flag,
                                                                                              df_calculated_ccl)
                                print('df_cement_quality', df_cement_quality.shape)
                                cement_quality_csv_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                               file_name_pattern, \
                                                                               depth_range, \
                                                                               io_const.CEMENT_QUALITY_DATA_CSV_SUFFIX)
                                df_cement_quality.to_csv(cement_quality_csv_path, index=False)

                                # Validate Zonal Isolation
                                df_zonal_isolation = pre_process.validate_zonal_isolation(df_final_flag,
                                                                                          df_zone_info_db, unit_depth)
                                print('df_zonal_isolation', df_zonal_isolation.shape)
                                zonal_isolation_csv_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                                file_name_pattern, \
                                                                                depth_range, \
                                                                                io_const.ZONAL_ISOLATION_DATA_CSV_SUFFIX)
                                df_zonal_isolation.to_csv(zonal_isolation_csv_path, index=False)

                                st.write(df_zonal_isolation)

                                # Validate channelling
                                df_channelling = pre_process.channelling_identification(frm, cemo_channel_name,
                                                                                        df_final_flag, unit_depth)
                                print('df_channelling', df_channelling.shape)
                                channelling_csv_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, \
                                                                            file_name_pattern, \
                                                                            depth_range, \
                                                                            io_const.CHANNELLING_DATA_CSV_SUFFIX)
                                df_channelling.to_csv(channelling_csv_path, index=False)

                                st.write(df_channelling)

                            else:
                                logging.warning("ATC channels not found in the logical file.")

                        except Exception as e:
                            logging.error(f"ERROR while Processing channel data....{e}")

                    except Exception as e:
                        logging.error(f"ERROR while plotting the WAVE data....{e}")


            else:
                logging.warning("Required Channels are missing.")

            if io_const.SAVE_DATA_TO_CSV:
                with open(summary_file_name, "w") as f:
                    dlis_summary.to_csv(f)


if __name__ == "__main__":
    # main(str(sys.argv[1]))
    main()
