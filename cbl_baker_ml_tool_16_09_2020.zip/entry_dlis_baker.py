# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 12:53:04 2020

This Python script provides an entry-point for building machine learning
prediction models for BAKER Cement Bond Logs. The methods extracts dlis files,
develop machine learning models by considering several combinations of the
ATC channels, and develop predictive models for
Cement Bond Quality (CQF). This script can be executed from Spyder IDE, or
from a Windows command prompt as > python entry_dlis_baker.py

Note:
    Training and predictions should run separately. Please don't provide \
    both training and prediction flags as True at the same time.

Usage:
    Following commands assume that dlis/data is provided for BAKER,
    and we are generating predictions for the Cement quality.

    Execute this file from command-line using following commands:

        * Training

        python entry_dlis_baker.py -dlis XXX.dlis -input_csv Well_Locations.csv \
        -tr True -pr False -df False -dft False

@author: Prabhaker Reddy Vanam
"""

# import concurrent.futures
import multiprocessing
import os
import sys
# from multiprocessing import Pool
import time

import dlisio
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages

from aon.dlis.ds.data_structures import LogicalFile
from aon.dlis.io import data_reader as reader
from aon.dlis.io import io_constants as io_const
from aon.dlis.io import plot_cement_bond_log as plot_cbl
from aon.dlis.model import cbl_model_helper as ml_helper
from aon.dlis.model import model_constants as ml_const
from aon.dlis.preprocess import data_preprocessor as pre_process

# Custom Logger
from logging_baker import logger
import matplotlib
matplotlib.use('TkAgg')

np.random.seed(ml_const.RANDOM_STATE)

# Set encodings for dlisio
dlisio.set_encodings(['latin1'])

training_data_dir = ""

duplicate_channel_list = []
dlis_summary = None
df_zone_info_db = None
logical_file_info_dict = {}



#logging.config.fileConfig(fname='.\config\log4py.properties', disable_existing_loggers=True)

def process_logical_file(lfile, response_dict, plot_fig_dict):
   
    logger.debug(f"Process started for : {lfile}")

    is_casing_plotted = False
    zone_info_extracted_from_db = False
    logical_file = None

    problematic_list = lfile.problematic

    # check for duplicate channels to skip by the code
    if len(problematic_list) > 0:

        logger.debug("Its Problematic file with duplicate channels : {}".format(problematic_list))

        prob_channel_list = [x[0] for x in problematic_list]

        for dup_chn in prob_channel_list:

            prob_channel_name = dup_chn.name
            # logger.debug(prob_channel_name)

            if prob_channel_name not in duplicate_channel_list:
                duplicate_channel_list.append(prob_channel_name)

    # Validate columns
    lfile_channels: list = reader.get_all_channel_names_of_logical_file(lfile, duplicate_channel_list)

    # 1. Validate required channels
    channel_missing = False

    for (ch, ch_i) in zip(io_const.SBT_CHANNEL_SET, io_const.SBT_CHANNEL_SET_I):

        if ch not in lfile_channels and ch_i not in lfile_channels:
            channel_missing = True
            break
    logger.debug(f"Logical file channel list : {lfile_channels}")
    logger.debug(f"Missing Required channels ?  { channel_missing}")
    if not channel_missing:

        # Initialize the logical File bean class
        logical_file = LogicalFile()

        parameter_table = reader.summarize(lfile.parameters, name=io_const.HEADER_PARAM_NAME_COLUMN,
                                           long_name=io_const.HEADER_LONG_NAME_COLUMN,
                                           values=io_const.HEADER_PARAM_VALUES_COLUMN,
                                           zones=io_const.HEADER_ZONES_COLUMN)

        zone_table = reader.summarize(lfile.zones, name=io_const.HEADER_PARAM_NAME_COLUMN, minimum='Minimum',
                                      maximum='Maximum')
        logger.debug(f"Header Casing data : {zone_table.head(5)}")

        # parameter_table['Value(s)'] = parameter_table['Value(s)'].apply(lambda x: str(x).strip('[]'))
        parameter_table[io_const.HEADER_ZONES_COLUMN] = parameter_table[io_const.HEADER_ZONES_COLUMN].apply(
            lambda x: str(x).strip('[]'))

        # Hide parameters containing names; see the privacy note in the Introduction. Comment out these lines
        # to show them.
        exclude_mask = ~parameter_table[io_const.HEADER_PARAM_NAME_COLUMN].isin(['RR1', 'WITN', 'ENGI'])
        parameter_table = parameter_table[exclude_mask]

        logical_file.well_name = get_header_property(parameter_table, 'WN')
        logical_file.company_name = get_header_property(parameter_table, 'CN')
        logical_file.producer_name = get_header_property(parameter_table, 'LCNM')
        logical_file.set_name = get_header_property(parameter_table, 'SET')
        logical_file.field_name = get_header_property(parameter_table, 'FN')

        # extract Casing data from header (Params and Zones)
        cs_table = parameter_table[parameter_table[io_const.HEADER_PARAM_NAME_COLUMN].str.startswith("CS")]
        cs_table[io_const.HEADER_PARAM_VALUES_COLUMN] = cs_table[io_const.HEADER_PARAM_VALUES_COLUMN].apply(
            lambda x: str(x).strip('[]'))
        cs_table[io_const.HEADER_ZONES_COLUMN] = cs_table[io_const.HEADER_ZONES_COLUMN].apply(
            lambda x: str(x).strip('Zone()'))

        if not zone_table.empty:
            cs_table = cs_table.merge(zone_table, left_on=io_const.HEADER_ZONES_COLUMN,
                                      right_on=io_const.HEADER_PARAM_NAME_COLUMN)
            logger.debug(f"Header Casing/Zone data : {cs_table.head(5)}")

        logical_file.well_name = pre_process.format_well_name(logical_file.well_name)

        if not zone_info_extracted_from_db:
            df_zone_info_db = reader.load_zone_info_from_expris(logical_file.well_name)
            zone_info_extracted_from_db = True

        channel_table = reader.summarize(lfile.channels, name=io_const.HEADER_PARAM_NAME_COLUMN,
                                         long_name=io_const.HEADER_LONG_NAME_COLUMN, units=io_const.HEADER_UNITS_COLUMN,
                                         dimension=io_const.HEADER_DIMEN_COLUMN, frame=io_const.HEADER_FRAME_COLUMN)
        channel_table.sort_values(io_const.HEADER_PARAM_NAME_COLUMN)

        # tool_table = reader.summarize(lfile.tools, name=io_const.HEADER_PARAM_NAME_COLUMN, generic_name=io_const.HEADER_GENERIC_NAME_COLUMN,
        #                              trademark_name=io_const.HEADER_TRADEMARK_COLUMN, description=io_const.HEADER_DESC_COLUMN)
        # tool_table.sort_values(io_const.HEADER_PARAM_NAME_COLUMN)
        ###logger.debug(tool_table)

        header_info = parameter_table.loc[
            parameter_table[io_const.HEADER_PARAM_NAME_COLUMN].isin(list(io_const.HEADER_PARAM_LIST))]. \
            drop(columns=io_const.HEADER_ZONES_COLUMN, axis=1)


        origin, *origin_tail = lfile.origins

        if len(origin_tail):
            logger.warning('Logical file contains multiple origins')

        for origin in lfile.origins:
            origin.describe()
            logical_file.producer_name = origin.producer_name
            logical_file.field_name = origin.field_name
            if not logical_file.well_name:
                logical_file.well_name = origin.well_name

        frm = reader.get_frame_from_logical_file(lfile)

        # for frm in lfile.frames:
        if not frm == None:

            # define three dataframes cemo, wave and channel to hold different dimension data
            df_single_dim_data = pd.DataFrame()
            df_cemo_data = pd.DataFrame()
            df_wave_data = pd.DataFrame()

            logical_file.frame_name = frm.name
            logical_file.logical_file_key = f"{logical_file.field_name}_{logical_file.well_name}_{logical_file.producer_name}_{logical_file.set_name}_{frm.name}"

            logger.debug(f"{logical_file.logical_file_key}")

            try:
                logger.debug("Reading frame curves...")
                frm_curves = frm.curves(strict=False)
                curve_index = reader.index_of(frm)

                # Convert the index to metres if needed
                if curve_index.units == '0.1 in':
                    frm_curves[frm.index] *= 0.00254

                logger.debug("Reading frame finished.")
                logger.debug(frm_curves.shape)
            except Exception as e:
                logger.error(f"ERROR in reading curve data.... : {e}")

            try:
                all_curves_names = reader.get_all_channel_names(frm, duplicate_channel_list)
                # single_dim_curves_names = reader.get_single_dim_channel_names(frm, duplicate_channel_list)
                logical_file.channel_list = all_curves_names
                logical_file.duplicate_channel_list = duplicate_channel_list

                logger.debug(all_curves_names)
                atc_channels = [i for i in all_curves_names if
                                i.startswith('ATC') and not i.startswith('ATC1.1') and not i.startswith('ATC1.I1')]
                atc_channels.sort()
                logger.debug(atc_channels)
                atav_channel = [i for i in all_curves_names if i.startswith(io_const.ATAV_COLUMN)]
                logger.debug(atav_channel)
                amav_channel = [i for i in all_curves_names if
                                i.startswith(io_const.AMAV_COLUMN) and not i.startswith('AMAV5')]
                logger.debug(amav_channel)
                ccl_channel = [i for i in all_curves_names if i.startswith(io_const.CCL_COLUMN)]
                logger.debug(ccl_channel)
                dtmn_channel = [i for i in all_curves_names if i.startswith(io_const.DTMN_COLUMN)]
                logger.debug(dtmn_channel)
                dtmx_channel = [i for i in all_curves_names if i.startswith(io_const.DTMX_COLUMN)]
                logger.debug(dtmx_channel)
                gr_channel = [i for i in all_curves_names if i.startswith(io_const.GR_COLUMN)]
                logger.debug(gr_channel)
                wave_channel = [i for i in all_curves_names if
                                i.startswith(io_const.WAVE_COLUMN) and not i.startswith('WAVEF')]
                logger.debug(wave_channel)
                cemo_channel = [i for i in all_curves_names if i.startswith(io_const.CEMO_COLUMN)]
                logger.debug(cemo_channel)
                tdep_channel = [i for i in all_curves_names if i.startswith(io_const.TDEP_COLUMN)]
                logger.debug(tdep_channel)

                devod_channel = [i for i in all_curves_names if i.startswith(io_const.DEVOD_COLUMN)]
                logger.debug(devod_channel)

                single_dim_curves_names = tdep_channel + atc_channels + atav_channel + amav_channel + ccl_channel + dtmn_channel + dtmx_channel + gr_channel + devod_channel
                logger.debug(single_dim_curves_names)

                if len(single_dim_curves_names) > 0:
                    df_single_dim_data = pd.DataFrame(frm_curves[single_dim_curves_names], index=frm_curves[frm.index])
                    logger.debug(df_single_dim_data.head(1))

                if len(wave_channel) > 0:
                    df_wave_data = pd.DataFrame(frm_curves[wave_channel[0]], index=frm_curves[frm.index])
                    df_wave_data.columns = ['W_' + str(col) for col in df_wave_data.columns]
                    df_wave_data[io_const.TDEP_COLUMN] = df_wave_data.index
                    logger.debug(df_wave_data.head(1))

                if len(cemo_channel) > 0:
                    df_cemo_data = pd.DataFrame(frm_curves[cemo_channel[0]], index=frm_curves[frm.index])
                    df_cemo_data.columns = ['C_' + str(col) for col in df_cemo_data.columns]
                    df_cemo_data[io_const.TDEP_COLUMN] = df_cemo_data.index
                    logger.debug(df_cemo_data.head(1))

                logical_file.min_depth = frm_curves[io_const.TDEP_COLUMN].min()
                logical_file.max_depth = frm_curves[io_const.TDEP_COLUMN].max()
                logical_file.unit_depth = frm_curves[io_const.TDEP_COLUMN][1] - frm_curves[io_const.TDEP_COLUMN][0]
                depth_range = (logical_file.min_depth, logical_file.max_depth)
                logger.debug("=======================================")
                logger.debug(f"{depth_range}")
                logger.debug("=======================================")
                if not is_casing_plotted:
                    casing_df = pre_process.get_casing_plot_data(cs_table, logical_file)
                    is_casing_plotted = True

                double_casing_message = ""
                # skip message for dummy casing plot by validating 9.5", 7" min of 1000 feets

                logger.debug(f"{int(logical_file.casing13_max), int(logical_file.casing9_min)}")
                if int(logical_file.casing13_max) >= 1000:
                    if int(logical_file.casing13_max - logical_file.casing9_min) >= io_const.DOUBLE_CASING_CUTOFF:
                        double_casing_message = f"Identified {logical_file.casing13_max - logical_file.casing9_min} feets depth double casing (13' & 9.5') From: {logical_file.casing9_min} - To: {logical_file.casing13_max}, data is not reliable for cement evaluation."

                logger.debug(f"{int(logical_file.casing9_max), int(logical_file.casing7_min)}")
                if (int(logical_file.casing9_max) >= 1000) & (int(logical_file.casing7_min) >= 1000):
                    if int(logical_file.casing9_max - logical_file.casing7_min) >= io_const.DOUBLE_CASING_CUTOFF:
                        message = f"Identified {logical_file.casing9_max - logical_file.casing7_min} feets depth double casing (9.5' & 7') From: {logical_file.casing7_min} - To: {logical_file.casing9_max}, data is not reliable for cement evaluation."
                        if double_casing_message == "":
                            double_casing_message = message
                        else:
                            double_casing_message = double_casing_message + ", " + message

                logger.debug(double_casing_message)
                if io_const.DOUBLE_CASING_MESSAGE not in response_dict.keys():
                    response_dict[io_const.DOUBLE_CASING_MESSAGE] = [double_casing_message]
                else:
                    response_dict[io_const.DOUBLE_CASING_MESSAGE].append(double_casing_message)

                # Channel data to CSV -  file paths
                single_dim_data_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.CHANNEL_DATA_CSV_SUFFIX}"
                wave_data_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.WAVE_DATA_CSV_SUFFIX}"
                cemo_data_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.CEMO_DATA_CSV_SUFFIX}"

                header_file_name = f"{logical_file.logical_file_key}_{depth_range}{io_const.HEADER_CSV_SUFFIX}"
                header_file_path = f"{io_const.OUTPUT_DATA_DIR}\\{header_file_name}"
                zone_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.ZONE_DATA_CSV_SUFFIX}"

                # Save data to CSV
                try:

                    if io_const.HEADER_FILES not in response_dict.keys():
                        response_dict[io_const.HEADER_FILES] = [header_file_name]
                    else:
                        response_dict[io_const.HEADER_FILES].append(header_file_name)

                    with open(header_file_path, "w") as f:
                        parameter_table.to_csv(f,index=False , line_terminator='\n')

                    if io_const.SAVE_DATA_TO_CSV:
                        with open(single_dim_data_file_name, "w") as f:
                            df_single_dim_data.to_csv(f,index=False , line_terminator='\n')

                        with open(cemo_data_file_name, "w") as f:
                            df_cemo_data.to_csv(f,index=False , line_terminator='\n')

                        with open(wave_data_file_name, "w") as f:
                            df_wave_data.to_csv(f,index=False , line_terminator='\n')

                        with open(zone_file_name, "w") as f:
                            zone_table.to_csv(f,index=False , line_terminator='\n')

                except Exception as ex:
                    logger.error(f"ERROR : while saving data to CSV files {ex} ")

                ###logger.debug(f"Bond Index Calculation : {df_atav.shape}")
                ret_value = pre_process.get_bi_header_info(header_info, zone_table, logical_file)
                logger.debug(f"Header Extracted : {ret_value}")

                # Predict the FREE PIPE if WAVE data exists
                fp_df = pd.DataFrame()
                if not df_wave_data.empty:
                    free_pipe_rf_model_file_path = os.path.join(io_const.MODELS_DIR,
                                                                ml_const.FREE_PIPE_TRAINED_RF_MODEL_JOBLIB)
                    fp_classifier = None
                    try:
                        fp_classifier = ml_helper.load_model(free_pipe_rf_model_file_path)
                        logger.debug(f"Existing model : {fp_classifier}")
                    except Exception as e:
                        logger.error(f"ERROR while loading the model....{e}")

                    if fp_classifier is None:
                        ###logger.debug(f"Training the RF model...")
                        fp_classifier = ml_helper.get_rf_free_pipe_model(free_pipe_rf_model_file_path)

                    # no Correction required for Free Pipe prediction
                    fp_df = ml_helper.predict_cbl_free_pipe(fp_classifier, df_wave_data.iloc[:,
                                                                           io_const.WAVE_START_IDX:io_const.WAVE_END_IDX].values)

                # Calculate Travel time Anomaly
                df_dtminmax = df_single_dim_data[tdep_channel + dtmn_channel + dtmx_channel]
                logger.debug(f"df_dtminmax.empty? {df_dtminmax.empty}")

                df_tt_anomaly = pre_process.calculate_travel_time_anomaly(df_dtminmax, dtmn_channel[0], dtmx_channel[0],
                                                                          logical_file.unit_depth)
                logger.debug(f"df_tt_anomaly.empty? {df_tt_anomaly.empty}")

                travel_time_anomaly_file = f"{logical_file.logical_file_key}_{depth_range}{io_const.TRAVEL_TIME_DATA_CSV_SUFFIX}"
                travel_time_anomaly_csv_path = f"{io_const.OUTPUT_DATA_DIR}\\{travel_time_anomaly_file}"

                with open(travel_time_anomaly_csv_path, "w") as f:
                    df_tt_anomaly.to_csv(f, index=False , line_terminator='\n')

                if io_const.TRAVEL_TIME_ANOMALY_FILES not in response_dict.keys():
                    response_dict[io_const.TRAVEL_TIME_ANOMALY_FILES] = [travel_time_anomaly_file]
                else:
                    response_dict[io_const.TRAVEL_TIME_ANOMALY_FILES].append(travel_time_anomaly_file)

                # Calculate CCL
                df_calculated_ccl = pre_process.calculate_ccl(df_dtminmax, dtmn_channel[0], dtmx_channel[0])
                logger.debug(f"df_calculated_ccl.empty? {df_calculated_ccl.empty}")

                calculated_ccl_csv_path = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.CALCULATED_CCL_DATA_CSV_SUFFIX}"
                if io_const.SAVE_DATA_TO_CSV:
                    with open(calculated_ccl_csv_path, "w") as f:
                        df_calculated_ccl.to_csv(f, index=False , line_terminator='\n')

                # below Free Pipe data will be used for other calculations
                fp_ndarray = []
                if not fp_df.empty:
                    fp_ndarray = fp_df[io_const.FREE_PIPE_COLUMN].values.reshape(-1, 1)

                ''' Normalization validation start'''

                # df_single_dim_data dataframe key data and this need to be updated accordingly to reflect Tool caliboration error correction
                ccb_df = predict_cement_quality(df_single_dim_data, tdep_channel, atc_channels)

                # Calculate Bond Index and Final Flags on the normalized data
                df_bi, df_final_flag = calculate_bi_final_flags(df_single_dim_data, ccb_df, fp_df, tdep_channel,
                                                                atav_channel, logical_file)

                df_atav = df_single_dim_data[tdep_channel + atav_channel]
                logger.debug(f"dm_atav.empty? {df_atav.empty}")

                ## Calculate Tool calibration error
                tool_calibration_executed = False
                final_flag_ndarray = []
                if not df_final_flag.empty:
                    tool_calibration_executed = pre_process.validate_tool_calibration_error(df_atav, df_final_flag,
                                                                                            atav_channel[0],
                                                                                            logical_file)
                    logger.debug(f"Tool Calibration done : {tool_calibration_executed}")
                    final_flag_ndarray = df_final_flag[io_const.FINAL_FLAG_COLUMN].values.reshape(-1, 1)

                if tool_calibration_executed:
                    # Validate & get the Correction factor for normalization

                    # Calculate Attenuation from CEMO data = (Attenuation(min) + (BI/100 *(Attenuation(max) ? Attenuation(min))))
                    # TODO  - dm_cemo_data

                    normalization_required = False
                    if float(logical_file.free_pipe_atten_9) > 0:
                        if logical_file.tool_calibration_error_9 >= io_const.TOOL_CALIBRATION_CUTOFF:
                            normalization_required = True
                            logical_file.correction_factor_9 = float(logical_file.free_pipe_atten_calc_9) / float(
                                logical_file.free_pipe_atten_9)
                        else:
                            logical_file.tool_calibration_error_msg_9 = "No tool Calibration error found, No normalization required for 9.5'"
                    else:
                        logical_file.tool_calibration_error_msg_9 = "Free pipe attenuation not found in the header for 9.5', Tool calibration error can not be performed."

                    if float(logical_file.free_pipe_atten_7) > 0:
                        if logical_file.tool_calibration_error_7 >= io_const.TOOL_CALIBRATION_CUTOFF:
                            normalization_required = True
                            logical_file.correction_factor_7 = float(logical_file.free_pipe_atten_calc_7) / float(
                                logical_file.free_pipe_atten_7)
                        else:
                            logical_file.tool_calibration_error_msg_7 = "No tool Calibration error found, No normalization required for 7. "
                    else:
                        logical_file.tool_calibration_error_msg_7 = "Free pipe attenuation not found in the header for 7', Tool calibration error can not be performed."

                    # normalization_required = False  # Temporary disabled
                    # update the data using normalization formula
                    if normalization_required:

                        # Update the df_cemo_data from  percentage to attenuation
                        # CEMO (in Attenuation form) = Attenuation(min) + (BI/100 *(Attenuation(max) ? Attenuation(min)))
                        # df_cemo_data_atten_corrected = df_cemo_data_atten/Correction factor
                        # TODO - df_cemo_data -> df_cemo_data_atten_corrected - >
                        df_cemo_data_atten_corrected = pd.DataFrame()
                        if not df_cemo_data.empty:
                            df_cemo_data_atten_corrected = pre_process.apply_correction_to_cemo_atten_data(df_cemo_data,
                                                                                                           logical_file)

                        # Save data to CSV
                        if io_const.SAVE_DATA_TO_CSV:
                            df_cemo_data_atten_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.CEMO_ATTEN_DATA_CORR_CSV_SUFFIX}"
                            with open(df_cemo_data_atten_file_name, "w") as f:
                                df_cemo_data_atten_corrected.to_csv(f, index=False , line_terminator='\n')

                        # update the CEMO, Single Dimension dataframes to normlize the data
                        # df_single_dim_data = df_single_dim_data/correction_factor_9 or correction_factor_7
                        # TODO update df_single_dim_data_corrected = df_single_dim_data/Correction factor,
                        corrected_coloumns = atc_channels + atav_channel
                        if len(amav_channel) > 0:
                            corrected_coloumns = corrected_coloumns + amav_channel

                        df_single_dim_data_corrected = pre_process.apply_correction_to_single_dim_data(
                            df_single_dim_data, corrected_coloumns, logical_file)

                        # # TODO df_single_dim_data = df_single_dim_data_corrected(after formula applied)
                        if not df_single_dim_data_corrected.empty:
                            logger.debug("Updating the single dim data with corrected dataframe columns.")
                            # keep non modified columns as it in the new dataframe
                            actual_columns = df_single_dim_data.columns
                            for column in actual_columns:
                                if column not in corrected_coloumns:
                                    df_single_dim_data_corrected[column] = df_single_dim_data[column]
                            # replace corrected dataframe with actual
                            df_single_dim_data = df_single_dim_data_corrected
                            if logical_file.tool_calibration_error_9 >= io_const.TOOL_CALIBRATION_CUTOFF and logical_file.free_pipe_atten_9 > 0:
                                logical_file.tool_calibration_error_msg_9 = "Tool Calibration error found, data has been normalized (Attenuation) for 9.5' "

                            if logical_file.tool_calibration_error_7 >= io_const.TOOL_CALIBRATION_CUTOFF and logical_file.free_pipe_atten_7 > 0:
                                logical_file.tool_calibration_error_msg_7 = "Tool Calibration error found, data has been normalized (Attenuation) for 7' "

                        # Save data to CSV
                        if io_const.SAVE_DATA_TO_CSV:
                            df_single_dim_corrected_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.ATC_DATA_AFTER_CORR_CSV_SUFFIX}"
                            with open(df_single_dim_corrected_file_name, "w") as f:
                                df_single_dim_data.to_csv(f, index=False , line_terminator='\n')

                        # TODO df_cemo_data = df_cemo_data_atten_corrected(after formula applied)
                        df_cemo_data_bi = pd.DataFrame()
                        if not df_cemo_data_atten_corrected.empty:
                            df_cemo_data_bi = pre_process.convert_corrected_cemo_to_bond_index(
                                df_cemo_data_atten_corrected, logical_file)
                            if logical_file.tool_calibration_error_9 >= io_const.TOOL_CALIBRATION_CUTOFF and logical_file.free_pipe_atten_9 > 0:
                                logical_file.tool_calibration_error_msg_9 = "Tool Calibration error found, data has been normalized (Attenuation & CEMO) for 9.5' "

                            if logical_file.tool_calibration_error_7 >= io_const.TOOL_CALIBRATION_CUTOFF and logical_file.free_pipe_atten_7 > 0:
                                logical_file.tool_calibration_error_msg_7 = "Tool Calibration error found, data has been normalized (Attenuation & CEMO) for 7' "

                        # Save data to CSV
                        if io_const.SAVE_DATA_TO_CSV:
                            df_cemo_data_bi_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.CEMO_BI_DATA_AFTER_CORR_CSV_SUFFIX}"
                            with open(df_cemo_data_bi_file_name, "w") as f:
                                df_cemo_data_bi.to_csv(f, index=False , line_terminator='\n')

                        if not df_cemo_data_bi.empty:
                            df_cemo_data = df_cemo_data_bi.copy()

                        ccb_df = predict_cement_quality(df_single_dim_data, tdep_channel, atc_channels)

                        df_atav = df_single_dim_data[tdep_channel + atav_channel]
                        logger.debug(f"dm_atav.empty? {df_atav.empty}")

                        # Calculate Bond Index and Final Flags on the normalized data
                        df_bi, df_final_flag = calculate_bi_final_flags(df_single_dim_data, ccb_df, fp_df, tdep_channel,
                                                                        atav_channel, logical_file)
                        logger.debug(f"df_final_flag.empty? {df_final_flag.empty}")
                        final_flag_ndarray = df_final_flag[io_const.FINAL_FLAG_COLUMN].values.reshape(-1, 1)

                        ''' Normalization End'''

                # Cement Quality Data will be used for plotting (CCB calculated on the updated/corrected dataframe values
                ccb_ndarray = ccb_df[io_const.CCB_COLUMN].values.reshape(-1, 1)

                # logger.debug(df_final_flag.head(5))
                final_flags_csv_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.FINAL_FLAG_DATA_CSV_SUFFIX}"
                if io_const.SAVE_DATA_TO_CSV:
                    with open(final_flags_csv_file_name, "w") as f:
                        df_final_flag.to_csv(f, index=False , line_terminator='\n')

                ###logger.debug("===============================================================================")
                ###save all plots to one pdf
                plot_file_name = f"{logical_file.logical_file_key}_{depth_range}{io_const.ALL_PLOTS_FILE_SUFFIX}"
                merged_plot_pdf_path = f"{io_const.OUTPUT_DATA_DIR}\\{plot_file_name}"

                fig = plot_cbl.plot_combo_grid(casing_df, df_single_dim_data, df_cemo_data, df_wave_data, ccb_ndarray,
                                               fp_ndarray, df_bi, final_flag_ndarray, atc_channels, ccl_channel,
                                               gr_channel, amav_channel, atav_channel, dtmn_channel,
                                               dtmx_channel, devod_channel, df_zone_info_db, logical_file)
                # add image to the dictionary , it will be saved to disk at the end
                plot_fig_dict[merged_plot_pdf_path] = fig

                if io_const.PLOT_FILES not in response_dict.keys():
                    response_dict[io_const.PLOT_FILES] = [plot_file_name]
                else:
                    response_dict[io_const.PLOT_FILES].append(plot_file_name)

                # save zone info from DB
                zone_info_from_db_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file.logical_file_key}_{depth_range}{io_const.ZONE_INFO_DB_DATA_CSV_SUFFIX}"
                if io_const.SAVE_DATA_TO_CSV:
                    with open(zone_info_from_db_file_name, "w") as f:
                        df_zone_info_db.to_csv(f, index=False, line_terminator='\n')

                # Calculate Cement Quality by Excluding CCL
                cement_quality_file = f"{logical_file.logical_file_key}_{depth_range}{io_const.CEMENT_QUALITY_DATA_CSV_SUFFIX}"
                cement_quality_csv_path = f"{io_const.OUTPUT_DATA_DIR}\\{cement_quality_file}"
                if io_const.CEMENT_QUALITY_FILES not in response_dict.keys():
                    response_dict[io_const.CEMENT_QUALITY_FILES] = [cement_quality_file]
                else:
                    response_dict[io_const.CEMENT_QUALITY_FILES].append(cement_quality_file)

                zonal_isolation_file = f"{logical_file.logical_file_key}_{depth_range}{io_const.ZONAL_ISOLATION_DATA_CSV_SUFFIX}"
                zonal_isolation_csv_path = f"{io_const.OUTPUT_DATA_DIR}\\{zonal_isolation_file}"
                if io_const.ZONAL_ISOLATION_FILES not in response_dict.keys():
                    response_dict[io_const.ZONAL_ISOLATION_FILES] = [zonal_isolation_file]
                else:
                    response_dict[io_const.ZONAL_ISOLATION_FILES].append(zonal_isolation_file)

                channelling_file = f"{logical_file.logical_file_key}_{depth_range}{io_const.CHANNELLING_DATA_CSV_SUFFIX}"
                channelling_csv_path = f"{io_const.OUTPUT_DATA_DIR}\\{channelling_file}"
                if io_const.CHANNELLING_FILES not in response_dict.keys():
                    response_dict[io_const.CHANNELLING_FILES] = [channelling_file]
                else:
                    response_dict[io_const.CHANNELLING_FILES].append(channelling_file)

                if not df_final_flag.empty:
                    df_cement_quality = pre_process.generate_final_cement_quality(df_final_flag, df_calculated_ccl, logical_file)
                    logger.debug(f"df_cement_quality.empty? {df_cement_quality.empty}")

                    with open(cement_quality_csv_path, "w") as f:
                        if not df_cement_quality.empty:
                            df_cement_quality.to_csv(f, index=False, line_terminator='\n')

                    # Validate Zonal Isolation
                    df_zonal_isolation = pre_process.validate_zonal_isolation(df_final_flag, df_zone_info_db,
                                                                              logical_file)
                    logger.debug(f"df_zonal_isolation.empty? {df_zonal_isolation.empty}")

                    with open(zonal_isolation_csv_path, "w") as f:
                        if not df_zonal_isolation.empty:
                            df_zonal_isolation.to_csv(f, index=False, line_terminator='\n')

                    # Validate channelling
                    if not df_cemo_data.empty:
                        df_channelling = pre_process.channelling_identification(df_cemo_data, df_final_flag,
                                                                                logical_file.unit_depth)
                        logger.debug(f"df_channelling.empty? :{df_channelling.empty}")
                        with open(channelling_csv_path, "w") as f:
                            if not df_channelling.empty:
                                df_channelling.to_csv(f, index=False, line_terminator='\n')

                    # validate isolation at target reservoir
                    pre_process.validate_zonal_isolation_at_target_reservoir(df_final_flag, logical_file)

                    # validate isolation at acquifer
                    pre_process.validate_zonal_isolation_at_acquifer(df_final_flag, df_zone_info_db, logical_file)

            except Exception as e:
                logger.error(f"ERROR while plotting data....{e}")

    else:
        logger.warning("Required Channels are missing.")

    if not logical_file == None:
        lfile_prop_dict = logical_file.__dict__
        # logger.debug(f"set name from data structure : {lfile_prop_dict}")
        for key in lfile_prop_dict:
            # logger.debug(key, '->', lfile_prop_dict[key])
            if key not in response_dict.keys():
                response_dict[str(key)] = [str(lfile_prop_dict[key])]
            else:
                response_dict[str(key)].append(str(lfile_prop_dict[key]))

    return response_dict


def calculate_bi_final_flags(df_single_dim_data, df_ccb, df_freepipe, tdep_channel, atav_channel, logical_file):
    '''

    :param df_single_dim_data:
    :param df_ccb:
    :param df_freepipe:
    :param tdep_channel:
    :param atav_channel:
    :param logical_file:
    :return:
    '''
    df_atav = df_single_dim_data[tdep_channel + atav_channel]
    # Bond index is calcuated on latest ATAV data from df_single_dim_data value will be used for plotting, no other calculations are depending on theis data
    df_bi = pre_process.bond_index_calculation(df_atav, atav_channel[0], logical_file)
    logger.debug(f"df_bi.empty? {df_bi.empty}")
    df_final_flag = pd.DataFrame()

    if not df_freepipe.empty:
        df_final_flag = pre_process.get_final_cement_bond_flags(df_ccb, df_freepipe)
        logger.debug(f"df_final_flag.empty? {df_final_flag.empty}")
        # Add dept column index
        # logger.debug(len(np.arange(logical_file.min_depth, logical_file.max_depth + logical_file.unit_depth, logical_file.unit_depth)))
        df_final_flag[io_const.TDEP_COLUMN] = np.arange(logical_file.min_depth,
                                                        logical_file.max_depth + logical_file.unit_depth,
                                                        logical_file.unit_depth)
    return df_bi, df_final_flag


def predict_cement_quality(df_single_dim_data, tdep_channel, atc_channels):
    '''

    :param atc_channels:
    :param df_single_dim_data:
    :param tdep_channel:
    :return:
    '''
    try:
        # predict the CCB
        ccb_rf_model_file_path = os.path.join(io_const.MODELS_DIR, ml_const.CCB_TRAINED_RF_MODEL_JOBLIB)
        ccb_classifier = None
        try:
            ccb_classifier = ml_helper.load_model(ccb_rf_model_file_path)
            logger.debug(f"Existing model : {ccb_classifier}")

        except Exception as e:
            logger.error(f"ERROR while loading the model....{e}")
        if ccb_classifier is None:
            logger.debug(f"Training the RF model...")
            ccb_classifier = ml_helper.get_rf_ccb_model(ccb_rf_model_file_path)
        feature_names = atc_channels
        # ['ATC1', 'ATC4', 'ATC5', 'ATC2', 'ATC6', 'ATC3']

        df_atc = df_single_dim_data[tdep_channel + feature_names]
        logger.debug(f"df_atc.empty? {df_atc.empty}")
        ccb_df = ml_helper.predict_cbl_cement_to_casinge(ccb_classifier, df_atc[feature_names].values)
        logger.debug(f"ccb_df.empty? {ccb_df.empty}")

        return ccb_df
    except Exception as ex:
        logger.debug(f"ERROR : {ex}")

    return pd.DataFrame()


def get_header_property(parameter_table, property_key):
    '''

    :param parameter_table:
    :param property_key:
    :return:
    '''
    property_value = 'NOT EXISTS'
    exists = property_key in parameter_table["Name"].values
    if exists:
        property_value = parameter_table[parameter_table["Name"] == property_key]['Value(s)'].values[0]

    return str(property_value).strip('[]').strip('\'\'')


def extract_dlis(source_dlis_file, trigger_from_flask: True):
    '''

    :param source_dlis_file:
    :return:
    '''
    source_dlis_file = source_dlis_file.replace('/', '\\\\')

    # Expecting only dlis file name from the Lowcode system, prefix the shared input path
    if trigger_from_flask:

        source_dlis_file = os.path.join(io_const.INPUT_DATA_DIR, source_dlis_file)
        logger.debug(f"Source File path on Lowcode server : {source_dlis_file}")

    response_dict = {}
    plot_fig_dict = {}
    with dlisio.load(source_dlis_file) as files:
        logger.debug(files.describe())
        for lfile in files:
            logger.debug(f"Processing logical file : {lfile}")
            response_dict = process_logical_file(lfile, response_dict, plot_fig_dict)

        # create Thread executor with same number of threads as logical file count
        print("Saving PDF files to the disk.")
        '''with concurrent.futures.ThreadPoolExecutor(max_workers=len(plot_fig_dict)) as executor:
            # save all plot images to the pdf file
            for fig_item in plot_fig_dict.items():
                executor.map(save_fig_to_pdf, (fig_item))
                '''

        '''with Pool(processes=len(plot_fig_dict)) as pool:
            # save all plot images to the pdf file
            for fig_item in plot_fig_dict.items():
                pool.apply_async(save_fig_to_pdf, (fig_item,))
                '''
        jobs = []
        for fig_item in plot_fig_dict.items():
            process = multiprocessing.Process(target=save_fig_to_pdf, args=(fig_item,))
            jobs.append(process)

        # # Start the processes (i.e. calculate the random number lists)
        for j in jobs:
            j.start()

        # # Ensure all of the processes have finished
        for j in jobs:
            j.join()

    #logger.debug(response_dict)

    response_df = pd.DataFrame.from_dict(response_dict)
    logical_file_info_name = f"{response_dict[io_const.LOGICAL_FILE_KEY][0]}{io_const.LOGICAL_FILE_INFO_CSV_SUFFIX}"
    logical_file_info_csv_path = f"{io_const.OUTPUT_DATA_DIR}\\{logical_file_info_name}"
    with open(logical_file_info_csv_path, "w") as f:
        response_df.to_csv(f,index=False , line_terminator='\n')

    return response_dict


def save_fig_to_pdf(fig_item):
    print("Saving file : " + fig_item[0])
    with PdfPages(fig_item[0]) as pdf:
        pdf.savefig(fig_item[1], dpi=300, bbox_inches="tight", pad_inches=0.5)


current_milli_time = lambda: int(round(time.time() * 1000))
def main(dlis_file='xyz.dlis'):

    # Get the logger specified in the file
    #logger = logging.getLogger(__name__)

    logger.info(f"Process started ...{dlis_file}")

    start_time = current_milli_time()

    training_data_dir = os.path.join(io_const.BASE_DATA_DIR, io_const.TRAINING_DATA_DIR)

    logger.debug(training_data_dir)

    response = extract_dlis(dlis_file, trigger_from_flask=False)

    #logger.debug(f"Response : {response}")

    end_time = current_milli_time()

    total_duration = (end_time - start_time) / 1000
    logger.info(f"Total Time taken : {total_duration} Seconds")

    return 0


if __name__ == "__main__":

    main(str(sys.argv[1]))
