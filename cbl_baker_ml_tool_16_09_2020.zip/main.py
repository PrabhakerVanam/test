import os
import sys
import json
from flask import request, jsonify
from werkzeug.utils import secure_filename

import entry_dlis_baker as baker

from app import app

ALLOWED_EXTENSIONS = set(['dlis'])


def main(args):
    host = "10.115.103.105"
    app.run(host=host, port=8001)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def hello():
    return 'Hello from flask....'

@app.route('/process-dlis', methods=['GET', 'POST'])
def process_dlis():
    try :
        secure_file = request.args.get('file_name')
        print(f"from requests args {secure_file}")
        response_dict = baker.extract_dlis(secure_file, trigger_from_flask=True)
        response_dict['message'] = ["Successfully processed dlis file"]
        #print(response_dict)
        resp = jsonify(response_dict)
        #print("============================================")
        resp.status_code = 201
    except Exception as ex:
        resp = jsonify({'message': ex})
        resp.status_code = 400

    return resp

@app.route('/upload-dlis', methods=['GET', 'POST'])
def upload_dlis():

    # check if the post request has the file part
    if 'file' not in request.files:
        resp = jsonify({'message': 'No file part in the request'})
        resp.status_code = 400
        return resp
    file = request.files['file']
    if file.filename == '':
        resp = jsonify({'message': 'No file selected for uploading'})
        resp.status_code = 400
        return resp
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        resp = jsonify({'message': 'File successfully uploaded', 'file_path': file_path})
        resp.status_code = 201
        return resp
    else:
        resp = jsonify({'message': 'Allowed file types are txt, pdf, png, jpg, jpeg, gif'})
        resp.status_code = 400
        return resp


if __name__ == "__main__":
    main(sys.argv[1:])
