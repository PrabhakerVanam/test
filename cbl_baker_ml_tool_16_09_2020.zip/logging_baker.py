# logging_baker.py

import logging
import logging.config

# create logger
logging.config.fileConfig(fname='./config/log4py.properties', disable_existing_loggers=True)

# Get the logger specified in the file
logger = logging.getLogger('BakerLogger')

