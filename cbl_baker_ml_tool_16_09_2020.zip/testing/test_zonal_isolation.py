import pandas as pd

cemtnt_qc_file = ".\data\BAB_BB1092101H_ATLAS_00001_7NEW_0_250000B0_(7206.5, 10479.0)_cement_quality_data.csv"
final_flags_file = ".\data\BAB_BB1092101H_ATLAS_00001_7NEW_0_250000B0_(7206.5, 10479.0)_final_flag_data.csv"
zones_info_file = ".\data\BAB_BB1092101H_ATLAS_00001_7NEW_0_250000B0_zone_info_from_db_data.csv"

df_cement_qc = pd.read_csv(final_flags_file)
df_zone_info = pd.read_csv(zones_info_file)

print(df_cement_qc.head(5))
print(df_zone_info.head(5))

# [['UWI', 'UBHI', 'LAYER_NAME', 'LAYER_TYPE', 'TOP', 'BASE']]
df_dense_zones = df_zone_info.query(" LAYER_TYPE == 'ZONE DENSE' ")
print(df_dense_zones.head(5))

df_dense_zones_result = df_dense_zones.copy()
df_dense_zones_result['Thickness(ft)'] = df_dense_zones['BASE'] - df_dense_zones['TOP']
df_dense_zones_result['Zonal Isolation'] = None

top_dense_depths = list(df_dense_zones['TOP'].values)
base_dense_depths = list(df_dense_zones['BASE'].values)
zonal_isolation_list = []
depth_intervel = .25

for dense_start_dept, dense_end_dept in zip(top_dense_depths, base_dense_depths):  
    
    print(f"Dense start & end : {dense_start_dept}, {dense_end_dept}")
    dence_depth = dense_end_dept - dense_start_dept
    # consider expected good quality same as dense depth if it is <= 10 , else 10% of the dense depth
    expected_good_qc_depth = dence_depth if dence_depth <= 10 else 0.1 * dence_depth
    print(f"expected_good_qc_depth : {expected_good_qc_depth}")
    
    # get records from cement quality dataframe based inon TOP and BASE Depth of the Zone
    
    df_zone_cement_qc = df_cement_qc.query(f"TDEP >= {dense_start_dept} & TDEP <= {dense_end_dept}")[['TDEP', 'FINAL_FLAG']]
    
    print(df_zone_cement_qc.head(5))
    
    dept_range = list(df_zone_cement_qc['TDEP'].values)
    good_qc_sum = 0
    zonal_isolation = 'Not Confirmed'
    for row in df_zone_cement_qc.itertuples(index=False):
        #print(row)
        if row[1] in [3, 4, 5] :
            good_qc_sum = good_qc_sum + depth_intervel 
            print(f"Cummilative sum :{ good_qc_sum}")
            if good_qc_sum >= int(expected_good_qc_depth):
                
                zonal_isolation = 'Confirmed'
                break
            
        else:
            good_qc_sum = 0    
    
    print(f'dzonal_isolation: {zonal_isolation}')

    zonal_isolation_list.append(zonal_isolation)

df_dense_zones_result['Zonal Isolation'] = zonal_isolation_list

print(df_dense_zones_result.head(5))
