import pandas as pd
import numpy as np

from sklearn.metrics import confusion_matrix, classification_report
from sklearn.ensemble import RandomForestClassifier
from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const

from aon.dlis.io import plot_cement_bond_log as plot_cbl
from aon.dlis.model import cbl_model_helper as ml_helper
from aon.dlis.io import data_reader as reader
import os

bi_data_file = os.path.join(io_const.BASE_DATA_DIR,"BAB-BB14591101H-ATLAS-['00001_MAIN_PRESSURE']-0_500000B0-(22675, 18).csv")
df_bi = pd.read_csv(bi_data_file)

atten_df = df_bi.copy()
atten_chan_name='ATAV.I'
casing9_min = 0
casing9_max = 7250
casing7_min = 6950
casing7_max = 11520
free_pipe_atten_9 = 2.57999992
free_pipe_atten_7  =0
hi_cutoff_9  = 8.75300026
hi_cutoff_7 =0

df = reader.bond_index_calculation(atten_df, atten_chan_name, casing9_min, casing9_max,
                    casing7_min, casing7_max, free_pipe_atten_9, free_pipe_atten_7, hi_cutoff_9, hi_cutoff_7)
print(df)
bi_plot_path = os.path.join(io_const.PLOTS_DIR, 'BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_bi_plot.png')
plot_cbl.plot_bond_index(df[io_const.BI_COLUMN].values.reshape(-1, 1), df[io_const.TDEP_COLUMN].min(), df[io_const.TDEP_COLUMN].max(),bi_plot_path)


