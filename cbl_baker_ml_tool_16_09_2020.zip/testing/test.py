# -*- coding: utf-8 -*-
"""
Created on Fri Jul 31 21:32:13 2020

@author: ad1006362
"""
import pandas as pd

from aon.dlis.io import io_constants as io_const

unit_depth = 0.25

print("Generating Final Cement Quality...")

source_file_ccl = ".\data\\BB1008_df_calculated_ccl_(2819.75, 9194.5).csv"

source_file_final_flags = ".\data\\BB1008_final_flags_(2819.75, 9194.5).csv"

df_calculated_ccl = pd.read_csv(source_file_ccl)
df_final_foags = pd.read_csv(source_file_final_flags)


print(df_calculated_ccl.index)
print(df_final_foags.index)

df_data = pd.merge(df_final_foags, df_calculated_ccl, on=io_const.TDEP_COLUMN)
# df_data = pd.concat([df_final_foags, df_ccl.reindex(df_final_foags.index)], axis=1)
print(df_data)

final_flag_shift_col = io_const.FINAL_FLAG_COLUMN + '_S'
final_flag_changed_col = io_const.FINAL_FLAG_COLUMN + '_CHANGED'
tdep_shift_col = io_const.TDEP_COLUMN + '_SHIFT'
tdep_diff_col = io_const.TDEP_COLUMN + '_DIFF'
# cutoff = io_const.FINAL_CEMENT_QUALITY_CUTOFF

df_data[tdep_shift_col] = df_data[io_const.TDEP_COLUMN].shift(1)

data_filtered = df_data.query(io_const.CCL_TICK_COL + " == 1")[
[io_const.TDEP_COLUMN, io_const.CCL_TICK_COL, io_const.FINAL_FLAG_COLUMN, tdep_shift_col]]

print("data_filtered ", data_filtered)

#last_depth = data_filtered.iloc[-1][data_filtered.columns.get_loc(io_const.TDEP_COLUMN)]
last_depth = max(data_filtered[io_const.TDEP_COLUMN])

# rearrange the final flag merge 0,1,2 to single 0
flag_dict = {0: 0, 1: 0, 2: 0, 3: 3, 4: 4, 5: 5}

quality_dict = {0: 'Poor', 3: 'Moderate', 4: 'Fast Formation', 5: 'Good'}
print("DebugLine2")
data_filtered[io_const.FINAL_FLAG_COLUMN] = data_filtered[io_const.FINAL_FLAG_COLUMN].map(flag_dict)

data_filtered[final_flag_shift_col] = data_filtered[io_const.FINAL_FLAG_COLUMN].shift(1)

#data_filtered[tdep_shift_col] = data_filtered[io_const.TDEP_COLUMN].shift(1)
print("DebugLine3")
data_filtered[final_flag_changed_col] = data_filtered[io_const.FINAL_FLAG_COLUMN] != data_filtered[
final_flag_shift_col]
print("DebugLine4")
data_filtered_true = data_filtered.query(final_flag_changed_col + " == True")[
[io_const.TDEP_COLUMN, io_const.FINAL_FLAG_COLUMN, final_flag_changed_col, tdep_shift_col]]
print("DebugLine5")
data_filtered_true[tdep_shift_col] = data_filtered_true[tdep_shift_col].shift(-1)
print("DebugLine6")
data_filtered_true[io_const.FINAL_FLAG_COLUMN] = data_filtered_true[io_const.FINAL_FLAG_COLUMN].map(
quality_dict)
print("DebugLine7")
data_filtered_true.reset_index(inplace=True, drop=True)
print("DebugLine8")
# Add last depth value at NAN position/cell
data_filtered_true.loc[data_filtered_true.shape[0] - 1, tdep_shift_col] = last_depth
print("DebugLine9")
# commented adding unit depth as its matching - Not Required
data_filtered_true[tdep_shift_col] = data_filtered_true[tdep_shift_col] + unit_depth

data_filtered_true[tdep_diff_col] = data_filtered_true[tdep_shift_col] - data_filtered_true[
io_const.TDEP_COLUMN]
print("DebugLine10")
data_filtered_true = data_filtered_true[
[io_const.TDEP_COLUMN, tdep_shift_col, io_const.FINAL_FLAG_COLUMN, tdep_diff_col]]
print("DebugLine11")
# data_cement_quality = data_filtered_true.query(tdep_diff_col + " >@io_const.FINAL_CEMENT_QUALITY_CUTOFF")[
#     [io_const.TDEP_COLUMN, tdep_shift_col, io_const.FINAL_FLAG_COLUMN, tdep_diff_col]].sort_values(
#     by=[io_const.TDEP_COLUMN], ascending=True).dropna(how='any')
#
#
# # merge all continues datavalues to display start_depth and end_depth
# previous_flag =None
# current_flag = ''
# start_depth = ''
# end_depth =''
#
# data_cement_quality_aggr=pd.DataFrame(columns=data_cement_quality.columns)
#
# for row in data_cement_quality.itertuples(index=False):
#     #print(row)
#     if previous_flag == None:
#         previous_flag = row[2]
#         current_flag = row[2]
#         start_depth = row[0]
#
#     current_flag =  row[2]
#     if previous_flag != current_flag:
#         to_append = [start_depth, end_depth, previous_flag, (end_depth-start_depth)]
#         #print(to_append)
#         df_length = len(data_cement_quality_aggr)
#         data_cement_quality_aggr.loc[df_length] = to_append
#         start_depth = row[0]
#         end_depth = row[1]
#     else:
#         end_depth = row[1]
#
#     previous_flag = current_flag
#
# return data_cement_quality_aggr
