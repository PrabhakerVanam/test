'''
Test Class for Expris Database for Zones
'''
import aon.dlis.db.db_connection_prop as db_prop
import aon.dlis.db.expris_connection as expris
import pandas as pd

exp_db = expris.ExprisDatabase(db_prop.DB_SERVER_NAME,db_prop.DB_PORT_NUMBER,db_prop.DB_SERVICE_NAME, db_prop.DB_USER, db_prop.DB_PWD)
conn = exp_db.connect_db()
well_number = 'BB0589101H'

#query = f"select DISTINCT(LAYER_NAME), UWI, SUBSTR(UBHI, 0, 6) UBHI, LAYER_TYPE, TOP, BASE from ep_well_marker_zn2 where UBHI like '{well_number}%'"
#query = f"select DISTINCT(LAYER_NAME), LAYER_TYPE, UWI, SUBSTR(UBHI, 0, 6) UBHI, TOP, BASE, TOP_TVDSS, BASE_TVDSS, APPARENT_THICKNESS from ep_well_marker where LAYER_TYPE='ZONE' and UBHI like '{well_number}%'"
query = f"select DISTINCT(LAYER_NAME), LAYER_TYPE, UWI, SUBSTR(UBHI, 0, 6) UBHI, TOP, BASE, TOP_TVDSS, BASE_TVDSS, APPARENT_THICKNESS from ep_well_marker where UBHI like '{well_number}%'"

df_zones = pd.read_sql(query, con=conn)
cur = exp_db.execute_query(conn, query)

exp_db.release(conn)

print(df_zones.head(50))



# cur = exp_db.execute_query(conn, query)
# for row in cur:
#     print(row[0], row[1], row[2], row[3], row[4], row[5])
# exp_db.release(conn)
