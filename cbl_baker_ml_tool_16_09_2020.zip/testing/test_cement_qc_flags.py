import numpy as np
import pandas as pd

source_file = "..\data\\BAB_BB1008_ATLAS_00002_GRFINAL_0_250000B0_(2819.75, 9194.5)_ccl_and_final_flag_data.csv"

data = pd.read_csv(source_file)

data.head()

tdep_channel_name = "TDEP"
ccl_tick_col = 'CCL_TICK'
final_flag_col = 'FINAL_FLAG'
final_flag_shift_col = 'FINAL_FLAG_S'
final_flag_changed_col = 'FINAL_FLAG_CHANGED'
tdep_shift_col = 'TDEP_SHIFT'
tdep_diff_col = 'TDEP_DIFF'
cutoff = 4
unit_depth=data.iloc[1][0] - data.iloc[0][0]


last_depth = max(data[tdep_channel_name])

#data_filtered = data.query(ccl_tick_col + " == 1")[[tdep_channel_name, ccl_tick_col, final_flag_col]]

data_filtered = data[[tdep_channel_name, ccl_tick_col, final_flag_col]]

# rearrange the final flag merge 0,1,2 to single 0
flag_dict = {
        0:0,
        1:0,
        2:0,
        3:3,
        4:4,
        5:5
        }

quality_dict = {
        0:'Poor',     
        3:'Modarate',
        4:'Fast Formation',
        5:'Good'
        }

data_filtered[final_flag_col] = data_filtered[final_flag_col].map(flag_dict)

data_filtered[final_flag_shift_col]= data_filtered[final_flag_col].shift(1)

# new
data_filtered[tdep_shift_col]= data_filtered[tdep_channel_name].shift(1)

data_filtered[final_flag_changed_col]= data_filtered[final_flag_col] != data_filtered[final_flag_shift_col]

data_filtered_true = data_filtered.query(final_flag_changed_col + " == True")[[tdep_channel_name, final_flag_col, final_flag_changed_col, tdep_shift_col]]

data_filtered_true[tdep_shift_col] = data_filtered_true[tdep_shift_col].shift(-1)


data_filtered_true[final_flag_col] = data_filtered_true[final_flag_col].map(quality_dict)
data_filtered_true.columns

data_filtered_true.reset_index(inplace=True, drop=True)

# Commented

data_filtered_true.loc[data_filtered_true.shape[0]-1, tdep_shift_col] =last_depth

data_filtered_true[tdep_shift_col] = data_filtered_true[tdep_shift_col] + unit_depth

data_filtered_true[tdep_diff_col] = data_filtered_true[tdep_shift_col] - data_filtered_true[tdep_channel_name] 

data_filtered_true = data_filtered_true[[tdep_channel_name,tdep_shift_col,final_flag_col, tdep_diff_col]]

data_filtered_true.to_csv('BAB_BB1008_ATLAS_00002_GRFINAL_0_250000B0_(2819.75, 9194.5)_quality.csv', index=False)



