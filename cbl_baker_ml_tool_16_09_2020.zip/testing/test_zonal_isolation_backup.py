import pandas as pd

# cemtnt_qc_file = ".\data\BAB_BB1092101H_ATLAS_00001_7NEW_0_250000B0_(7206.5, 10479.0)_cement_quality_data.csv"
# zones_info_file = ".\data\BAB_BB1092101H_ATLAS_00001_7NEW_0_250000B0_zone_info_from_db_data.csv"

cemtnt_qc_file = ".\data\BAB_BB1074_ATLAS_00005_N331DS_0_250000B0_(25.25, 11220.5)_cement_quality_data.csv"
zones_info_file = ".\data\BAB_BB1074_ATLAS_00005_N331DS_0_250000B0_zone_info_from_db_data.csv"


df_cement_qc = pd.read_csv(cemtnt_qc_file)
df_zone_info = pd.read_csv(zones_info_file)

print(df_cement_qc.head(5))
print(df_zone_info.head(5))

# mark poor and remaing as differ class
df_cement_qc['qc_class'] = df_cement_qc.apply(lambda x: 0 if x.FINAL_FLAG == 'Poor' else 1, axis=1)
df_cement_qc['qc_class_shift'] = df_cement_qc['qc_class'].shift(1)

# mark last row last column (qc_class_shift) 0 if it is 1, else 1
df_cement_qc.iloc[-1,-1] = 0 if df_cement_qc.iloc[-1,-1]==1 else 1

# markfirst row last column (qc_class_shift) 
df_cement_qc.iloc[0,-1] = 0 if  df_cement_qc.iloc[1,-1] == 1 else 1
#df_cement_qc['qc_class_shift'].fillna(value=0, inplace=True)

# filter columns qc_class & qc_class_shift which are not equal
df_cement_qc.query(" qc_class != qc_class_shift ", inplace=True)

df_cement_qc['TDEP_END'] = df_cement_qc['TDEP'].shift(-1)

# remove first record as nan is not required
df_cement_qc.dropna(inplace=True)

# re calculate difference
df_cement_qc['TDEP_DIFF'] = df_cement_qc['TDEP_END'] - df_cement_qc['TDEP']

# filter dataframe with non poor value
df_cement_qc = df_cement_qc.query(" qc_class == 1 ")[['TDEP', 'TDEP_END', 'TDEP_DIFF', 'FINAL_FLAG']]

# [['UWI', 'UBHI', 'LAYER_NAME', 'LAYER_TYPE', 'TOP', 'BASE']]

df_dense_zones = df_zone_info.query(" LAYER_TYPE == 'ZONE DENSE' ")


df_dense_zones_result = df_dense_zones.copy()
df_dense_zones_result['Thickness(ft)'] = df_dense_zones['BASE'] - df_dense_zones['TOP']
df_dense_zones_result['Zonal Isolation'] = None

top_dense_depths = list(df_dense_zones['TOP'].values)
base_dense_depths = list(df_dense_zones['BASE'].values)
zonal_isolation_list = []

for start_dept, end_dept in zip(top_dense_depths, base_dense_depths):

    dence_depth = end_dept - start_dept
    # consider expected good quality same as dense depth if it is <= 10 , else 10% of the dense depth
    expected_good_qc_depth = dence_depth if dence_depth <= 10 else 0.1 * dence_depth
    print(expected_good_qc_depth)

    # dense start_depth + expected good qc  <= TDEP_END
    # df_cement_dense1 = df_cement_qc.query(
    #     f"TDEP_END - {expected_good_qc_depth} >= {start_dept} & ( TDEP_END >= {end_dept} | TDEP + {expected_good_qc_depth} <= {start_dept})")
    df_cement_dense1 = df_cement_qc.query(
        f"TDEP_END - {expected_good_qc_depth} >= {start_dept} & ( TDEP_END >= {end_dept} )")
  
    print(df_cement_dense1.head(5))
    # (df_cement_dense1['TDEP_DIFF'] >= expected_good_qc_depth)
    print(df_cement_dense1['TDEP_DIFF'].max())

    if df_cement_dense1['TDEP_DIFF'].max() >= expected_good_qc_depth:
        zonal_isolation = 'Confirmed'
    else:
        zonal_isolation = 'Not Confirmed'

    print(f'zonal_isolation: {zonal_isolation}')

    zonal_isolation_list.append(zonal_isolation)

df_dense_zones_result['Zonal Isolation'] = zonal_isolation_list

print(df_dense_zones_result.head(5))
