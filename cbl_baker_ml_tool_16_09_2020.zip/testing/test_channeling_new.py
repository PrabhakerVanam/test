# -*- coding: utf-8 -*-
"""
Created on Thu Sep  3 09:03:10 2020

@author: ad1006362
"""

import pandas as pd

import numpy as np

from aon.dlis.io import io_constants as io_const

final_flags_file = ".\data\BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_final_flag_data.csv"
cemo_file = ".\data\BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_cemo_data.csv"

df_final_flag = pd.read_csv(final_flags_file)
df_cemo = pd.read_csv(cemo_file)

print(df_final_flag.head(5))
print(df_cemo.head(5))

unit_depth = 0.5
df_cemo.columns
df_cemo[io_const.ROW_MIN_COLUMN] = (df_cemo.iloc[:,1:-1].min(axis=1))

df_cemo[io_const.CHANNELLING_COLUMN] = df_cemo.apply(lambda x: True if x[io_const.ROW_MIN_COLUMN] <= io_const.CHANNELLING_CUTOFF_VALUE else False, axis=1)
#print(df_cemo[[io_const.CHANNELLING_COLUMN]].query(io_const.CHANNELLING_COLUMN + "<= 20"))
df_channelling = df_cemo.drop(columns=['Unnamed: 0'])

df_channelling.columns

df_final_flag.columns

# Merge dataframe based on TDEP
df_channelling = df_channelling.merge(df_final_flag[['CCB', 'FREE_PIPE', 'FINAL_FLAG', 'TDEP']], on=io_const.TDEP_COLUMN)
# df_channelling[io_const.FINAL_FLAG_COLUMN] = df_final_flag[io_const.FINAL_FLAG_COLUMN]
print("df_channelling merged with final flags \n", df_channelling.head(5))

# Before filtering the channelling colums, shift TDEP into new column to preserve the next index value
df_channelling[io_const.TDEP_SHIFT_FOR_BASE_COLUMN] = df_channelling[io_const.TDEP_COLUMN].shift(-1)
print("df_channelling after TDEP shift \n", df_channelling.head(5))

# Filter data based on channelling flag (columns with min value <= 20)
df_channelling_true = df_channelling.query(io_const.CHANNELLING_COLUMN + "== True")
print("df_channelling_true\n", df_channelling_true.head(5))

 # Filter data further based on final flag
df_channelling_true_filtered = df_channelling_true[df_channelling_true[io_const.FINAL_FLAG_COLUMN] == 3]
print("df_channelling_true_filtered\n", df_channelling_true_filtered.head(5))

df_channelling_true_filtered.set_index(io_const.TDEP_COLUMN, drop=True, inplace=True)

column_list = df_channelling_true_filtered.columns

column_list = [i for i in column_list if i.startswith('C_')]

# Select only columns which are required
df_channelling_cemo = df_channelling_true_filtered[column_list]

# convert it into binary
for column in column_list:
    df_channelling_cemo[column] = df_channelling_cemo[column].apply(lambda x:1 if x> io_const.CHANNELLING_CUTOFF_VALUE else 0)

def zero_runs(a):
    # Create an array that is 1 where a is 0, and pad each end with an extra 0.
    iszero = np.concatenate(([0], np.equal(a, 0).view(np.int8), [0]))
    absdiff = np.abs(np.diff(iszero))
    # Runs start and end where absdiff is 1.
    ranges = np.where(absdiff == 1)[0].reshape(-1, 2)
    return ranges

index_depth = df_channelling_cemo.index
channelling_cemo_array = df_channelling_cemo.to_numpy()

for depth in df_channelling_cemo.index:
    idx = df_channelling_cemo.index.get_loc(depth)
    row = channelling_cemo_array[idx]
    runs = zero_runs(row)    
    print(depth, runs)

