# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 22:06:40 2020

@author: ad1006362
"""

import pandas as pd
import numpy as np

from sklearn.metrics import confusion_matrix, classification_report
from sklearn.ensemble import RandomForestClassifier
from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const

from aon.dlis.io import plot_cement_bond_log as plot_cbl
from aon.dlis.model import cbl_model_helper as ml_helper
import os
# load the dataset
#Cement Classification flag (1-Good, 2-Moderate, 3-Poor) - SQF
ccb_training_file = os.path.join(io_const.TRAINING_DATA_DIR, io_const.CCB_TRAINING_DATA_CSV)
df_ccb = pd.read_csv(ccb_training_file)

fp_training_file = os.path.join(io_const.TRAINING_DATA_DIR, io_const.FREE_PIPE_TRAINING_DATA_CSV)
df_fp = pd.read_csv(fp_training_file)
#print(Welltest)
df_ccb.columns

print(df_fp.columns)

rename_col_dict = {'TDEP, ft':'TDEP', 'AMAV.I, mV':'AMAV', 'ATAV.I, dB/ft':'ATAV',
       'ATC1.I, dB/ft':'ATC1', 'ATC2.I, dB/ft':'ATC2', 'ATC3.I, dB/ft':'ATC3', 'ATC4.I, dB/ft':'ATC4',
       'ATC5.I, dB/ft':'ATC5', 'ATC6.I, dB/ft':'ATC6', 'CCL.I, mV':'CCL', 'DTMN.I, us/ft':'DTMN',
       'DTMX.I, us/ft':'DTMX', 'Cement_flag (CBL)':'CCB'}
df_ccb.rename(columns=rename_col_dict, inplace=True)

df_ccb.columns
feature_names=io_const.ATC_COLUMN_LIST
target_label=['CCB']
df_ccb = df_ccb[df_ccb != -999.25]

df_ccb.dropna(inplace=True)

df_ccb.replace({-9999:0}, inplace=True)

print(df_ccb.head())

n_estimators = 350

conf_matrix , classify_report , accur_score, classifier = ml_helper.build_cbl_cement_to_casing_model(df=df_ccb, feature_names =feature_names, target_label= target_label, n_estimators=n_estimators)

validate_data_file = os.path.join(io_const.OUTPUT_DATA_DIR, 'BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_channel_data.csv')
df_validate = pd.read_csv(validate_data_file)

rename_col_i_dict = {'TDEP':'TDEP', 'AMAV.I':'AMAV', 'ATAV.I':'ATAV',
       'ATC1.I':'ATC1', 'ATC2.I':'ATC2', 'ATC3.I':'ATC3', 'ATC4.I':'ATC4',
       'ATC5.I':'ATC5', 'ATC6.I':'ATC6', 'CCL.I':'CCL', 'DTMN.I':'DTMN',
       'DTMX.I':'DTMX'}
df_validate.rename(columns=rename_col_i_dict, inplace=True)

print(df_validate.columns)
ccb_df = ml_helper.predict_cbl_cement_to_casinge(classifier, df_validate[feature_names].values)

print(ccb_df['CCB'].values.reshape(-1, 1))
ccb_plot_file = os.path.join(io_const.PLOTS_DIR, 'BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_ccb_plot.png')

plot_cbl.plot_cement_quality(ccb_df['CCB'].values.reshape(-1, 1), 126.0, 11463.0, ccb_plot_file)


df_fp.columns
fp_colums = list(df_fp.columns)
print(fp_colums)
feature_col_start_idx = 29
feature_col_end_idx = 140
target_label_idx = 1

print(feature_names)
print(target_label)
df_fp = df_fp[df_fp != -999.25]

df_fp.dropna(inplace=True)

df_fp.replace({-9999:0}, inplace=True)

print(df_fp.head())

n_estimators = 350

conf_matrix, classify_report, accur_score, classifier = ml_helper.build_cbl_free_pipe_model(df_free_pipe=df_fp, \
                                                                                            feature_col_start_idx=29,\
                                                                                            feature_col_end_idx = 140,\
                                                                                            target_label_idx=target_label_idx, \
                                                                                            n_estimators=n_estimators)

validate_data_file = os.path.join(io_const.BASE_DATA_DIR, 'validation\\bb1459_wave_data.csv')
df_validate = pd.read_csv(validate_data_file)
print(df_validate.columns)
df_fp = ml_helper.predict_cbl_free_pipe(classifier, df_validate.iloc[:,feature_col_start_idx:feature_col_end_idx].values)

print(df_fp[io_const.FREE_PIPE_COLUMN].values.reshape(-1, 1))
fp_plot_file = os.path.join(io_const.PLOTS_DIR, 'BB1459_(126.0, 11463.0)_fp_plot.png')

plot_cbl.plot_free_pipe(df_fp[io_const.FREE_PIPE_COLUMN].values.reshape(-1, 1), 126.0, 11463.0, fp_plot_file)

print(df_fp.head())

