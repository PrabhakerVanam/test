

import pandas as pd

import numpy as np

free_pipe_atten_from_header_9 = 2.57999992
free_pipe_atten_from_header_7 = 2.12345456

top_dept_9 = 0.0
bottom_depth_9 = 7250.0
top_dept_7 = 6950.0

bottom_depth_7 = 11445.0


data_file = ".\data\BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_data.csv"
final_flag_file = ".\data\BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_final_flag_data.csv"

data = pd.read_csv(data_file)
df_final_flags = pd.read_csv(final_flag_file)


df_final_flags_filtered = df_final_flags.query("(CCB == 3 or CCB == 2) and FREE_PIPE == 1")[['TDEP', 'CCB', 'FREE_PIPE'] ]


df_final_flags_atav = df_final_flags_filtered.merge(data[['TDEP', 'ATAV.I']], on='TDEP')

# drop invalid rows
df_final_flags_atav = df_final_flags_atav[df_final_flags_atav['ATAV.I'] != -999.25]

df_final_flags_atav.set_index('TDEP', drop=True, inplace=True)

df_final_flags_atav_9 = df_final_flags_atav.loc[int(top_dept_9): int(bottom_depth_9),:]

df_final_flags_atav_7 = df_final_flags_atav.loc[int(top_dept_7): int(bottom_depth_7),:]

free_pipe_attenuation_9_avg = np.average(df_final_flags_atav_9['ATAV.I'])

free_pipe_attenuation_7_avg = np.average(df_final_flags_atav_7['ATAV.I'])

tool_calibration_error_9 = abs(free_pipe_attenuation_9_avg - free_pipe_atten_from_header_9)

tool_calibration_error_7 = abs(free_pipe_attenuation_7_avg - free_pipe_atten_from_header_7)

if tool_calibration_error_9 > 1:
    print("Identified tool calibration error for 9.5\". Data needs to be normalized before plotting....")
else:
    print("Normalization not required for 9.5\" ")


if tool_calibration_error_7 > 1:
    print("Identified tool calibration error for 7\". Data needs to be normalized before plotting....")
else:
    print("Normalization not required  for 7\" ")
