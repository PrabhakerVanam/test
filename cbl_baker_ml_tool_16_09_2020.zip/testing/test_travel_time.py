import numpy as np
import pandas as pd

source_file = "D:\\Prabhaker\\Data Science\\Cement Evaluation\\cbl_baker_ml_tool\data\\tdep-dtmnmx.xlsx"

data = pd.read_excel(source_file, sheet_name='Sheet2')
data1 = pd.read_excel(source_file, sheet_name='Sheet3')

data.head()

dtmn_channel_name = "DTMN"
dtmx_channel_name = "DTMX"
tdep_channel_name = "TDEP"
ccl_tick_col = 'CCL_TICK'
ccl_tick_shift_col = 'CCL_SHIFT_TICK'
ccl_start_dept_col = "CCL_START_DEPT"
ccl_end_dept_col = "CCL_END_DEPT"
tdep_shift_col = 'TDEP_SHIFT'
ccl_dept_marker_col ='CCL_DEPT_MARKER'
ccl_dept_diff_col = 'TDEP_DIFF'

data = data[data[dtmn_channel_name] != -999.25]
data.reset_index(inplace=True, drop=True)

tdept_diff = data[tdep_channel_name][1] - data[tdep_channel_name][0]
cutoff = 4

data[ccl_tick_col] = data[[dtmn_channel_name, dtmx_channel_name]].apply(
    lambda x: 0 if (x[dtmx_channel_name] - x[dtmn_channel_name]) > (0.1 * x[dtmn_channel_name]) else 1, axis=1)

# data_ccf= data.query("CCL_IDF == 0")[[tdep_channel_name,ccl_idf]]
data_ccf = data.copy()

data_ccf[tdep_shift_col] = data_ccf[tdep_channel_name].shift(-1)

data_ccf[ccl_tick_shift_col] = data_ccf[ccl_tick_col].shift(-1)

data_ccf[ccl_dept_marker_col] = data_ccf[[tdep_channel_name, ccl_tick_col, ccl_tick_shift_col]].apply(
    lambda x: '00' if x[ccl_tick_col] == x[ccl_tick_shift_col] and x[ccl_tick_col] == 0 else (
        '01' if x[ccl_tick_col] != x[ccl_tick_shift_col] and x[ccl_tick_col] == 0 else (
            '10' if x[ccl_tick_col] != x[ccl_tick_shift_col] and x[ccl_tick_col] == 1 else '11')), axis=1)

data_ccf_selected = data_ccf.query(ccl_dept_marker_col + " == '10' or " + ccl_dept_marker_col + " == '01' ")[[tdep_shift_col, ccl_dept_marker_col]]

#data_ccf_selected['TICK_SHIFT'] = data_ccf['TDEP_END'].shift(-1)

data_ccf_pivot = data_ccf_selected.pivot(columns=ccl_dept_marker_col, values=[tdep_shift_col])
data_ccf_pivot.columns

data_ccf_pivot1 = data_ccf_pivot.copy()

#data_ccf_pivot1.iloc[:,1]
#data_ccf_pivot1.iloc[:,0]

df_ccf_new = pd.DataFrame({ccl_start_dept_col: data_ccf_pivot1.iloc[:, 1], ccl_end_dept_col: data_ccf_pivot1.iloc[:, 0]})

df_ccf_new[ccl_end_dept_col] = df_ccf_new[[ccl_end_dept_col]].shift(-1)
df_ccf_new.dropna(inplace=True)

df_ccf_new[ccl_dept_diff_col] = df_ccf_new[ccl_end_dept_col] - df_ccf_new[ccl_start_dept_col]

df_ccf_new[ccl_end_dept_col] = df_ccf_new[ccl_end_dept_col] - tdept_diff

data_ccl_anomoly = df_ccf_new.query(ccl_dept_diff_col + " >@cutoff")[[ccl_start_dept_col, ccl_end_dept_col, ccl_dept_diff_col]].sort_values(
    by=[ccl_start_dept_col], ascending=True).dropna(how='any')

