# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains data structures/classes to support 
object-oriented approach of data input/output and model building 
functionality.

@author: Prabhaker Reddy Vanam
"""


class LogicalFile(property):
    """The class aon.dlis.io.data_structures.LogicalFile provides data
    structure for storing well log header/parameters and other related information.

    The class is initialized with WellHeader(field_name, well_name, producer_name, set_name, frame_name)
    Class constructor has following parameters:
        :param field_name: Field Name
        :param well_name: Well Name
        :param producer_name: Producer Name
        :param set_name: Logical File Set Name
        :param frame_name: Frame name in the logical File

    Attributes
    ----------

    Additionally, this class has following attributes:
        * date_time: list of dates and times of data collection
        * cum_date_time: list of dates and times of cum. prod. data collection
        * drainage_radius: drainage radius of the well
        * well_zones: list of adnoc.wellopt.io.data_structures.WellZone objetcs
        TODO
    """

    def __init__(self, field_name=None, well_name=None, producer_name=None, set_name=None, frame_name=None):

        self.logical_file_key = None
        self.field_name = field_name
        self.well_name = well_name
        self.producer_name = producer_name
        self.set_name = set_name
        self.frame_name = frame_name
        self.casing18_min = 0.0
        self.casing18_max = 0.0
        self.casing13_min = 0.0
        self.casing13_max = 0.0
        self.casing9_min = 0.0
        self.casing9_max = 0.0
        self.casing7_min = 0.0
        self.casing7_max = 0.0
        self.max_depth = 0.0
        self.min_depth = 0.0
        self.unit_depth = 0.25
        self.free_pipe_atten_9 = 0.0
        self.free_pipe_atten_7 = 0.0
        self.span_9 = 0.0
        self.span_7 = 0.0
        self.atten_max_9 = 0.0
        self.atten_max_7 = 0.0
        self.free_pipe_atten_calc_9 = 0.0
        self.free_pipe_atten_calc_7 = 0.0
        self.hi_cutoff_9 = 0.0
        self.hi_cutoff_7 = 0.0
        self.tool_calibration_error_9 = 0.0
        self.tool_calibration_error_7 = 0.0
        self.correction_factor_9 = 1.0
        self.correction_factor_7 = 1.0
        self.channel_list = []
        self.duplicate_channel_list = []
        self.tool_calibration_error_msg_9=""
        self.tool_calibration_error_msg_7=""
        self.zonal_isolation_at_acquifer_msg = ""
        self.zonal_isolation_at_target_reservoir = ""

    # Getter and setter for logical_file_key.
    # @property
    def logical_file_key(self):
        return self.logical_file_key if (None != self.logical_file_key) else f"{self.field_name}_{self.well_name}_{self.producer_name}_{self.set_name}_{self.frame_name}"

    # @logical_file_key.setter
    def logical_file_key(self, n_logical_file_key):
        self.logical_file_key = n_logical_file_key

    # Getter and setter for field_name.
    # @property
    def field_name(self):
        return self.field_name

    # @field_name.setter
    def field_name(self, n_field_name):
        self.field_name = n_field_name

    # And the getter and setter for well_name.
    # @property
    def well_name(self):
        return self.well_name

    # @well_name.setter
    def well_name(self, n_well_name):
        self.well_name = n_well_name

    # And the getter and setter for producer_name.
    # @property
    def producer_name(self):
        return self.producer_name

    # @producer_name.setter
    def producer_name(self, n_producer_name):
        self.producer_name = n_producer_name

    # And the getter and setter for set_name.
    # @property
    def set_name(self):
        return self.set_name

    # @set_name.setter
    def set_name(self, n_set_name):
        self.set_name = n_set_name

    # And the getter and setter for frame_name.
    # @property
    def frame_name(self):
        return self.frame_name

    # @frame_name.setter
    def frame_name(self, n_frame_name):
        self.frame_name = n_frame_name

    # And the getter and setter for casing18_min.
    # @property

    def casing18_min(self):
        return self.casing18_min

    # @casing18_min.setter
    def casing18_min(self, n_casing18_min):
        self.casing18_min = float(n_casing18_min)

    # And the getter and setter for casing18_max.
    # @property
    def casing18_max(self):
        return self.casing18_max

    # @casing18_max.setter
    def casing18_max(self, n_casing18_max):
        self.casing18_max = float(n_casing18_max)

    # And the getter and setter for casing13_min.
    # @property
    def casing13_min(self):
        return self.casing13_min

    # @casing13_min.setter
    def casing13_min(self, n_casing13_min):
        self.casing13_min = float(n_casing13_min)

    # And the getter and setter for casing9_max.
    # @property
    def casing13_max(self):
        return self.casing13_max

    # @casing13_max.setter
    def casing13_max(self, n_casing13_max):
        self.casing13_max = float(n_casing13_max)

    # And the getter and setter for casing9_min.
    # @property
    def casing9_min(self):
        return self.casing9_min

    # @casing9_min.setter
    def casing9_min(self, n_casing9_min):
        self.casing9_min = float(n_casing9_min)

    # And the getter and setter for casing9_max.
    # @property
    def casing9_max(self):
        return self.casing9_max

    # @casing9_max.setter
    def casing9_max(self, n_casing9_max):
        self.casing9_max = float(n_casing9_max)

    # And the getter and setter for casing7_min.
    # @property
    def casing7_min(self):
        return self.casing7_min

    # @casing7_min.setter
    def casing7_min(self, n_casing7_min):
        self.casing7_min = float(n_casing7_min)

    # And the getter and setter for casing7_max.
    # @property
    def casing7_max(self):
        return self.casing7_max

    # @casing7_max.setter
    def casing7_max(self, n_casing7_max):
        self.casing7_max = float(n_casing7_max)

    # And the getter and setter for min_depth.
    # @property
    def min_depth(self):
        return self.min_depth

    # @min_depth.setter
    def min_depth(self, n_min_depth):
        self.min_depth = float(n_min_depth)

    # And the getter and setter for max_depth.
    # @property
    def max_depth(self):
        return self.max_depth

    # @max_depth.setter
    def max_depth(self, n_max_depth):
        self.max_depth = float(n_max_depth)

    # And the getter and setter for unit_depth.
    # @property
    def unit_depth(self):
        return self.unit_depth

    # @unit_depth.setter
    def unit_depth(self, n_unit_depth):
        self.unit_depth = float(n_unit_depth)

    # And the getter and setter for free_pipe_atten_9.
    # @property
    def free_pipe_atten_9(self):
        return self.free_pipe_atten_9

    # @free_pipe_atten_9.setter
    def free_pipe_atten_9(self, n_free_pipe_atten_9):
        self.free_pipe_atten_9 = float(n_free_pipe_atten_9)

    # And the getter and setter for free_pipe_atten_7.
    # @property
    def free_pipe_atten_7(self):
        return self.free_pipe_atten_7

    # @free_pipe_atten_7.setter
    def free_pipe_atten_7(self, n_free_pipe_atten_7):
        self.free_pipe_atten_7 = float(n_free_pipe_atten_7)

    # And the getter and setter for atten_max_9.
    # @property
    def atten_max_9(self):
        return self.atten_max_9

    # @atten_max_9.setter
    def atten_max_9(self, n_atten_max_9):
        self.atten_max_9 = float(n_atten_max_9)

    # And the getter and setter for atten_max_7.
    # @property
    def atten_max_7(self):
        return self.atten_max_7

    # @atten_max_7.setter
    def atten_max_7(self, n_atten_max_7):
        self.atten_max_7 = float(n_atten_max_7)

    # And the getter and setter for free_pipe_atten_calc_9.
    # @property
    def free_pipe_atten_calc_9(self):
        return self.free_pipe_atten_calc_9

    # @free_pipe_atten_calc_9.setter
    def free_pipe_atten_calc_9(self, n_free_pipe_atten_calc_9):
        self.free_pipe_atten_calc_9 = float(n_free_pipe_atten_calc_9)

    # And the getter and setter for free_pipe_atten_calc_7.
    # @property
    def free_pipe_atten_calc_7(self):
        return self.free_pipe_atten_calc_7

    # @free_pipe_atten_calc_7.setter
    def free_pipe_atten_calc_7(self, n_free_pipe_atten_calc_7):
        self.free_pipe_atten_calc_7 = float(n_free_pipe_atten_calc_7)

    # And the getter and setter for hi_cutoff_9.
    # @property
    def hi_cutoff_9(self):
        return self.hi_cutoff_9

    # @hi_cutoff_9.setter
    def hi_cutoff_9(self, n_hi_cutoff_9):
        self.hi_cutoff_9 = float(n_hi_cutoff_9)

    # And the getter and setter for hi_cutoff_7.
    # @property
    def hi_cutoff_7(self):
        return self.hi_cutoff_7

    # @hi_cutoff_7.setter
    def hi_cutoff_7(self, n_hi_cutoff_7):
        self.hi_cutoff_7 = float(n_hi_cutoff_7)

    # And the getter and setter for span_9.
    # @property
    def span_9(self):
        return self.span_9

    # @span_9.setter
    def span_9(self, n_span_9):
        self.span_9 = float(n_span_9)

    # And the getter and setter for span_7.
    # @property
    def span_7(self):
        return self.hi_cutoff_7

    # @span_7.setter
    def span_7(self, n_span_7):
        self.span_7 = float(n_span_7)

    # And the getter and setter for tool_calibration_error_9.
    # @property
    def tool_calibration_error_9(self):
        return self.tool_calibration_error_9

    # @tool_calibration_error_9.setter
    def tool_calibration_error_9(self, n_tool_calibration_error_9):
        self.tool_calibration_error_9 = float(n_tool_calibration_error_9)

    # And the getter and setter for tool_calibration_error_7.
    # @property
    def tool_calibration_error_7(self):
        return self.tool_calibration_error_7

    # @tool_calibration_error_7.setter
    def tool_calibration_error_7(self, n_tool_calibration_error_7):
        self.tool_calibration_error_7 = float(n_tool_calibration_error_7)

    # And the getter and setter for correction_factor_9.
    # @property
    def correction_factor_9(self):
        return self.correction_factor_9

    # @correction_factor_9.setter
    def correction_factor_9(self, n_correction_factor_9):
        self.correction_factor_9 = float(n_correction_factor_9)

    # And the getter and setter for correction_factor_7.
    # @property
    def correction_factor_7(self):
        return self.correction_factor_7

    # @correction_factor_7.setter
    def correction_factor_7(self, n_correction_factor_7):
        self.correction_factor_7 = float(n_correction_factor_7)

    # And the getter and setter for channel_list.
    # @property
    def channel_list(self):
        return self.channel_list

    # @channel_list.setter
    def channel_list(self, n_channel_list):
        self.channel_list = n_channel_list

    # And the getter and setter for duplicate_channel_list.
    # @property
    def duplicate_channel_list(self):
        return self.duplicate_channel_list

    # @duplicate_channel_list.setter
    def duplicate_channel_list(self, n_duplicate_channel_list):
        self.duplicate_channel_list = n_duplicate_channel_list

    # And the getter and setter for tool_calibration_error_msg_9.
    # @property
    def tool_calibration_error_msg_9(self):
        self.tool_calibration_error_msg_9

    # @tool_calibration_error_msg_9.setter
    def tool_calibration_error_msg_9(self, n_tool_calibration_error_msg_9):
        self.tool_calibration_error_msg_9 = n_tool_calibration_error_msg_9

    # And the getter and setter for tool_calibration_error_msg_7.
    # @property
    def tool_calibration_error_msg_7(self):
        self.tool_calibration_error_msg_7

    # @tool_calibration_error_msg_7.setter
    def tool_calibration_error_msg_7(self, n_tool_calibration_error_msg_7):
        self.tool_calibration_error_msg_7 = n_tool_calibration_error_msg_7

    # And the getter and setter for zonal_isolation_at_acquifer_msg.
    # @property
    def zonal_isolation_at_acquifer_msg(self):
        self.zonal_isolation_at_acquifer_msg

    # @zonal_isolation_at_acquifer_msg.setter
    def zonal_isolation_at_acquifer_msg(self, n_zonal_isolation_at_acquifer_msg):
        self.zonal_isolation_at_acquifer_msg = n_zonal_isolation_at_acquifer_msg

    # And the getter and setter for zonal_isolation_at_target_reservoir.
    # @property
    def zonal_isolation_at_target_reservoir(self):
        self.zonal_isolation_at_target_reservoir

    # @zonal_isolation_at_target_reservoir.setter
    def zonal_isolation_at_target_reservoir(self, n_zonal_isolation_at_target_reservoir):
        self.zonal_isolation_at_target_reservoir = n_zonal_isolation_at_target_reservoir

    # Dunder method
    def __repr__(self):
        members = [attr for attr in dir(self) if not callable(getattr(self, attr)) and not attr.startswith("__")]
        return f"LogicalFile({members})"