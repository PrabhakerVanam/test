# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module describes various constants used during input/output of data 
from/to the CSV files. These constants include expected names of columns in 
different input CSV files, names used as file and model prefix and suffix, etc.

@author: Prabhaker Reddy Vanam
"""

import os

# Flag to save extracted data to CSV
SAVE_DATA_TO_CSV = False
SAVE_INDIVIDUAL_PLOTS = False

# NaN values in dataframe
BAKER_DEFALUT_NAN = -999.25
QUALITY_DEFALUT_NAN = -9999

# Constants: Directory and file names
BASE_DATA_DIR = os.path.join(os.getcwd(), "data")
TRAINING_DATA_DIR = os.path.join(BASE_DATA_DIR, "training")
CCB_TRAINING_DATA_CSV = "bb1342_ccb_training.csv"
FREE_PIPE_TRAINING_DATA_CSV = "bb1342_free_pipe_training.csv"
INPUT_DATA_DIR = "\\\\lcdev1\\CementEvaluation\\input"
#OUTPUT_DATA_DIR = "\\\\lcdev1\\CementEvaluation\\output"
OUTPUT_DATA_DIR = os.path.join(os.getcwd(), "output")
MODELS_DIR = os.path.join(os.getcwd(), "models")
PARAMS_DIR = os.path.join(BASE_DATA_DIR, "params")
PLOTS_DIR = os.path.join(os.getcwd(), "plots")
CHANNEL_DATA_CSV_SUFFIX = "_channel_data.csv"
ALL_CHANNEL_DATA_CSV_SUFFIX = "_all_channel_data.csv"
WAVE_DATA_CSV_SUFFIX = "_wave_data.csv"
CEMO_DATA_CSV_SUFFIX = "_cemo_data.csv"
CEMO_ATTEN_DATA_CORR_CSV_SUFFIX = "_cemo_atten_data_corr.csv"
CEMO_BI_DATA_AFTER_CORR_CSV_SUFFIX = "_cemo_bi_data_after_corr.csv"
ATC_DATA_AFTER_CORR_CSV_SUFFIX = "_atc_data_after_corr.csv"
HEADER_CSV_SUFFIX = "_header_data.csv"
LOGICAL_FILE_INFO_CSV_SUFFIX = "_logical_file_info.csv"
ZONE_DATA_CSV_SUFFIX = "_zone_data.csv"
SUMMARY_DATA_CSV_SUFFIX = "_summary_data.csv"
ZONE_INFO_DB_DATA_CSV_SUFFIX = "_zone_info_from_db_data.csv"
FINAL_FLAG_DATA_CSV_SUFFIX = "_final_flag_data.csv"
TRAVEL_TIME_DATA_CSV_SUFFIX = "_travel_time_anomaly_data.csv"
CALCULATED_CCL_DATA_CSV_SUFFIX = "_calculated_ccl_data.csv"
CEMENT_QUALITY_DATA_CSV_SUFFIX = "_cement_quality_data.csv"
ZONAL_ISOLATION_DATA_CSV_SUFFIX = "_zonal_isolation_data.csv"
CHANNELLING_DATA_CSV_SUFFIX = "_channelling_data.csv"

PLOTS_DIR = os.path.join(os.getcwd(), "plots")
PLOT_FILE_SUFFIX = ".png"
WAVE_PLOT_FILE_SUFFIX = "_wave.png"
CEMO_PLOT_FILE_SUFFIX = "_cemo.png"
ATC_PLOT_FILE_SUFFIX = "_atc.png"
ALL_PLOTS_FILE_SUFFIX = "_all_plots.pdf"
CASING_PLOT_FILE_SUFFIX = "_casing.png"
CCB_PLOT_FILE_SUFFIX = "_ccb.png"
FP_PLOT_FILE_SUFFIX = "_fp.png"
BAKER_PREFIX = "BK"

CASING_SIZE_HEADER_KEY = 'CSOD'
FREE_PIPE_ATTEN_HEADE_KEY = 'FPAT'
SB_HIGH_CUTOFF_HEADER_KEY = 'SBHI'

# Casing info
DOUBLE_CASING_CUTOFF = 1

# Tool Calibration error
TOOL_CALIBRATION_CUTOFF=1.5

# Travel Time Anomaly related columns
TRAVEL_TIME_PERCENT = 0.1
CCL_TICK_COL = 'CCL_TICK'
CCL_TICK_SHIFT_COL = 'CCL_SHIFT_TICK'
CCL_START_DEPT_COL = "Start_anomaly_depth"
CCL_END_DEPT_COL = "End_anomaly_depth"
CCL_DEPT_DIFF_COL = 'Anomaly_lenth_in_ft'
TDEP_SHIFT_COL = 'TDEP_SHIFT'
CCL_DEPT_MARKER_COL = 'CCL_DEPT_MARKER'
ANOMALY_DEPT_CUTOFF = 4
FINAL_CEMENT_QUALITY_CUTOFF = 1

# Zonal Isolation related info
MIN_THICKNESS_AT_TARGET_RESERVOIR = 40
MIN_VALID_THICKNESS_AT_TARGET_RESERVOIR = 20
MIN_THICKNESS_AT_ACQUIFER = 300
MIN_THICKNESS_FOR_ZONAL_ISOLATION = 10
ZONAL_ISOLATION_PERCENT = 0.1
ZONAL_ISOLATION_EXCEL_COLUMN = 'Zonal Isolation'
ZONE_THICKNESS_EXCEL_COLUMN = 'Thickness(ft)'
ZONE_ISOLATION_NOT_CONFIRMED_MSG = 'Not Confirmed'
ZONE_ISOLATION_CONFIRMED_MSG = 'Confirmed'

#Zones colors
ZONE_COLOR_LIST = ['white', 'peru', 'darkkhaki', 'goldenrod', 'wheat', 'tan', 'burlywood', 'lightcoral', 'sienna', 'olive',
          'slategray', 'steelblue', 'darkcyan', 'dimgray', 'maroon', 'tomato', 'cadetblue']

# Channelling info
ROW_MIN_COLUMN = 'ROW_MIN_VALUE'
CHANNELLING_CUTOFF_VALUE = 20
CHANNELLING_COLUMN = 'CHANNELLING'
MAX_CHANNELLING_THECKNESS = 10
TDEP_SHIFT_FOR_BASE_COLUMN ='TDEPT_END'
CHANNELLING_THICKNESS_COLUMN = 'CHANNEL_THICKNESS'
CHANNELLING_CHANGE_MARK_COLUMN='CHANGE_MARK'
CHANNELLING_CHANGE_MARK_SHIFT_D_COLUMN='CHANGE_MARK_SHIFT_D'
CHANNELLING_REMARKS_COLUMN = "Remarks"
CHANNELLING_REMARKS_FOR_USER = "Suspected Channeling"

# Constants: Column names in the DLIS Logical file/CSV files containing input data, and
#            for the intermediate Pandas dataframes created during the 
#            model training and prediction process.
SUMMARY_DF_COLUMN_LIST = ['Field Name', 'Well Name', 'Company', 'Producer Name', 'Set Name', 'Frame Name',
                          'Total Rows and Columns', 'Depth Range', 'Column Names']
HEADER_PARAM_LIST = ['CN', 'WN', 'FN', 'UWID', 'SET', 'RUN', 'ABSE_FVAL', 'BS', 'CSOD', 'CSWT', 'FAMP',
                     'FPAT', 'BPLO', 'BPHI', '!', 'COUN', 'STAT', 'FL', 'FL1', 'FL2', 'FL3', 'DATE',
                     'TDD', 'BLI', 'TLI', 'EKB', 'EDF', 'EGL', 'CMST', 'SBHI', 'SBLO', 'LCNM', 'STAT',
                     'R1', 'R2', 'R3', 'R3', 'R5', 'R6', 'R7', 'R8', 'R9', 'R10', 'R11', 'R12', 'R13', 'R14',
                     'R15', 'R16', 'CS1', 'CW1', 'CG1', 'CS2', 'CW2', 'CG2', 'CS3', 'CW3', 'CG3', 'CS4', 'CW4', 'CG4',
                     'LPAS', 'LDIR']

SBT_CHANNEL_SET = ['TDEP', 'ATAV', 'ATC1', 'ATC2', 'ATC3', 'ATC4', 'ATC5', 'ATC6', 'CCL', 'DTMN', 'DTMX']
SBT_CHANNEL_SET_I = ['TDEP', 'ATAV.I', 'ATC1.I', 'ATC2.I', 'ATC3.I', 'ATC4.I', 'ATC5.I', 'ATC6.I', 'CCL.I',
                     'DTMN.I', 'DTMX.I']
ATC_COLUMN_LIST = ['ATC1', 'ATC2', 'ATC3', 'ATC4', 'ATC5', 'ATC6']
ATC_I_COLUMN_LIST = ['ATC1.I', 'ATC2.I', 'ATC3.I', 'ATC4.I', 'ATC5.I', 'ATC6.I']
WAVE_COLUMN = 'WAVE'
WAVE_I_COLUMN = 'WAVE.I'
CEMO_COLUMN = 'CEMO'
CEMO_I_COLUMN = 'CEMO.I'
TDEP_COLUMN = 'TDEP'
DEVOD_COLUMN = 'DEVOD'
DTMN_I_COLUMN = 'DTMN.I'
DTMX_I_COLUMN = 'DTMX.I'
GR_I_COLUMN = 'GR.I'
AMAV_I_COLUMN = 'AMAV.I'
ATAV_I_COLUMN = 'ATAV.I'
CCL_I_COLUMN = 'CCL.I'
DTMN_COLUMN = 'DTMN'
DTMX_COLUMN = 'DTMX'
GR_COLUMN = 'GR'
AMAV_COLUMN = 'AMAV'
ATAV_COLUMN = 'ATAV'
CCL_COLUMN = 'CCL'
CCB_COLUMN = 'CCB'
BI_COLUMN = 'BI'
FREE_PIPE_COLUMN = 'FREE_PIPE'
FINAL_FLAG_COLUMN = 'FINAL_FLAG'

# Constants: These constants define the path and names of saved machine learning 
#            models, created using scikit-learn and Keras libraries.
MODEL_DIR = os.path.join(os.getcwd(), "models")
MODEL_NAME_SUFFIX = ".joblib"
MODEL_SEPARATOR = "-"
MODEL_FOLD="fold"
# For data scalers and prediction models
CQF_MODEL_PREFIX = "cqf"

# Hyper-parameters for the forecasting RNN training
RNN_NUM_HIDDEN_PARAM = "num_hidden"
RNN_BATCH_SIZE_PARAM = "batch_size"
RNN_NUM_EPOCHS_PARAM = "num_epochs"
RNN_PATIENCE_PARAM = "patience"
RNN_LOOKBACK_PARAM = "lookback"
RNN_LOOKAHEAD_PARAM = "lookahead"
RNN_DROPOUT_PARAM = "dropout"

# WAVE data info for calculations
WAVE_START_IDX=29
WAVE_END_IDX=140

#Bond Index Params
SPN_CONSTANT = 0.8
BI_9_COLUMN = '9_BI'
BI_7_COLUMN = '7_BI'

# Flask API Param names
HEADER_FILES = 'header_file'
PLOT_FILES = 'plot_file'
CHANNELLING_FILES = 'channelling_file'
TRAVEL_TIME_ANOMALY_FILES = 'travel_time_anomaly_file'
ZONAL_ISOLATION_FILES = 'zonal_isolation_file'
CEMENT_QUALITY_FILES = 'cement_quality_file'
ZONE_FILES ='zone_file'
MESSAGE ='message'
DOUBLE_CASING_MESSAGE='double_casing_message'
LOGICAL_FILE_INFO = "logical_file_info"
LOGICAL_FILE_KEY ="logical_file_key"


# DLIS Header Properties names
HEADER_PARAM_VALUES_COLUMN = 'Value(s)'
HEADER_PARAM_NAME_COLUMN = 'Name'
HEADER_LONG_NAME_COLUMN = 'Long name'
HEADER_ZONES_COLUMN = 'Zone(s)'
HEADER_DIMEN_COLUMN = 'Dimension'
HEADER_FRAME_COLUMN = 'Frame'
HEADER_UNITS_COLUMN = 'Units'
HEADER_TRADEMARK_COLUMN = 'Trademark name'
HEADER_GENERIC_NAME_COLUMN = 'Generic name'
HEADER_DESC_COLUMN = 'Description'

# DLIS Logical file prams
LOGICAL_FILE_FRAME_ATTR = 'frame'
LOGICAL_FILE_FRAME_VALUE_25 = '0_250000B0'
LOGICAL_FILE_FRAME_VALUE_50 = '0_500000B0'