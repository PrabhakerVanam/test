# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module reads data from given DLIS files for Cement Bond logs,
and returns populated Pandas dataframes. Purpose of this module is to provide a loose
coupling between the data population module and the data source. 
In future, beyond PoC scope, this module may be substituted with a module 
reading data from other data source, and providing similar dataframes.

@author: Prabhaker Reddy Vanam
"""

import logging
import os

import pandas as pd

import aon.dlis.db.db_connection_prop as db_prop
import aon.dlis.db.expris_connection as expris
from aon.dlis.io import io_constants as io_const

# Custom Logger
from logging_baker import logger

def get_frame_from_logical_file(lfile):
    """Extract 'frame' from Logical File

    Parameters
    ----------
    :param lfile : Logical File from a dlis

    Returns
    -------
    frame : 'frame' from Logical File
    """
    frame = None
    try:
        frame = lfile.object(io_const.LOGICAL_FILE_FRAME_ATTR, io_const.LOGICAL_FILE_FRAME_VALUE_25)

    except Exception as e:
        logging.error(f"ERROR : {e}")
        frame = lfile.object(io_const.LOGICAL_FILE_FRAME_ATTR, io_const.LOGICAL_FILE_FRAME_VALUE_50)

    return frame


def index_of(frame):
    """Return the index channel of the frame"""
    return next(ch for ch in frame.channels if ch.name == frame.index)


def get_channel(frame, name):
    """Get a channel with a given name from a given frame; fail if the frame does not have exactly one such channel"""
    [channel] = [x for x in frame.channels if x.name == name]
    return channel


def get_single_dim_channel_names(frame, duplicate_channel_list):
    """Create a List that contains the single dimensional channel names of 'frame',
    duplicate channels are ignored

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    # print("--------------------------------------------")
    # keep default column name as FRAMENO
    # channel_names = ['FRAMENO']
    channel_names = []
    for ch in frame.channels:

        dim = ch.dimension
        name = ch.name
        # print(dim[0])
        if dim[0] == 1:
            if name not in duplicate_channel_list and (
                    name in io_const.SBT_CHANNEL_SET or name in io_const.SBT_CHANNEL_SET_I):
                channel_names.append(name)

    return channel_names


def get_all_channel_names_of_logical_file(logical_file, duplicate_channel_list):
    """Create a List that contains all channel names of 'logical file',
    duplicate channels are ignoted

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    # channel_names = ['FRAMENO']
    channel_names = []
    for ch in logical_file.channels:
        # dim = ch.dimension
        name = ch.name
        if name not in duplicate_channel_list:
            channel_names.append(name)

    return channel_names


def get_all_channel_names(frame, duplicate_channel_list):
    """Create a List that contains all channel names of 'frame',
    duplicate channels are ignored

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    # channel_names = ['FRAMENO']
    channel_names = []
    for ch in frame.channels:
        # dim = ch.dimension
        name = ch.name
        if name not in duplicate_channel_list:
            channel_names.append(name)

    return channel_names


def get_wave_channel_name(frame, duplicate_channel_list):
    """Create a List that contains the multi dimensional channel names of 'frame', One
    channel pr. CEMO/WAVE

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    channel_names = []
    for ch in frame.channels:

        dim = ch.dimension
        name = ch.name
        if dim[0] >= 250 and (name == io_const.WAVE_COLUMN or name == io_const.CEMO_COLUMN or name == io_const.WAVE_I_COLUMN or name == io_const.CEMO_I_COLUMN):

            print("Channel Name : {} and Size {}".format(name, dim[0]))
            if name not in duplicate_channel_list:
                channel_names.append(name)

    return channel_names


''' 
To explore the parameters and channels in the file, we create a helper function that iterates through a sequence of 
dlisio objects and compiles a pandas dataframe from selected object attributes. We will show how the function is used 
in the next cell.
'''


def summarize(objs, **kwargs):
    """Create a pd.DataFrame that summarize the content of 'objs', One
    object pr. row

    Parameters
    ----------
    :rtype:
    :param objs : list()
        list of metadata objects

    :param **kwargs
        Keyword arguments
        Use kwargs to tell summarize() which fields (attributes) of the
        objects you want to include in the DataFrame. The parameter name
        must match an attribute on the object in 'objs', while the value
        of the parameters is used as a column name. Any kwargs are excepted,
        but if the object does not have the requested attribute, 'KeyError'
        is used as the value.

    Returns
    -------
    summary : pd.DataFrame
    """
    summary = []
    for attr, label in kwargs.items():
        column = []
        for obj in objs:
            try:
                value = getattr(obj, attr)
            except AttributeError:
                value = 'KeyError'

            column.append(value)
        summary.append(column)

    summary = pd.DataFrame(summary).T
    summary.columns = kwargs.values()

    return summary


def populate_csv_data_dataframes(csv_file_path,
                                 header_info_file_path):
    """This is a utility function, which returns Pandas dataframes containing dlis
    information specific to a desired well.
    
    Parameters
    ----------
    :param csv_file_path: Path to the file containing dlis Extracted CSV Data.
    :param header_info_file_path: CSV File path contains the header info

    Return value(s)
    ---------------
    :return well_log_df: Pandas dataframe with well test data
    """
    well_log_df = None
    header_df = None

    # Reading the CBL data file
    if os.path.isfile(csv_file_path):
        well_log_df = pd.read_csv(csv_file_path)
    # Reading the Header Info data file
    if os.path.isfile(header_info_file_path):
        header_df = pd.read_csv(header_info_file_path)

    # Reading well location file
    well_log_df = well_log_df.loc[well_log_df[io_const.BAKER_COLUMN_NAMES]]
    return well_log_df, header_df


def load_zone_info_from_expris(well_name: "BB0318"):
    ''' Function which connects to EXPRIS database to fetch Zone information for given Well, return zone related info
    as 3 pandas list else return empty list if it doesnt exists

    :param well_name:
    :return:
    '''

    exp_db = None
    column_names = pd.column_names = [db_prop.DB_UWI_COLUMN, db_prop.DB_UBHI_COLUMN, db_prop.DB_LAYER_NAME_COLUMN,\
                                      db_prop.DB_LAYER_TYPE_COLUMN, db_prop.DB_TOP_COLUMN, db_prop.DB_BASE_COLUMN]
    df_zones_info_db = pd.DataFrame(columns=column_names)
    try:

        exp_db = expris.ExprisDatabase(db_prop.DB_SERVER_NAME, db_prop.DB_PORT_NUMBER, db_prop.DB_SERVICE_NAME,
                                       db_prop.DB_USER, db_prop.DB_PWD)
        conn = exp_db.connect_db()
        query = "SELECT DISTINCT(" + db_prop.DB_LAYER_NAME_COLUMN + "), " + db_prop.DB_UWI_COLUMN \
                + ", SUBSTR(" + db_prop.DB_UBHI_COLUMN + ", 0, 6) UBHI, " + db_prop.DB_LAYER_TYPE_COLUMN \
                + ", " + db_prop.DB_TOP_COLUMN + ", " + db_prop.DB_BASE_COLUMN + " FROM " + db_prop.DB_VIEW_NAME \
                + " WHERE " + db_prop.DB_UBHI_COLUMN + f" LIKE '{well_name}%'"
        print(query)
        df_zones_info_db = pd.read_sql(query, con=conn)
        print(df_zones_info_db.head(1))

    except Exception as e:
        print("Unexpected error:", e)

    finally:
        if exp_db is not None:
            exp_db.release(conn)

    return df_zones_info_db
