# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module provides utility function to plot prediction and  
forecasting results obtained from the trained machine learning models.

@author: Prabhaker Reddy Vanam
"""

import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as plticker
import numpy as np
from pandas.plotting import register_matplotlib_converters

import aon.dlis.db.db_connection_prop as db_prop
from aon.dlis.io import io_constants as io_const
from aon.dlis.preprocess import data_preprocessor as preproc

# Custom Logger
from logging_baker import logger

register_matplotlib_converters()

'''Set a default DPI for all figures in this file. Lower DPI gives smaller figures, higher bigger.'''

mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['axes.linewidth'] = 0.5  # set the value globally


def paint_channel(ax, curve, y_axis, x_axis, **kwargs):
    """Plot an image channel into an axes using an index channel for the y-axis

    Parameters
    ----------
    :param ax: matplotlib.axes
    :param curve : numpy array  - The curve to be plotted
    :param index : numpy array  - The depth index as a Channel object (slower) or a numpy array (faster)
    :param **kwargs : dict      - Keyword arguments to be passed on to ax.imshow()
    """
    try:
        # Determine the extent of the image so that the pixel centres correspond with the correct axis values
        dx = np.mean(x_axis[1:] - x_axis[:-1])
        dy = np.mean(y_axis[1:] - y_axis[:-1])
        # Y - Top to Bottom
        # extent = (x_axis[0] - dx/2, x_axis[-1] + dx/2, y_axis[0] - dy/2, y_axis[-1] + dy/2)
        # Y - Bottom To Top
        extent = (x_axis[0] - dx / 2, x_axis[-1] + dx / 2, y_axis[-1] + dy / 2, y_axis[0] - dy / 2)

        # Determine the correct orientation of the image
        if y_axis[1] < y_axis[0]:  # Frame recorded from the bottom to the top of the well
            origin = 'lower'
        else:  # Frame recorded from the top to the bottom of the well
            origin = 'upper'

        return ax.imshow(curve, aspect='auto', origin=origin, extent=extent, **kwargs)
    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def plot_combo_grid(casing_df, df_single_dim_data, df_cemo_data, df_wave_data, ccb_ndarray, fp_ndarray, df_bi,
                    final_flag_ndarray, atc_channels, ccl_channel, gr_channel, amav_channel, \
                    atav_channel, dtmn_channel, dtmx_channel, devod_channel, df_zone_info_db, logical_file):
    ''' This function generates combined plots which are required for POC casing, WAVE, CEMO, ATC etc.

    :param casing_df:
    :param df_single_dim_data:
    :param df_cemo_data:
    :param df_wave_data:
    :param ccb_ndarray:
    :param fp_ndarray:
    :param df_bi:
    :param final_flag_ndarray:
    :param atc_channels:
    :param ccl_channel:
    :param gr_channel:
    :param amav_channel:
    :param atav_channel:
    :param dtmn_channel:
    :param dtmx_channel:
    :param devod_channel:
    :param logical_file:
    :param df_zone_info_db:
    :param file_path:
    :return:
    '''

    try:
        title_font = {'fontsize': '5', 'fontweight': 'bold', 'verticalalignment': 'baseline',  'horizontalalignment': 'center',}

        # fig, axes = plt.subplots(nrows=1, ncols=10, sharey=True, figsize=(7, max_depth*.01), constrained_layout=False)
        # fig5 = plt.figure(constrained_layout=True)
        widths = [3, 3, 3, 1, 1, 1, 1, 1, 1, 3, 3, 5, 3, 5, 3, 3, 3, 3]
        heights = [logical_file.max_depth * .01]

        gs_kw = dict(width_ratios=widths, height_ratios=heights)
        fig, axes = plt.subplots(nrows=1, ncols=18, sharey=True, figsize=(7, logical_file.max_depth * .01), constrained_layout=False,
                                 gridspec_kw=gs_kw)

        # plt.plots_adjust(hspace=0.1, top=0.85, bottom=0.15, left=0.2, wspace=0.1)
        fig.subplots_adjust(hspace=0.1, top=0.5, bottom=0.15, left=0.1, wspace=0.2)

        ylocator = mpl.ticker.MultipleLocator(base=25)

        # ax = fig5.add_subplot(spec5[0, 0])
        logger.debug("""-----------------------------CASING------------------------------------""")
        ax = axes[0]
        c2 = plot_casing(fig, ax, casing_df, logical_file, ylocator)

        logger.debug("""-----------------------------DEVOD---------------------------------""")
        # DEVOD
        ax = axes[1]
        plot_devod(ax, df_single_dim_data, devod_channel[0], logical_file, ylocator)

        logger.debug("""-----------------------------DTMN & DTMX---------------------------------""")
        ax = axes[2]
        plot_dt_min_max(ax, df_single_dim_data, dtmn_channel[0], dtmx_channel[0], logical_file, ylocator)

        logger.debug("""-----------------------------CCL---------------------------------""")
        # CCL in single Axis
        ax = axes[3]
        plot_ccl(ax, df_single_dim_data, ccl_channel[0], logical_file, ylocator)

        logger.debug("""-----------------------------ATC---------------------------------""")
        axs = axes[4:10]
        plot_atc(axs, df_single_dim_data, atc_channels, logical_file, ylocator)

        logger.debug("""-----------------------------AMAV & ATAV---------------------------------""")
        # AMAV & ATAV in single Axis
        ax = axes[10]
        plot_amav_atav(ax, df_single_dim_data, amav_channel, atav_channel, logical_file, ylocator)

        logger.debug("""-----------------------------CEMO------------------------------------""")
        ax = axes[11]
        c2 = plot_cemo(fig, ax, df_cemo_data, logical_file, ylocator)

        logger.debug("""-----------------------------GR--------------------------------""")
        ax = axes[12]
        plot_gr(ax, df_single_dim_data, gr_channel[0], df_zone_info_db, logical_file, ylocator)

        logger.debug("""-----------------------------WAVE---------------------------------""")
        ax = axes[13]
        c2 = plot_wave(fig, ax, df_wave_data, logical_file, ylocator)

        logger.debug("""-----------------------------CCB---------------------------------""")
        # CCB Axis
        ax = axes[14]
        c2 = plot_ccb(fig, ax, df_single_dim_data, ccb_ndarray, logical_file, ylocator)

        logger.debug("""-----------------------------Free Pipe---------------------------------""")
        # FP Axis
        ax = axes[15]
        c2 = plot_freepipe(fig, ax, df_single_dim_data, fp_ndarray, logical_file, ylocator)

        logger.debug("""-----------------------------Bond Index---------------------------------""")
        # FP Axis
        ax = axes[16]
        plot_bi_line(ax, df_bi, logical_file, ylocator)

        logger.debug("""-----------------------------Final Flag ---------------------------------""")
        ax = axes[17]
        plot_final_flag(fig, ax, df_single_dim_data, final_flag_ndarray, logical_file, ylocator)

        return fig

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def plot_bi_line(ax, df_bi, logical_file, ylocator):
    '''

    :param ax:
    :param df_bi:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        tdep_column = io_const.TDEP_COLUMN
        bi_column = io_const.BI_COLUMN
        color = 'dimgray'
        xlimmin = 0
        xlimmax = 1

        ax.plot(df_bi[bi_column], df_bi[tdep_column], color=color, linewidth=0.4)
        # ax.set_xlabel(ccl_channel_name, fontsize=2)
        ax.set_xlim(xlimmin, xlimmax)
        ax.set_ylim(df_bi[tdep_column].min(), df_bi[tdep_column].max())
        ax.fill_between(df_bi[bi_column].values, df_bi[tdep_column].values, 0, facecolor='lightblue', alpha=0.5)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1, colors='green')
        ax.yaxis.set_tick_params(width=0.01, colors='green')
        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=4)
        ax.yaxis.set_major_locator(ylocator)

        # Add header labels
        ax01 = annotate_axis_header_label(ax, (xlimmin, xlimmax), 'BOND INDEX', color, 5)

        if np.max(df_bi[bi_column]) <= 0:
            message = "Header info missing"
            missing_data_custom_message(ax, message, xlimmin, xlimmax, logical_file)

            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='green')
            ax.yaxis.set_tick_params(width=0.01, colors='green')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=4)
            ax.yaxis.set_major_locator(ylocator)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")


def plot_final_flag(fig, ax, df_single_dim_data, final_flag_ndarray, logical_file, ylocator):
    '''

    :param fig:
    :param ax:
    :param df_single_dim_data:
    :param final_flag_ndarray:
    :param min_depth:
    :param max_depth:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        wave_dimension = 250
        fp_samples = np.arange(wave_dimension)

        colors = ['white', 'deepskyblue', 'dodgerblue', 'steelblue', 'orange', 'brown', 'lightgreen']
        cmap = mpl.colors.ListedColormap(colors)

        # cmap = 'RdYlGn'  # plt.cm.Greys, #'seismic', #'viridis',
        vmin = -1
        vmax = 5
        wf_pltargs = {
            'cmap': cmap,
            'vmin': vmin,
            'vmax': vmax,
            # 'alpha': 1.0,
            'interpolation': 'nearest',
        }
        if len(final_flag_ndarray) > 0:

            extent = [0, len(final_flag_ndarray) * .015, logical_file.max_depth, logical_file.min_depth]
            # c2 = ax.imshow(ccb_ndarray , origin='upper', extent=extent , **wf_pltargs)
            im = paint_channel(ax, final_flag_ndarray, df_single_dim_data.index.values, fp_samples, **wf_pltargs)

            # add Colorbar
            add_custom_colorbar(ax, fig, im, 'FINAL FLAG')

            # ax.set_xlabel('Free Pipe', fontsize=2)
            ax.xaxis.set_label_position('top')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.yaxis.set_major_locator(ylocator)

            return im

        else:
            message = "Source data missing to calculate/predict Final Flags"
            logger.debug(message)
            missing_data_custom_message(ax, message, 0, 1, logical_file)

            ax.xaxis.set_label_position('top')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.yaxis.set_major_locator(ylocator)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")


def plot_freepipe(fig, ax, df_single_dim_data, fp_ndarray, logical_file, ylocator):
    '''

    :param fig:
    :param ax:
    :param df_single_dim_data:
    :param fp_ndarray:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        wave_dimension = 250
        fp_samples = np.arange(wave_dimension)

        colors = ['deepskyblue', 'lightgreen']
        cmap = mpl.colors.ListedColormap(colors)

        # cmap = 'RdYlGn'  # plt.cm.Greys, #'seismic', #'viridis',
        vmin = 1
        vmax = 2
        wf_pltargs = {
            'cmap': cmap,
            'vmin': vmin,
            'vmax': vmax,
            # 'alpha': 1.0,
            'interpolation': 'nearest',
        }
        if len(fp_ndarray) > 0:
            extent = [0, len(fp_ndarray) * .015, logical_file.max_depth, logical_file.min_depth]
            # c2 = ax.imshow(ccb_ndarray , origin='upper', extent=extent , **wf_pltargs)
            im = paint_channel(ax, fp_ndarray, df_single_dim_data.index.values, fp_samples, **wf_pltargs)

            # add Colorbar
            add_custom_colorbar(ax, fig, im, 'FREE PIPE')

            # ax.set_xlabel('Free Pipe', fontsize=2)
            ax.xaxis.set_label_position('top')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.yaxis.set_major_locator(ylocator)

            return im
        else:
            message = "Freepipe data not available"
            logger.debug(message)
            missing_data_custom_message(ax, message, 0, 1, logical_file)

            ax.xaxis.set_label_position('top')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.yaxis.set_major_locator(ylocator)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def plot_ccb(fig, ax, df_single_dim_data, ccb_ndarray, logical_file, ylocator):
    '''

    :param fig:
    :param ax:
    :param df_single_dim_data:
    :param ccb_ndarray:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        wave_dimension = 250
        ccb_samples = np.arange(wave_dimension)

        colors = ['white', 'lightgreen', 'orange', 'deepskyblue']
        cmap = mpl.colors.ListedColormap(colors)

        # cmap = 'RdYlGn'  # plt.cm.Greys, #'seismic', #'viridis',
        vmin = 0
        vmax = 3
        wf_pltargs = {
            'cmap': cmap,
            'vmin': vmin,
            'vmax': vmax,
            # 'alpha': 1.0,
            'interpolation': 'nearest',
        }
        extent = [0, len(ccb_ndarray) * .015, logical_file.max_depth, logical_file.min_depth]
        # c2 = ax.imshow(ccb_ndarray , origin='upper', extent=extent , **wf_pltargs)
        im = paint_channel(ax, ccb_ndarray, df_single_dim_data.index.values, ccb_samples, **wf_pltargs)

        # add Colorbar
        add_custom_colorbar(ax, fig, im, 'CCB')

        ax.xaxis.set_label_position('top')
        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=2)
        ax.xaxis.set_tick_params(width=0.1, colors='blue')
        ax.yaxis.set_tick_params(width=0.01, colors='blue')
        ax.yaxis.set_major_locator(ylocator)

        return im

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def plot_ccl(ax, df_single_dim_data, ccl_channel_name, logical_file, ylocator):
    '''

    :param ax:
    :param df_single_dim_data:
    :param ccl_channel_name:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        tdep_column = io_const.TDEP_COLUMN
        df_ccl = df_single_dim_data[[tdep_column] + [ccl_channel_name]]
        # df_ccl = df_ccl[df_ccl != -999.25].dropna()
        df_ccl = df_ccl.replace({io_const.BAKER_DEFALUT_NAN: 0})

        ccl_min = 0  # df_ccl[ccl_channel_name].min()
        ccl_max = 100  # df_ccl[ccl_channel_name].max()

        color = 'black'

        ax.plot(df_ccl[ccl_channel_name], df_ccl[tdep_column], color=color, linewidth=0.4)
        # ax.set_xlabel(ccl_channel_name, fontsize=2)
        ax.set_xlim(ccl_min, ccl_max)
        ax.set_ylim(logical_file.min_depth, logical_file.max_depth)
        ax.fill_between(df_ccl[ccl_channel_name].values, df_ccl[tdep_column].values, 0, facecolor='lightblue', alpha=0.5)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1, colors='blue')
        ax.yaxis.set_tick_params(width=0.01, colors='blue')
        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=4)
        ax.yaxis.set_major_locator(ylocator)

        # Add header labels
        ax01 = annotate_axis_header_label(ax, (ccl_min, ccl_max), ccl_channel_name, color, 5)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")


def plot_devod(ax, df_single_dim_data, devod_channel_name, logical_file, ylocator):
    '''

    :param ax:
    :param df_single_dim_data:
    :param devod_channel_name:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        tdep_column = io_const.TDEP_COLUMN
        # DEVOD Axis
        df_devod = df_single_dim_data[[tdep_column] + [devod_channel_name]]
        # df_devod = df_devod[df_devod != -999.25].dropna()
        df_devod = df_devod.replace({io_const.BAKER_DEFALUT_NAN: 0})

        devod_min = -1 #int(df_devod[devod_channel_name].min())
        devod_max = 1 #int(df_devod[devod_channel_name].max())

        if len(devod_channel_name) > 0:

            devod_min = int(df_devod[devod_channel_name].min())
            devod_max = int(df_devod[devod_channel_name].max())

            ax.plot(df_devod[devod_channel_name], df_devod[tdep_column], color='brown', linewidth=0.4)
            # ax.set_xlabel(gr_channel_name, fontsize=2)
            ax.set_xlim(devod_min, devod_max)
            ax.set_ylim(logical_file.min_depth, logical_file.max_depth)
            ax.fill_between(df_devod[devod_channel_name].values, df_devod[tdep_column].values, 0, facecolor='lightblue',
                            alpha=0.5)

            ax.invert_yaxis()
            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

            # Add header labels
            # (df_gr[gr_channel_name].min(), df_gr[gr_channel_name].max())
            ax01 = annotate_axis_header_label(ax, (devod_min, devod_max), devod_channel_name, 'brown', 5)

        else:
            message = "DEVOD data not available"
            missing_data_custom_message(ax, message, devod_min, devod_max, logical_file)

            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.1, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")


def plot_amav_atav(ax, df_single_dim_data, amav_channel, atav_channel, logical_file, ylocator):
    '''

    :param ax:
    :param df_single_dim_data:
    :param amav_channel:
    :param atav_channel:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        # logger.debug(amav_channel, atav_channel)
        tdep_column = io_const.TDEP_COLUMN
        df_amtav = df_single_dim_data[[tdep_column] + amav_channel + atav_channel]
        # df_amtav = df_amtav[df_amtav != -999.25].dropna()
        df_amtav = df_amtav.replace({io_const.BAKER_DEFALUT_NAN: 0})

        amav_min = 0  # df_amtav[amav_channel[0]].min()
        amav_max = 60  # df_amtav[amav_channel[0]].max()
        atav_min = -5  # df_amtav[atav_channel[0]].min()
        atav_max = 20  # df_amtav[atav_channel[0]].max()

        if len(amav_channel) > 0:
            ax.plot(df_amtav[amav_channel[0]], df_amtav[tdep_column], color='brown', linewidth=0.4)
        ax.plot(df_amtav[atav_channel[0]], df_amtav[tdep_column], color='blue', linewidth=0.4)
        # ax.set_xlabel(amav_channel_name + ' - ' + atav_channel_name, fontsize=2)
        if len(amav_channel) > 0:
            ax.set_xlim(min(amav_min, atav_min), max(amav_max, atav_max))
        else:
            ax.set_xlim(atav_min, atav_max)

        ax.set_ylim(logical_file.min_depth, logical_file.max_depth)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1, colors='blue')
        ax.yaxis.set_tick_params(width=0.01, colors='blue')
        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=4)
        ax.yaxis.set_major_locator(ylocator)

        if len(amav_channel) > 0:
            # Add header labels
            ax01 = annotate_axis_header_label(ax, (amav_min, amav_max), amav_channel, 'brown', 5)

        # Add header labels
        ax01 = annotate_axis_header_label(ax, (atav_min, atav_max), atav_channel, 'blue', 25)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")


def plot_gr(ax, df_single_dim_data, gr_channel_name, df_zone_info_db, logical_file, ylocator):
    '''

    :param ax:
    :param df_single_dim_data:
    :param gr_channel_name:
    :param df_zone_info_db:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        tdep_column = io_const.TDEP_COLUMN
        # GR Axis
        df_gr = df_single_dim_data[[tdep_column] + [gr_channel_name]]
        # df_gr = df_gr[df_gr != -999.25].dropna()
        df_gr = df_gr.replace({io_const.BAKER_DEFALUT_NAN: 0})

        gr_min = 0  # df_gr[gr_channel_name].min()
        gr_max = 70  # df_gr[gr_channel_name].max()

        if len(gr_channel_name) > 0:
            ax.plot(df_gr[gr_channel_name], df_gr[tdep_column], color='darkgreen', linewidth=0.4)
            # ax.set_xlabel(gr_channel_name, fontsize=2)
            ax.set_xlim(gr_min, gr_max)
            ax.set_ylim(logical_file.min_depth, logical_file.max_depth)
            ax.fill_between(df_gr[gr_channel_name].values, df_gr[tdep_column].values, 0, facecolor='lightblue', alpha=0.5)

            ax.invert_yaxis()
            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

            # Add header labels
            # (df_gr[gr_channel_name].min(), df_gr[gr_channel_name].max())
            ax01 = annotate_axis_header_label(ax, (gr_min, gr_max), gr_channel_name, 'darkgreen', 5)

            # Annotate axis with Zones names
            annotate_axis_with_zones(ax, df_zone_info_db, logical_file)

            # Fill colour in the zones
            fill_zones_with_color(ax, df_zone_info_db, df_gr, gr_channel_name, logical_file)

        else:
            message = "GR data not available"
            missing_data_custom_message(ax, message, gr_min, gr_max, logical_file)

            # ax.set_xlabel('WAVE', fontsize=2)
            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.1, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")


def fill_zones_with_color(ax, df_zone_info_db, df_gr, gr_channel_name, logical_file):
    '''

    :param ax:
    :param df_zone_info_db:
    :param logical_file:
    :return:
    '''
    print("Coloring Zone layers...")
    if df_zone_info_db is not None:
        # logger.debug(df_zone_info_db.head(2))
        zone_names = df_zone_info_db[db_prop.DB_LAYER_NAME_COLUMN].values.tolist()
        # logger.debug(zone_names)
        zone_tops_depths = df_zone_info_db[db_prop.DB_TOP_COLUMN].values.tolist()
        # logger.debug(zone_tops_depths)
        zone_bottom_depths = df_zone_info_db[db_prop.DB_BASE_COLUMN].values.tolist()
        # logger.debug(zone_bottom_depths)
        count = 1
        df_gr_copy = df_gr.copy()
        # fill complete values with 0
        df_gr_copy.set_index(io_const.TDEP_COLUMN, drop=True, inplace=True)
        df_gr_copy[gr_channel_name] = 0

        for (i, j) in zip(zone_tops_depths, zone_bottom_depths):
            i = int(i) + logical_file.unit_depth
            j = int(j) + logical_file.unit_depth
            if (i >= float(logical_file.min_depth)) and (i <= float(logical_file.max_depth)):
                if j > float(logical_file.max_depth):
                    j = float(logical_file.max_depth)

                df_gr_copy.loc[int(i): int(j), :] = count
                count += 1

        # create image plot on top of GR
        colors = io_const.ZONE_COLOR_LIST
        cmap = mpl.colors.ListedColormap(colors)

        #cmap = 'seismic' #'RdYlGn'  # plt.cm.Greys, #'seismic', #'viridis',
        vmin = 0
        vmax = count
        wf_pltargs = {
            'cmap': cmap,
            'vmin': vmin,
            'vmax': vmax,
            'alpha': 0.5,
            'interpolation': 'nearest',
        }
        #print(df_gr_copy.shape)
        gr_ndarray = df_gr_copy[gr_channel_name].values.reshape(-1, 1)

        if len(gr_ndarray) > 0:
            extent = [0, len(gr_ndarray) * .015, logical_file.max_depth, logical_file.min_depth]
            gr_samples = np.arange(250)
            im = paint_channel(ax, gr_ndarray, df_gr_copy.index.values, gr_samples, **wf_pltargs)

    return 0


def annotate_axis_with_zones(ax, df_zone_info_db, logical_file):
    '''

    :param ax:
    :param df_zone_info_db:
    :param logical_file:
    :return:
    '''
    # Mark Zones on the GR axis
    if df_zone_info_db is not None:
        # logger.debug(df_zone_info_db.head(2))
        zone_names = df_zone_info_db[db_prop.DB_LAYER_NAME_COLUMN].values.tolist()
        # logger.debug(zone_names)
        zone_tops_depths = df_zone_info_db[db_prop.DB_TOP_COLUMN].values.tolist()
        # logger.debug(zone_tops_depths)
        zone_bottom_depths = df_zone_info_db[db_prop.DB_BASE_COLUMN].values.tolist()
        # logger.debug(zone_bottom_depths)
        for (i, j) in zip(zone_tops_depths, zone_names):
            i = float(i)
            if (i >= float(logical_file.min_depth)) and (i <= float(logical_file.max_depth)):
                ax.axhline(y=i, linewidth=0.1, color='black')
                ax.text(0.1, i, j, horizontalalignment='left', verticalalignment='baseline', fontsize=2.5,
                        color='red')

    return 0


def plot_dt_min_max(ax, df_single_dim_data, dtmn_channel_name, dtmx_channel_name, logical_file, ylocator):
    '''

    :param ax:
    :param df_single_dim_data:
    :param dtmn_channel_name:
    :param dtmx_channel_name:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        tdep_column = io_const.TDEP_COLUMN
        # DTMN,  DTMX in single Axis
        df_dtmnmx = df_single_dim_data[[tdep_column] + [dtmn_channel_name, dtmx_channel_name]]
        # df_dtmnmx = df_dtmnmx[df_dtmnmx != -999.25].dropna()
        df_dtmnmx = df_dtmnmx.replace({io_const.BAKER_DEFALUT_NAN: 0})

        dtmn_min = 20  # df_dtmnmx[dtmn_channel_name].min()
        dtmn_max = 80  # df_dtmnmx[dtmn_channel_name].max()
        dtmx_min = 20  # df_dtmnmx[dtmx_channel_name].min()
        dtmx_max = 80  # df_dtmnmx[dtmx_channel_name].max()

        ax.plot(df_dtmnmx[dtmn_channel_name], df_dtmnmx[tdep_column], color='green', linewidth=0.4)
        ax.plot(df_dtmnmx[dtmx_channel_name], df_dtmnmx[tdep_column], color='red', linewidth=0.4)
        # ax.set_xlabel(dtmn_channel_name + ' - ' + dtmx_channel_name, fontsize=2)
        ax.set_xlim(min(dtmn_min, dtmx_min), max(dtmn_max, dtmx_max))
        ax.set_ylim(logical_file.min_depth, logical_file.max_depth)
        #ax.fill_between(df_dtmnmx[dtmn_channel_name].values, df_dtmnmx[tdep_column].values, 0, facecolor='green', alpha=0.5)
        #ax.fill_between(df_dtmnmx[dtmx_channel_name].values, df_dtmnmx[tdep_column].values, 0, facecolor='lightblue', alpha=0.5)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1, colors='blue')
        ax.yaxis.set_tick_params(width=0.01, colors='blue')
        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=2)
        ax.yaxis.set_major_locator(ylocator)

        # Add header labels - DTMIN
        ax01 = annotate_axis_header_label(ax, (dtmn_min, dtmn_max), dtmn_channel_name, 'green', 5)

        # Add header labels - DTMAX
        ax01 = annotate_axis_header_label(ax, (dtmx_min, dtmx_max), dtmx_channel_name, 'red', 25)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")


def plot_atc(axs, df_single_dim_data, atc_channel_names, logical_file, ylocator):
    '''

    :param axs:
    :param df_single_dim_data:
    :param atc_channel_names:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:

        tdep_column = io_const.TDEP_COLUMN
        logs = df_single_dim_data[[tdep_column] + atc_channel_names]
        # logs = logs[logs != -999.25].dropna()
        logs = logs.replace({io_const.BAKER_DEFALUT_NAN: 0})
        logs = logs.replace({np.nan: 0})

        atc_min = -5  # logs[channel].min()
        atc_max = 20  # logs[channel].max()

        color_list = ['green', 'red', 'blue', 'yellow', 'darkcyan', 'black']
        # axs = [fig5.add_subplot(spec5[0, 3], fig5.add_subplot(spec5[0, 4]), fig5.add_subplot(spec5[0, 5]),
        #                        fig5.add_subplot(spec5[0, 6]), fig5.add_subplot(spec5[0, 7]), fig5.add_subplot(spec5[0, 8]))]
        for (ax, channel, color) in list(zip(axs, atc_channel_names, color_list)):
            color = 'blue'
            ax.plot(logs[channel], logs[tdep_column], color=color, linewidth=0.4)
            # ax.set_xlabel(channel, fontsize=2)
            ax.set_xlim(atc_min, atc_max)
            ax.set_ylim(logical_file.min_depth, logical_file.max_depth)

            ax.invert_yaxis()
            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=4)
            ax.yaxis.set_major_locator(ylocator)

            # Add header labels
            annotate_axis_header_label(ax, (atc_min, atc_max), channel, color, 5)

            # reduce line width
            reduce_axis_border_width(ax)

        return logs, tdep_column
    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None, None


def plot_wave(fig, ax, df_wave_data, logical_file, ylocator):
    '''

    :param fig:
    :param ax:
    :param df_wave_data:
    :param logical_file:
    :param ylocator:
    :return:
    '''

    try:
        # reduce line width
        reduce_axis_border_width(ax)

        wave_dimension = 250
        wave_samples = np.arange(wave_dimension)
        wf_lim = 300

        if not df_wave_data.empty:

            df_wave_data_valid = df_wave_data[df_wave_data != io_const.BAKER_DEFALUT_NAN].dropna()
            wf_max = df_wave_data_valid.iloc[:, 0:wave_dimension].values.max()
            wf_lim = 0.12 * wf_max

            # Parameters for plotting the waveforms
            cmap = plt.cm.Greys  # plt.cm.Greys, #'seismic' #'viridis'
            wf_pltargs = {
                'cmap': cmap,
                'vmin': -wf_lim,
                'vmax': wf_lim,
            }

            # Plot WAVE as an image
            im = paint_channel(ax, df_wave_data.iloc[:, 0: wave_dimension].values, df_wave_data.index.values, wave_samples,
                               **wf_pltargs)

            # add Colorbar
            add_custom_colorbar(ax, fig, im, 'WAVE')

            # ax.set_xlabel('WAVE', fontsize=2)
            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.1, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

            return im

        else:
            message = "WAVE data not available in the log"
            logger.debug(message)
            missing_data_custom_message(ax, message, 0, 1, logical_file)

            # ax.set_xlabel('WAVE', fontsize=2)
            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.1, colors='blue')
            ax.yaxis.set_tick_params(width=0.1, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def plot_cemo(fig, ax, df_cemo_data, logical_file, ylocator):
    '''

    :param fig:
    :param ax:
    :param df_cemo_data:
    :param logical_file:
    :param ylocator:
    :return:
    '''
    try:
        # reduce line width
        reduce_axis_border_width(ax)

        cemo_dimension = 360
        cem_samples = np.arange(cemo_dimension)

        # cem_data = pd.DataFrame(curves_data[cemo_channel_name])
        # df_cemo_data = df_cemo_data[df_cemo_data != -999.25].dropna()

        # colors = ['red', 'deepskyblue', 'orange', 'turquoise', 'darkturquoise', 'lightseagreen', 'darkcyan', 'teal', 'darkslategray', 'black']
        colors = [preproc.hexa_to_rgb('#FD0100'), preproc.hexa_to_rgb('#65CBFF'), preproc.hexa_to_rgb('#FFCD18'), \
                  preproc.hexa_to_rgb('#19CAB6'), preproc.hexa_to_rgb('#1AB296'), preproc.hexa_to_rgb('#339A7E'), \
                  preproc.hexa_to_rgb('#36634F'), preproc.hexa_to_rgb('#334B33'), preproc.hexa_to_rgb('#333333'), \
                  preproc.hexa_to_rgb('#301B18'), preproc.hexa_to_rgb('#000000')]

        cmap = mpl.colors.ListedColormap(colors)
        vmin = -10
        vmax = 100

        # Parameters for plotting the cemo
        cem_pltargs = {
            'cmap': cmap,
            'vmin': vmin,
            'vmax': vmax,
        }

        # set well name on the CEMO plot axis
        set_well_name_as_axis_title(ax, vmin, vmax, logical_file)

        if not df_cemo_data.empty:
            # Plot CEMO as an image
            im = paint_channel(ax, df_cemo_data.iloc[:, 0:cemo_dimension].values, df_cemo_data.index.values, cem_samples,
                               **cem_pltargs)

            # add Colorbar
            add_custom_colorbar(ax, fig, im, 'CEMO')

            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.01, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

            return im
        else:
            message = "CEMO Data not available in the log"
            logger.debug(message)

            missing_data_custom_message(ax, message, 0, 1, logical_file)

            ax.xaxis.set_label_position('top')
            ax.xaxis.set_tick_params(width=0.01, colors='blue')
            ax.yaxis.set_tick_params(width=0.01, colors='blue')
            ax.tick_params(axis="x", labelsize=2)
            ax.tick_params(axis="y", labelsize=2)
            ax.yaxis.set_major_locator(ylocator)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def plot_casing(fig, ax, casing_df, logical_file, ylocator):
    '''

    :param fig:
    :param ax:
    :param casing_df:
    :param logical_file
    :param ylocator:
    :return:
    '''
    try:

        # reduce line width
        reduce_axis_border_width(ax)

        casing_plot_data = casing_df.loc[logical_file.min_depth:logical_file.max_depth, :]

        cmap = plt.cm.Greys  # plt.cm.Greys, #'seismic', #'viridis',
        vmin = 0
        vmax = 4
        wf_pltargs = {
            'cmap': cmap,
            'vmin': vmin,
            'vmax': vmax,
        }
        ax.invert_yaxis()

        ax.set_ylabel('DEPTH [ft]')
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.01, colors='blue')
        ax.yaxis.set_tick_params(width=0.01, colors='blue')
        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=2)
        ax.yaxis.set_major_locator(ylocator)
        extent = [vmin, vmax, logical_file.max_depth, logical_file.min_depth]

        im = ax.imshow(casing_plot_data.values, aspect='auto', origin='upper', extent=extent, **wf_pltargs)

        # add Colorbar
        add_custom_colorbar(ax, fig, im, 'CASING')

        if np.max(casing_plot_data.values) <= 0:
            message = "Header info missing"
            missing_data_custom_message(ax, message, vmin, vmax, logical_file)

        return im

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def annotate_axis_header_label(ax, x_lim: (-100, 10), header_label, header_color, position: 0):
    ''' function to add plot header info and ticks

    :param ax:
    :param x_lim:
    :param header_label:
    :param header_color:
    :param position:
    :return:
    '''
    try:

        ax01 = ax.twiny()
        ax01.set_xlim(x_lim)
        ax01.spines['top'].set_position(('outward', position))
        ax01.set_xlabel(header_label)
        # ax01.plot(logs.SP, logs.DEPT, label=header_label, color=header_color)
        ax01.set_xlabel(header_label, color=header_color, fontsize=2)
        ax01.tick_params(axis='x', colors=header_color, labelsize=2)
        ax01.tick_params(axis='y', colors=header_color, labelsize=1)
        ax01.grid(True, color='g', linestyle='None', linewidth=0.1)

        ax01.xaxis.set_label_position('top')
        ax01.xaxis.set_tick_params(width=0.01, colors=header_color)
        ax01.yaxis.set_tick_params(width=0.01, colors=header_color)

        # reduce line width
        reduce_axis_border_width(ax01)

        return ax01
    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def add_custom_colorbar(ax, fig, im, bar_label: None):
    ''' function to add colorbar for given image plot as new custom axis

    :param ax:
    :param fig:
    :param im:
    :return:
    '''
    try:

        # reduce line width
        reduce_axis_border_width(ax)

        pos1 = ax.get_position()  # get the original position
        # pos2 = [pos1.x0 + 0.3, pos1.y0 + 0.3,  pos1.width / 2.0, pos1.height / 2.0]
        # logger.debug('pos1', pos1)
        pos2 = [pos1.x0, pos1.height * 1.435, pos1.width, pos1.height * 0.005]
        # logger.debug('pos2', pos2)
        colorbar_ax = fig.add_axes(pos2)
        cbar = fig.colorbar(im, cax=colorbar_ax, orientation="horizontal")
        cbar.ax.tick_params(labelsize=2, width=0.01)
        cbar.ax.set_title(bar_label, size=2)

        return cbar
    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def reduce_axis_border_width(ax):
    '''
    reduce the line width in all direction
    :param ax:
    :return:
    '''
    for axis in ['top', 'bottom', 'left', 'right']:
        ax.spines[axis].set_linewidth(0.01)


def missing_data_custom_message(ax, message, xmin, xmax, logical_file):
    '''

    :param ax:
    :param message:
    :param xmin:
    :param xmax:
    :param logical_file:
    :return:
    '''
    # arrowprops=dict(facecolor='red', shrink=0.1) - removed argument to disable arrow
    ax.annotate(message, xy=((xmin + xmax) / 2, logical_file.min_depth + 200),
                xytext=((xmin + xmax) / 2, logical_file.min_depth + 200),                horizontalalignment='center',
                verticalalignment='center',
                fontsize=3.5, color='red', rotation=90)

    return 1


def set_well_name_as_axis_title(ax, vmin, vmax, logical_file):
    '''

    :param ax:
    :param logical_file:
    :return:
    '''

    # reduce line width
    reduce_axis_border_width(ax)

    ax01 = ax.twiny()
    ax01.set_xlim(vmin, vmax)
    ax01.spines['top'].set_position(('outward', 60))
    ax01.spines["top"].set_color("white")
    ax01.set_xlabel(logical_file.well_name, color="blue", fontsize=7)
    ax01.xaxis.set_label_position('top')
    ax01.xaxis.set_ticks_position("bottom")
    ax01.xaxis.set_tick_params(width=0.0001, colors="white")
    ax01.yaxis.set_tick_params(width=0.0001, colors="white")

    # reduce line width
    reduce_axis_border_width(ax01)

    return 1