# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains functions to support data imputation before 
generation of the input feature matrix for the prediction .
This module also provides utility functions for generating
input feature dataframes

@author: Prabhaker Reddy Vanam
"""

# import os

import numpy as np
import pandas as pd

pd.options.mode.chained_assignment = None
# from joblib import dump
# from joblib import load
# from sklearn.preprocessing import MinMaxScaler

from aon.dlis.io import io_constants as io_const
# from aon.dlis.model import model_helper as ml_helper
import aon.dlis.db.db_connection_prop as db_prop

from PIL import ImageColor as img_color

# Custom Logger
from logging_baker import logger

def get_casing_plot_data(casing_df, logical_file):
    """This is a utility function, which returns Tdept min and Max, dataframe to plot well casing

    :param casing_df: Casing info Dataframe (casing size, zone name , zone min, zone max etc.)
    :param logical_file:
    :return:
    min_depth - Casing start depth
    max_depth - Casing End depth
    casing_dataframe - Casing dataframe to plot
    """
    try:
        casing_df.rename(columns={io_const.HEADER_PARAM_VALUES_COLUMN: 'Value'}, inplace=True)
        casing_size_list = casing_df.Value.unique()

        logger.debug(casing_df)
        if 'Minimum' in casing_df.columns and 'Maximum' in casing_df.columns:

            logger.debug("casing_size_list : " + casing_size_list)
            for cs in casing_size_list:
                cs_values = casing_df[['Minimum', 'Maximum']][casing_df.Value == cs].values
                logger.debug(f"Min-Max: {cs_values.min(), cs_values.max()}")
                if cs.startswith('7'):
                    logical_file.casing7_min = cs_values.min()
                    logical_file.casing7_max = cs_values.max()
                if cs.startswith('9'):
                    logical_file.casing9_min = cs_values.min()
                    logical_file.casing9_max = cs_values.max()
                if cs.startswith('13'):
                    logical_file.casing13_min = cs_values.min()
                    logical_file.casing13_max = cs_values.max()
                if cs.startswith('18'):
                    logical_file.casing18_min = cs_values.min()
                    logical_file.casing18_max = cs_values.max()

        # min_depth = min(logical_file.casing18_min, logical_file.casing18_max, logical_file.casing13_min, logical_file.casing13_max, logical_file.casing9_min, logical_file.casing9_max,
        #                 logical_file.casing7_min, logical_file.casing7_max)
        # max_depth = max(logical_file.casing18_min, logical_file.casing18_max, logical_file.casing13_min, logical_file.casing13_max, logical_file.casing9_min, logical_file.casing9_max,
        #                 logical_file.casing7_min, logical_file.casing7_max)
        else:
            logger.debug("Casing Zones info missing in the header")

        return prepare_casing_plot_data(logical_file)

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def prepare_casing_plot_data(logical_file):
    """ Create a pd.DataFrame that filled with casing data used to plot the casing plot

    Parameters
    ----------
    :param logical_file

    Return value(s)
    ---------------
    :return casing_df: Pandas dataframe with well test data
    """
    try:
        # min_depth = min(casing18_min, casing18_max, logical_file.casing13_min, logical_file.casing13_max, logical_file.casing9_min, logical_file.casing9_max,
        #                 logical_file.casing7_min, logical_file.casing7_max)
        # max_depth = max(casing18_min, casing18_max, logical_file.casing13_min, logical_file.casing13_max, logical_file.casing9_min, logical_file.casing9_max,
        #                 logical_file.casing7_min, logical_file.casing7_max)

        # Dataframe Columns to differentiate the casings
        columns = ['C18L', 'C13L', 'C9L', 'C7L', 'C00', 'C11', 'C7R', 'C9R', 'C13R', 'C18R']

        if logical_file.max_depth >= 1000:

            index = np.arange(logical_file.min_depth, logical_file.max_depth + logical_file.unit_depth,
                              logical_file.unit_depth)
            casing_df = pd.DataFrame(index=index, columns=columns)
            casing_df[io_const.TDEP_COLUMN] = np.arange(logical_file.min_depth,
                                                        logical_file.max_depth + logical_file.unit_depth,
                                                        logical_file.unit_depth)
            casing_df.set_index(io_const.TDEP_COLUMN, inplace=True)
            casing_df = casing_df.fillna(-2)
        else:
            # Dummy index
            index = np.arange(0, 10)
            casing_df = pd.DataFrame(index=index, columns=columns)
            casing_df = casing_df.fillna(-2)

        casing_df[io_const.TDEP_COLUMN] = casing_df.index

        casing_df['C18L'] = casing_df[[io_const.TDEP_COLUMN, 'C18L']].apply(
            lambda x: 2 if x.TDEP <= logical_file.casing18_max else -2, axis=1)
        casing_df['C18R'] = casing_df['C18L']

        casing_df['C13L'] = casing_df[[io_const.TDEP_COLUMN, 'C13L']].apply(
            lambda x: 2 if x.TDEP <= logical_file.casing13_max else -2, axis=1)
        casing_df['C13R'] = casing_df['C13L']

        casing_df['C9L'] = casing_df[[io_const.TDEP_COLUMN, 'C9L']].apply(
            lambda x: 2 if x.TDEP <= logical_file.casing9_max else -2, axis=1)
        casing_df['C9R'] = casing_df['C9L']

        casing_df['C7L'] = casing_df[[io_const.TDEP_COLUMN, 'C7L']].apply(
            lambda x: 2 if logical_file.casing7_min > 0.0 and x.TDEP >= logical_file.casing7_min else -2, axis=1)
        casing_df['C7R'] = casing_df['C7L']

        # drop the index  not to display in the ndarray
        casing_df.drop(columns=[io_const.TDEP_COLUMN], inplace=True)

        return casing_df

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def validate_tool_calibration_error(df_atten, df_final_flags, atten_chan_name: io_const.ATAV_COLUMN, logical_file):
    '''

    :param df_atten:
    :param df_final_flags:
    :param atten_chan_name:
    :param casing9_min:
    :param casing9_max:
    :param casing7_min:
    :param casing7_max:
    :param free_pipe_atten_from_header_9:
    :param free_pipe_atten_from_header_7:
    :return:
    '''

    logger.debug("Calculating Tool Calibration Error....")
    try:
        # filter the final flags with moderate
        # "(" + io_const.CCB_COLUMN + " == 3 or " + io_const.CCB_COLUMN + " == 2) and " + io_const.FREE_PIPE_COLUMN + " == 1")
        # updated query to exclude moderate (TESTING Update)
        df_final_flags_filtered = df_final_flags.query(
            "(" + io_const.CCB_COLUMN + " == 3 ) and " + io_const.FREE_PIPE_COLUMN + " == 1")[
            [io_const.TDEP_COLUMN, io_const.CCB_COLUMN, io_const.FREE_PIPE_COLUMN]]

        df_final_flags_atav = df_final_flags_filtered.merge(df_atten[[io_const.TDEP_COLUMN, atten_chan_name]],
                                                            on=io_const.TDEP_COLUMN)

        # drop invalid rows
        df_final_flags_atav = df_final_flags_atav[df_final_flags_atav[atten_chan_name] != io_const.BAKER_DEFALUT_NAN]

        df_final_flags_atav.set_index(io_const.TDEP_COLUMN, drop=True, inplace=True)

        # if logical_file.casing9_min <= logical_file.min_depth and logical_file.casing9_max > logical_file.min_depth and logical_file.casing9_max <= logical_file.max_depth:
        if logical_file.casing9_max > logical_file.min_depth:
            start_slice = logical_file.casing9_min if logical_file.casing9_min >= logical_file.min_depth else logical_file.min_depth
            end_slice = logical_file.casing9_max if logical_file.casing9_max <= logical_file.max_depth else logical_file.max_depth
            logger.debug(f"9' slice ({start_slice, end_slice})")
            # ignore double casing while calculating Free pipe attenuation (TESTING Update)

            if logical_file.casing13_max > logical_file.casing9_min:
                start_slice = logical_file.casing13_max
                logger.debug(f"9' slice after ignore 13 & 9 double casing - ({start_slice, end_slice})")

            if logical_file.casing9_max > logical_file.casing7_min:
                end_slice = logical_file.casing7_min if logical_file.casing7_min <= logical_file.max_depth else logical_file.max_depth
                logger.debug(f"9' slice after ignore 9 & 7 double casing - ({start_slice, end_slice})")

            df_final_flags_atav_9 = df_final_flags_atav[df_final_flags_atav != io_const.BAKER_DEFALUT_NAN].loc[
                                    int(start_slice): int(end_slice), :]
            if not df_final_flags_atav_9.empty:
                logical_file.free_pipe_atten_calc_9 = np.average(df_final_flags_atav_9[atten_chan_name])
                logical_file.tool_calibration_error_9 = abs(
                    float(logical_file.free_pipe_atten_calc_9) - float(logical_file.free_pipe_atten_9))

        # if logical_file.casing7_min >= logical_file.min_depth and logical_file.casing7_max > logical_file.min_depth and logical_file.casing7_max <= logical_file.max_depth:
        if logical_file.casing7_min < logical_file.max_depth:
            start_slice = logical_file.casing7_min if logical_file.casing7_min >= logical_file.min_depth else logical_file.min_depth
            end_slice = logical_file.casing7_max if logical_file.casing7_max <= logical_file.max_depth else logical_file.max_depth
            logger.debug(f"7' slice ({start_slice, end_slice})")
            # ignore double casing while calculating Free pipe attenuation (TESTING Update)
            if logical_file.casing9_max > logical_file.casing7_min:
                start_slice = logical_file.casing9_max if logical_file.casing9_max >= logical_file.min_depth else logical_file.min_depth
                logger.debug(f"7' slice after ignore double casing - ({start_slice, end_slice})")

            df_final_flags_atav_7 = df_final_flags_atav[df_final_flags_atav != io_const.BAKER_DEFALUT_NAN].loc[
                                    int(start_slice): int(end_slice), :]
            if not df_final_flags_atav_7.empty:
                logical_file.free_pipe_atten_calc_7 = np.average(df_final_flags_atav_7[atten_chan_name])
                logical_file.tool_calibration_error_7 = abs(
                    float(logical_file.free_pipe_atten_calc_7) - float(logical_file.free_pipe_atten_7))

        return True

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return False


def bond_index_calculation(atten_df, atten_chan_name: io_const.ATAV_COLUMN, logical_file):
    # casing9_min, casing9_max, casing7_min, casing7_max, free_pipe_atten_9, free_pipe_atten_7, hi_cutoff_9, hi_cutoff_7):
    ''' Top and bottom depth for casings to be either retrieved from EXPRIS casing table or from log header
    or as an input9 – 5/8’’ casing (Attn-attenuation@free pipe)/(Attn@max - attn@free pipe )Attn@max
    – refer section to d7’’ liner (Attn-attenuation@free pipe)/(Attn@max - attn@free pipe )Attn@max
    – refer section to dBond index to be plotted.

    Parameters:
    -----------
    :param atten_df:
    :param atten_chan_name:
    :param free_pipe_atten_9:
    :param free_pipe_atten_7:
    :param hi_cutoff_9:
    :param hi_cutoff_7:

    :return:
    '''
    try:
        casing9_min = int(logical_file.casing9_min)
        casing9_max = int(logical_file.casing9_max)
        casing7_min = int(logical_file.casing7_min)
        casing7_max = int(logical_file.casing7_max)
        free_pipe_atten_9 = float(logical_file.free_pipe_atten_9)
        free_pipe_atten_7 = float(logical_file.free_pipe_atten_7)
        hi_cutoff_9 = float(logical_file.hi_cutoff_9)
        hi_cutoff_7 = float(logical_file.hi_cutoff_7)

        # clean data
        atten_df = atten_df.replace({io_const.BAKER_DEFALUT_NAN: 0})

        # scale = atten_df[io_const.TDEP_COLUMN][1] - atten_df[io_const.TDEP_COLUMN][0]
        # start = min(casing9_min, casing9_max, casing7_min, casing7_max)
        # end = max(casing9_min, casing9_max, casing7_min, casing7_max)

        atten_df[io_const.BI_9_COLUMN] = 0
        atten_df[io_const.BI_7_COLUMN] = 0

        if hi_cutoff_9 > 0.0 and free_pipe_atten_9 > 0.0:
            span_9 = (hi_cutoff_9 - free_pipe_atten_9) / io_const.SPN_CONSTANT
            atten_max_9 = span_9 + free_pipe_atten_9
            logical_file.span_9 = span_9
            logical_file.atten_max_9 = atten_max_9
            for dep in range(casing9_min, casing9_max):
                atten_df[io_const.BI_9_COLUMN] = (atten_df[atten_chan_name] - free_pipe_atten_9) / (
                            atten_max_9 - free_pipe_atten_9)

        if hi_cutoff_7 > 0.0 and free_pipe_atten_7 > 0.0:
            span_7 = (hi_cutoff_7 - free_pipe_atten_7) / io_const.SPN_CONSTANT
            atten_max_7 = span_7 + free_pipe_atten_7
            logical_file.span_7 = span_7
            logical_file.atten_max_7 = atten_max_7
            for dep in range(casing7_min, casing7_max):
                atten_df[io_const.BI_7_COLUMN] = (atten_df[atten_chan_name] - free_pipe_atten_7) / (
                            atten_max_7 - free_pipe_atten_7)

        # for dep in range(start, end):
        atten_df[io_const.BI_COLUMN] = atten_df[
            [io_const.TDEP_COLUMN, io_const.BI_9_COLUMN, io_const.BI_7_COLUMN]].apply(
            lambda x: x[io_const.BI_9_COLUMN] if casing7_min > 0 and x[io_const.TDEP_COLUMN] < casing7_min else x[
                io_const.BI_7_COLUMN], axis=1)

        return atten_df

    except Exception as ex:
        logger.error(f"ERROR in BI info Extraction from Header {ex}")

    return pd.DataFrame()


def get_bi_header_info(header_info, zone_info, logical_file):
    '''

    :param header_info:
    :param zone_info:
    :return:
    '''
    free_pipe_atten_9 = 0
    free_pipe_atten_7 = 0
    hi_cutoff_9 = 0
    hi_cutoff_7 = 0

    try:
        csod_values = \
        header_info.loc[header_info[io_const.HEADER_PARAM_NAME_COLUMN] == io_const.CASING_SIZE_HEADER_KEY].iloc[0][
            io_const.HEADER_PARAM_VALUES_COLUMN]
        logger.debug(f"Casing Sizes : {csod_values}")
        is_9_inch = False
        is_7_inch = False
        if isinstance(csod_values, np.ndarray):
            listToStr = ' '.join(map(str, csod_values))
            csod_values = listToStr.split(' ')
            logger.debug(len(csod_values))
            if float(csod_values[0]) >= 9.0:
                is_9_inch = True
            else:
                is_7_inch = True
            if len(csod_values) > 1:
                is_7_inch = True
        logger.debug(f"is_9_inch?, is_7_inch? : {is_9_inch, is_7_inch}")

        fpat_values = \
        header_info.loc[header_info[io_const.HEADER_PARAM_NAME_COLUMN] == io_const.FREE_PIPE_ATTEN_HEADE_KEY].iloc[0][
            io_const.HEADER_PARAM_VALUES_COLUMN]
        logger.debug(f"Free Pipe Attenuation : {fpat_values}")
        if isinstance(fpat_values, np.ndarray):
            listToStr = ' '.join(map(str, fpat_values))
            fpat_values = listToStr.split(' ')
            logger.debug(len(fpat_values))
            free_pipe_atten_9 = fpat_values[0]
            if len(fpat_values) > 1:
                free_pipe_atten_7 = fpat_values[1]
        logger.debug(f"Free Pipe Attenuation : {free_pipe_atten_9, free_pipe_atten_7}")

        sbhi_values = \
        header_info.loc[header_info[io_const.HEADER_PARAM_NAME_COLUMN] == io_const.SB_HIGH_CUTOFF_HEADER_KEY].iloc[0][
            io_const.HEADER_PARAM_VALUES_COLUMN]
        logger.debug(f"SB High Cutoff : {sbhi_values}")
        if isinstance(sbhi_values, np.ndarray):
            listToStr = ' '.join(map(str, sbhi_values))
            sbhi_values = listToStr.split(' ')
            logger.debug(len(sbhi_values))
            hi_cutoff_9 = sbhi_values[0]
            if len(sbhi_values) == 2:
                hi_cutoff_7 = sbhi_values[1]
        logger.debug(f"SB High Cutoff : {hi_cutoff_9, hi_cutoff_7}")

        # if 9" doesnt exist , consider 7" FPAT and SBHT
        if not is_9_inch:
            free_pipe_atten_7 = free_pipe_atten_9
            hi_cutoff_7 = hi_cutoff_9
            free_pipe_atten_9 = 0.0
            hi_cutoff_9 = 0.0

        logical_file.free_pipe_atten_9 = float(str(free_pipe_atten_9).strip('\'\''))
        logical_file.free_pipe_atten_7 = float(str(free_pipe_atten_7).strip('\'\''))
        logical_file.hi_cutoff_9 = float(str(hi_cutoff_9).strip('\'\''))
        logical_file.hi_cutoff_7 = float(str(hi_cutoff_7).strip('\'\''))

        return True

    except Exception as ex:
        logger.error(f"ERROR in BI info Extraction from Header{ex}")

    return False


def get_final_cement_bond_flags(df_ccb, df_fp):
    ''' CBL flags(casing to cement bond) - CCB +  VDL flags(cement to formation flags) =
        Final Aggregated (CBL+VDL) cement bond flags
        0 - Poor (lightblue)
        1 - Poor + check data (blue)
        2 - Poor + Possible Poor Cement to Formation bond (darkblue)
        3 - Moderate (orange)
        4 - Fast Formation (brown)
        5 - Good (lightgreen)
        ===========================================
        Poor + Free pipe = Poor (3 + 1 = 0)
        Poor + Not free pipe = Poor (check data) (3 + 2 = 1)
        Good + Free pipe = Fast Formation (1 + 1 = 4)
        Good + Not free pipe = Good (1 + 2 = 5)
        Moderate + Free pipe =  Poor (Possible Poor cement to formation bond) (2 + 1 = 2)
        Moderate + Not free pipe = Moderate (2 + 2 = 3)
        ===========================================

    :param df_ccb:
    :param df_fp:
    :return:
    '''
    try:
        ROW_NUM_COLUMN = 'ROW_NO'
        df_ccb[ROW_NUM_COLUMN] = df_ccb.index
        df_fp[ROW_NUM_COLUMN] = df_fp.index

        df_final_flag = df_ccb.merge(df_fp, on=ROW_NUM_COLUMN)
        # df_final_flag = df_ccb.merge(df_fp, left_index=True)
        df_final_flag[io_const.FINAL_FLAG_COLUMN] = df_final_flag[
            [io_const.CCB_COLUMN, io_const.FREE_PIPE_COLUMN]].apply(
            lambda x: 0 if x.CCB == 0 else (0 if x.CCB == 3 and x.FREE_PIPE == 0 else (
                1 if x.CCB == 3 and x.FREE_PIPE == 2 else (4 if x.CCB == 1 and x.FREE_PIPE == 1 else (
                    5 if x.CCB == 1 and x.FREE_PIPE == 2 else (
                        2 if x.CCB == 2 and x.FREE_PIPE == 1 else (
                            3 if x.CCB == 2 and x.FREE_PIPE == 2 else (
                                0 if x.CCB == 3 and x.FREE_PIPE == 1 else -1))))))),
            axis=1)

        # logger.debug(df_final_flag.head())

        return df_final_flag[[io_const.CCB_COLUMN, io_const.FREE_PIPE_COLUMN, io_const.FINAL_FLAG_COLUMN]]

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def calculate_ccl(df_dtminmax, dtmn_channel_name, dtmx_channel_name):
    ''' IF((Q87>0.1*L87),0,1)
    :param df_dtminmax:
    :return:
    '''
    try:
        #data = df_dtminmax[df_dtminmax[dtmn_channel_name] != io_const.BAKER_DEFALUT_NAN]
        #data.reset_index(inplace=True, drop=True)
        data = df_dtminmax.replace({io_const.BAKER_DEFALUT_NAN: 0})

        data[io_const.CCL_TICK_COL] = data[[dtmn_channel_name, dtmx_channel_name]].apply(
            lambda x: 0 if (x[dtmx_channel_name] - x[dtmn_channel_name]) > (
                    io_const.TRAVEL_TIME_PERCENT * x[dtmn_channel_name]) else 1, axis=1)

        return data[[io_const.TDEP_COLUMN, io_const.CCL_TICK_COL]]

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def calculate_travel_time_anomaly(df_dtminmax, dtmn_channel_name, dtmx_channel_name, unit_depth):
    ''' (DTMX - DTMN ) > (0.1 * DTMN) to be considered as Casing Caller
        this should be maximum of 4 feet in length
        calculate number of points based on the tdept (.25 OR .50)

        =IF((Q87>0.1*L87),0,1)
    :param df_dtminmax:
    :return:
    '''

    try:

        data = df_dtminmax[df_dtminmax[dtmn_channel_name] != io_const.BAKER_DEFALUT_NAN]
        data.reset_index(inplace=True, drop=True)

        data[io_const.CCL_TICK_COL] = data[[dtmn_channel_name, dtmx_channel_name]].apply(
            lambda x: 0 if (x[dtmx_channel_name] - x[dtmn_channel_name]) > (
                    io_const.TRAVEL_TIME_PERCENT * x[dtmn_channel_name]) else 1, axis=1)

        data_ccf = data.copy()

        data_ccf[io_const.TDEP_SHIFT_COL] = data_ccf[io_const.TDEP_COLUMN].shift(-1)

        data_ccf[io_const.CCL_TICK_SHIFT_COL] = data_ccf[io_const.CCL_TICK_COL].shift(-1)

        data_ccf[io_const.CCL_DEPT_MARKER_COL] = data_ccf[
            [io_const.TDEP_COLUMN, io_const.CCL_TICK_COL, io_const.CCL_TICK_SHIFT_COL]].apply(
            lambda x: '00' if x[io_const.CCL_TICK_COL] == x[io_const.CCL_TICK_SHIFT_COL] and x[
                io_const.CCL_TICK_COL] == 0 else (
                '01' if x[io_const.CCL_TICK_COL] != x[io_const.CCL_TICK_SHIFT_COL] and x[
                    io_const.CCL_TICK_COL] == 0 else (
                    '10' if x[io_const.CCL_TICK_COL] != x[io_const.CCL_TICK_SHIFT_COL] and x[
                        io_const.CCL_TICK_COL] == 1 else '11')), axis=1)

        data_ccf_selected = \
            data_ccf.query(io_const.CCL_DEPT_MARKER_COL + " == '10' or " + io_const.CCL_DEPT_MARKER_COL + " == '01' ")[
                [io_const.TDEP_SHIFT_COL, io_const.CCL_DEPT_MARKER_COL]]

        data_ccf_pivot = data_ccf_selected.pivot(columns=io_const.CCL_DEPT_MARKER_COL, values=[io_const.TDEP_SHIFT_COL])
        # data_ccf_pivot.columns

        data_ccf_pivot1 = data_ccf_pivot.copy()

        df_ccf_new = pd.DataFrame(
            {io_const.CCL_START_DEPT_COL: data_ccf_pivot1.iloc[:, 1],
             io_const.CCL_END_DEPT_COL: data_ccf_pivot1.iloc[:, 0]})

        df_ccf_new[io_const.CCL_END_DEPT_COL] = df_ccf_new[[io_const.CCL_END_DEPT_COL]].shift(-1)
        df_ccf_new.dropna(inplace=True)

        df_ccf_new[io_const.CCL_DEPT_DIFF_COL] = df_ccf_new[io_const.CCL_END_DEPT_COL] - df_ccf_new[
            io_const.CCL_START_DEPT_COL]

        df_ccf_new[io_const.CCL_END_DEPT_COL] = df_ccf_new[io_const.CCL_END_DEPT_COL] - unit_depth

        data_ccl_anomaly = df_ccf_new.query(io_const.CCL_DEPT_DIFF_COL + " >@io_const.ANOMALY_DEPT_CUTOFF")[
            [io_const.CCL_START_DEPT_COL, io_const.CCL_END_DEPT_COL, io_const.CCL_DEPT_DIFF_COL]].sort_values(
            by=[io_const.CCL_START_DEPT_COL], ascending=True).dropna(how='any')

        return data_ccl_anomaly
    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def generate_final_cement_quality(df_final_foags, df_calculated_ccl, logical_file):
    '''
    Remove all CCL(0) from the df
    Return depth range for each continues data points as below:
    - 5 Good
    - 4 Fast Formation
    - 3 Moderate
    - 0,1,2 - Poor

    :param df:
    :return:
    '''
    try:
        logger.debug("Generating Final Cement Quality...")

        #logger.debug(df_calculated_ccl.index)
        #logger.debug(df_final_foags.index)
        #df_final_foags.to_csv(f"BB1008_final_flags-{logical_file.min_depth, logical_file.max_depth}.csv")
        #df_calculated_ccl.to_csv(f"BB1008_df_calculated_ccl-{logical_file.min_depth, logical_file.max_depth}.csv")

        df_data = pd.merge(df_final_foags, df_calculated_ccl, on=io_const.TDEP_COLUMN)
        # df_data = pd.concat([df_final_foags, df_ccl.reindex(df_final_foags.index)], axis=1)
        #logger.debug(df_data)

        final_flag_shift_col = io_const.FINAL_FLAG_COLUMN + '_S'
        final_flag_changed_col = io_const.FINAL_FLAG_COLUMN + '_CHANGED'
        tdep_shift_col = io_const.TDEP_COLUMN + '_SHIFT'
        tdep_diff_col = io_const.TDEP_COLUMN + '_DIFF'
        # cutoff = io_const.FINAL_CEMENT_QUALITY_CUTOFF

        # Not Filter CCL
        data_filtered = df_data.query(io_const.CCL_TICK_COL + " == 1")[[io_const.TDEP_COLUMN, io_const.CCL_TICK_COL, io_const.FINAL_FLAG_COLUMN]]

        #data_filtered = df_data[[io_const.TDEP_COLUMN, io_const.CCL_TICK_COL, io_const.FINAL_FLAG_COLUMN]]
        logger.debug(f"df_data : {df_data.head(5)}")
        logger.debug(f"df_data : {df_data.head(5)}")

        logger.debug(f"data_filtered : {data_filtered.head(5)}")

        #last_depth = data_filtered.iloc[-1][data_filtered.columns.get_loc(io_const.TDEP_COLUMN)]
        last_depth = max(data_filtered[io_const.TDEP_COLUMN])

        # rearrange the final flag merge 0,1,2 to single 0
        flag_dict = {0: 0, 1: 0, 2: 0, 3: 3, 4: 4, 5: 5}

        quality_dict = {0: 'Poor', 3: 'Moderate', 4: 'Fast Formation', 5: 'Good'}

        data_filtered[io_const.FINAL_FLAG_COLUMN] = data_filtered[io_const.FINAL_FLAG_COLUMN].map(flag_dict)

        data_filtered[final_flag_shift_col] = data_filtered[io_const.FINAL_FLAG_COLUMN].shift(1)

        data_filtered[tdep_shift_col] = data_filtered[io_const.TDEP_COLUMN].shift(1)

        data_filtered[final_flag_changed_col] = data_filtered[io_const.FINAL_FLAG_COLUMN] != data_filtered[
            final_flag_shift_col]

        data_filtered_true = data_filtered.query(final_flag_changed_col + " == True")[
            [io_const.TDEP_COLUMN, io_const.FINAL_FLAG_COLUMN, final_flag_changed_col, tdep_shift_col]]

        data_filtered_true[tdep_shift_col] = data_filtered_true[tdep_shift_col].shift(-1)

        data_filtered_true[io_const.FINAL_FLAG_COLUMN] = data_filtered_true[io_const.FINAL_FLAG_COLUMN].map(
            quality_dict)

        data_filtered_true.reset_index(inplace=True, drop=True)

        # Add last depth value at NAN position/cell
        data_filtered_true.loc[data_filtered_true.shape[0] - 1, tdep_shift_col] = last_depth

        # commented adding unit depth as its matching - it depends on which TDEP shift
        data_filtered_true[tdep_shift_col] = data_filtered_true[tdep_shift_col] + logical_file.unit_depth

        data_filtered_true[tdep_diff_col] = data_filtered_true[tdep_shift_col] - data_filtered_true[
            io_const.TDEP_COLUMN]

        data_filtered_true = data_filtered_true[
            [io_const.TDEP_COLUMN, tdep_shift_col, io_const.FINAL_FLAG_COLUMN, tdep_diff_col]]

        data_cement_quality = data_filtered_true.query(tdep_diff_col + " >@io_const.FINAL_CEMENT_QUALITY_CUTOFF")[
             [io_const.TDEP_COLUMN, tdep_shift_col, io_const.FINAL_FLAG_COLUMN, tdep_diff_col]].sort_values(
             by=[io_const.TDEP_COLUMN], ascending=True).dropna(how='any')

        '''# merge all continues datavalues to display start_depth and end_depth
        previous_flag =None
        current_flag = ''
        start_depth = ''
        end_depth =''

        data_cement_quality_aggr=pd.DataFrame(columns=data_cement_quality.columns)

        for row in data_cement_quality.itertuples(index=False):
             #logger.debug(row)
             if previous_flag == None:
                 previous_flag = row[2]
                 current_flag = row[2]
                 start_depth = row[0]

             current_flag =  row[2]
             if previous_flag != current_flag:
                 to_append = [start_depth, end_depth, previous_flag, (end_depth-start_depth)]
                 #logger.debug(to_append)
                 df_length = len(data_cement_quality_aggr)
                 data_cement_quality_aggr.loc[df_length] = to_append
                 start_depth = row[0]
                 end_depth = row[1]
             else:
                 end_depth = row[1]

             previous_flag = current_flag

        return data_cement_quality_aggr'''
        return data_cement_quality

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def format_well_name(well_name):
    '''

    :param well_name:
    :return:
    '''
    logger.debug(f"Initial Well name : {well_name}")
    try:
        well_name = str(well_name).strip('[]')
        well_name = well_name.replace('\'', '')

        # assume its correct well number
        correct_well_name = well_name

        had_special_char_init = False
        # split well name by - if it has
        if '-' in correct_well_name:
            had_special_char_init = True
            wn_array = correct_well_name.split('-')
            field_code = wn_array[0]
            # logger.debug(field_code)
            well_number = wn_array[1]
            # logger.debug(well_number)
            additional_chars = ''
            if len(well_number) < 4:
                str_four_dig_num = well_number.zfill(4)
            elif len(well_number) == 4:
                str_four_dig_num = well_number

            if len(wn_array) > 2:
                additional_chars = wn_array[2]

            correct_well_name = field_code + str_four_dig_num + additional_chars
        # validate the total well number, should have min 6 chars in it
        if len(correct_well_name) < 6:
            correct_well_name = correct_well_name[0:2] + correct_well_name[2:].zfill(4)

        # Check the minmum length 10 chars
        well_borehole_length = len(correct_well_name)
        logger.debug(f"Correct Well name : {correct_well_name} and its length: {well_borehole_length}")
        if well_borehole_length < 10 and not had_special_char_init:
            correct_well_name = correct_well_name[0:2] + "0" + correct_well_name[2:well_borehole_length]
            logger.debug(f"Adding additinal '0' in the Correct Well name : {correct_well_name}")

        return correct_well_name

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return None


def validate_zonal_isolation(df_final_flags, df_zone_info, logical_file):
    ''' function calculate the Zonal Isolation confirmed OR not for DENSE Zones
    by validation the cement quality with 3,4,5 flags with continues depth

    :param df_final_flags:
    :param df_zone_info:
    :param logical_file:
    :return:df_dense_zones_result
    '''

    try:
        # [['UWI', 'UBHI', 'LAYER_NAME', 'LAYER_TYPE', 'TOP', 'BASE']]

        df_dense_zones = df_zone_info.query(db_prop.DB_LAYER_TYPE_COLUMN + " == @db_prop.DB_LAYER_TYPE_ZONE_DENSE ")
        # logger.debug(df_dense_zones.head(5))

        df_dense_zones_result = df_dense_zones.copy()
        df_dense_zones_result[io_const.ZONE_THICKNESS_EXCEL_COLUMN] = df_dense_zones[db_prop.DB_BASE_COLUMN] - \
                                                                      df_dense_zones[db_prop.DB_TOP_COLUMN]
        df_dense_zones_result[io_const.ZONAL_ISOLATION_EXCEL_COLUMN] = None

        top_dense_depths = list(df_dense_zones[db_prop.DB_TOP_COLUMN].values)
        base_dense_depths = list(df_dense_zones[db_prop.DB_BASE_COLUMN].values)
        zonal_isolation_list = []

        for dense_start_dept, dense_end_dept in zip(top_dense_depths, base_dense_depths):
            # logger.debug("Dense : (", dense_start_dept, dense_end_dept, ") Log depth : (", logical_file.min_depth, logical_file.max_depth,")")

            # skip zones for which dense_end_dept is greater than available data max_depth
            if dense_end_dept <= logical_file.max_depth and dense_start_dept >= logical_file.min_depth:

                # logger.debug(f"Dense start & end : {dense_start_dept}, {dense_end_dept}")
                dence_depth = dense_end_dept - dense_start_dept
                # consider expected good quality same as dense depth if it is <= 10 , else 10% of the dense depth
                expected_good_qc_depth = dence_depth if dence_depth <= io_const.MIN_THICKNESS_FOR_ZONAL_ISOLATION else io_const.ZONAL_ISOLATION_PERCENT * dence_depth
                # logger.debug(f"expected_good_qc_depth : {expected_good_qc_depth}")

                # get records from cement quality dataframe based on TOP and BASE Depth of the Zone
                df_zone_cement_qc = df_final_flags.query(
                    io_const.TDEP_COLUMN + f" >= {dense_start_dept} & " + io_const.TDEP_COLUMN + f" <= {dense_end_dept}")[
                    [io_const.TDEP_COLUMN, io_const.FINAL_FLAG_COLUMN]]

                # logger.debug(df_zone_cement_qc.head(5))
                good_qc_sum = 0
                zonal_isolation = io_const.ZONE_ISOLATION_NOT_CONFIRMED_MSG
                for row in df_zone_cement_qc.itertuples(index=False):
                    # logger.debug(row)
                    if row[1] in [3, 4, 5]:
                        good_qc_sum = good_qc_sum + logical_file.unit_depth
                        # logger.debug(f"Cumilative sum :{good_qc_sum}")
                        if good_qc_sum >= int(expected_good_qc_depth):
                            zonal_isolation = io_const.ZONE_ISOLATION_CONFIRMED_MSG
                            break
                    else:
                        good_qc_sum = 0

                # logger.debug(f'dzonal_isolation: {zonal_isolation}')
                zonal_isolation_list.append(zonal_isolation)

            else:
                message = f"WARNING: Dense Zone depth range out of available Log data range {logical_file.min_depth, logical_file.max_depth}"
                zonal_isolation_list.append(message)
                logger.debug(message)

        df_dense_zones_result[io_const.ZONAL_ISOLATION_EXCEL_COLUMN] = zonal_isolation_list

        return df_dense_zones_result

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def channelling_identification(df_cemo_data, df_final_flag, unit_depth: 0.25):
    '''

    :param df_cemo:
    :param df_final_flag:
    :param unit_depth
    :return:
    '''
    try:
        column_names = ['From Depth', 'To Depth', 'Channel Thickness']
        empty_df = pd.DataFrame(columns=column_names)

        # drop null values which are not required for channelling
        df_cemo_data = df_cemo_data[df_cemo_data != io_const.BAKER_DEFALUT_NAN].dropna()
        # logger.debug(df_cemo.columns)

        # Identify Minimum value in each row
        df_cemo_data[io_const.ROW_MIN_COLUMN] = df_cemo_data.min(axis=1)

        # Mark rows where minimum value less than cutoff value
        df_cemo_data[io_const.CHANNELLING_COLUMN] = df_cemo_data.apply(
            lambda x: True if x[io_const.ROW_MIN_COLUMN] <= io_const.CHANNELLING_CUTOFF_VALUE else False, axis=1)

        # Extract only channelling column with index into different dataframe
        df_channelling = df_cemo_data[[io_const.CHANNELLING_COLUMN]]  # TDEP is in index column

        # Copy index as separate column in the dataframe
        df_channelling[io_const.TDEP_COLUMN] = df_channelling.index
        logger.debug(f"df_channelling.columns {df_channelling.columns}")

        # ======================================= SAME as TEST CLASS ========================================
        # Merge dataframe based on TDEP
        df_channelling = df_channelling.merge(df_final_flag, on=io_const.TDEP_COLUMN)
        # df_channelling[io_const.FINAL_FLAG_COLUMN] = df_final_flag[io_const.FINAL_FLAG_COLUMN]
        logger.debug(f"df_channelling merged with final flags {df_channelling.head(2)}")

        # Before filtering the channelling colums, shift TDEP into new column to preserve the next index value
        df_channelling[io_const.TDEP_SHIFT_FOR_BASE_COLUMN] = df_channelling[io_const.TDEP_COLUMN].shift(-1)
        logger.debug(f"df_channelling after TDEP shift {df_channelling.head(2)}")

        # Filter data based on channelling flag
        df_channelling_true = df_channelling.query(io_const.CHANNELLING_COLUMN + "== True")
        logger.debug(f"df_channelling_true {df_channelling_true.head(2)}")

        # Filter data further based on final flag
        df_channelling_true_filtered = df_channelling_true[df_channelling_true[io_const.FINAL_FLAG_COLUMN] == 3]
        logger.debug(f"df_channelling_true_filtered {df_channelling_true_filtered.head(2)}")

        if not df_channelling_true_filtered.empty:
            # Apply shift on TDEP to validate the difference in start and end depth to get identify the continue
            df_channelling_true_filtered[io_const.TDEP_SHIFT_COL] = df_channelling_true_filtered[
                io_const.TDEP_COLUMN].shift(-1)
            logger.debug(f"df_channelling_true_filtered TDEP Shift {df_channelling_true_filtered.head(2)}")

            # tick the rows where there is the difference in the first TDEP shift (TDEP_END) and Second TDEP shift (TDEP_SHIFT)
            df_channelling_true_filtered[io_const.CHANNELLING_CHANGE_MARK_COLUMN] = df_channelling_true_filtered.apply(
                lambda x: 1 if ((x[io_const.TDEP_SHIFT_COL] - x[io_const.TDEP_SHIFT_FOR_BASE_COLUMN]) > 0) else 0, axis=1)
            logger.debug(f"Data with change ticks {df_channelling_true_filtered.head(2)}")

            # Shift the Change mark column to identify the marked column
            df_channelling_true_filtered[io_const.CHANNELLING_CHANGE_MARK_SHIFT_D_COLUMN] = df_channelling_true_filtered[
                io_const.CHANNELLING_CHANGE_MARK_COLUMN].shift(1)
            logger.debug(f"Change mark shift {df_channelling_true_filtered.head(2)}")

            # Fill nan with 1 to cover last record
            df_channelling_true_filtered[io_const.CHANNELLING_CHANGE_MARK_SHIFT_D_COLUMN] = df_channelling_true_filtered[
                io_const.CHANNELLING_CHANGE_MARK_SHIFT_D_COLUMN].fillna(1)
            logger.debug(f"Fill nan with 1 to cover last record {df_channelling_true_filtered.tail(2)}")

            # Filter rows only channelling ranges (change mark != Shifted change marks)
            df_channelling_true_filtered = df_channelling_true_filtered.query(
                io_const.CHANNELLING_CHANGE_MARK_COLUMN + " != " + io_const.CHANNELLING_CHANGE_MARK_SHIFT_D_COLUMN)[
                [io_const.TDEP_COLUMN, io_const.TDEP_SHIFT_FOR_BASE_COLUMN, io_const.TDEP_SHIFT_COL,
                 io_const.CHANNELLING_CHANGE_MARK_COLUMN, io_const.CHANNELLING_CHANGE_MARK_SHIFT_D_COLUMN]]
            logger.debug(f"Filter rows only channelling ranges {df_channelling_true_filtered.head(2)}")

            # Adjust the TDEP_BASE column with shift up and change mark up
            df_channelling_true_filtered[io_const.TDEP_SHIFT_FOR_BASE_COLUMN] = df_channelling_true_filtered[
                io_const.TDEP_SHIFT_FOR_BASE_COLUMN].shift(-1)
            df_channelling_true_filtered[io_const.CHANNELLING_CHANGE_MARK_COLUMN] = df_channelling_true_filtered[
                io_const.CHANNELLING_CHANGE_MARK_COLUMN].shift(-1)
            logger.debug(f"TDEP_BASE and CHANGE MARK shifted {df_channelling_true_filtered.head(2)}")

            # calculae the channel thickness TDEP_END - TDEP
            df_channelling_true_filtered[io_const.CHANNELLING_THICKNESS_COLUMN] = df_channelling_true_filtered[
                                                                                      io_const.TDEP_SHIFT_FOR_BASE_COLUMN] - \
                                                                                  df_channelling_true_filtered[
                                                                                      io_const.TDEP_COLUMN]
            logger.debug(f"Channel Thickness calculated {df_channelling_true_filtered.head(2)}")

            # Finally filter data where changed and with thickness cutoff
            df_channelling_true_filtered = \
                df_channelling_true_filtered.query(
                    io_const.CHANNELLING_CHANGE_MARK_COLUMN + " == 1 & " + io_const.CHANNELLING_THICKNESS_COLUMN + " > @io_const.MAX_CHANNELLING_THECKNESS")[
                    [io_const.TDEP_COLUMN, io_const.TDEP_SHIFT_FOR_BASE_COLUMN, io_const.CHANNELLING_THICKNESS_COLUMN]]
            logger.debug(f"Final data {df_channelling_true_filtered.head(2)}")

            #column_names = ['From Depth', 'To Depth', 'Channel Thickness']
            df_channelling_true_filtered.columns = column_names

            df_channelling_true_filtered[io_const.CHANNELLING_REMARKS_COLUMN] = io_const.CHANNELLING_REMARKS_FOR_USER
            logger.debug(f"Return Dataframe {df_channelling_true_filtered.head(2)}")

            return df_channelling_true_filtered

        else:
            logger.warning(f"Zero records in final flags with value 3");
            return empty_df

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return empty_df


def apply_correction_to_cemo_atten_data(df_cemo_data, logical_file):
    ''' Convert CEMO (in Attenuation form) = Attenuation(min) + (BI/100 *(Attenuation(max) – Attenuation(min)))
    then df_cemo_data_atten_corrected = df_cemo_data_atten/Correction factor

    :param df_cemo_data:
    :param logical_file:
    :return:
    '''
    logger.debug("Correcting CEMO Atten data ...")
    try:
        # consider only 360 points, exclude TDEP column
        df_cemo_data_copy = df_cemo_data.copy()
        df_cemo_data_copy = df_cemo_data_copy.iloc[:, 0:360]
        # copy data to new Dataframe to modify
        df_cemo_data_atten_corrected = df_cemo_data_copy.copy()

        # df_cemo_data_atten_corrected_9 = pd.DataFrame()
        # df_cemo_data_atten_corrected_7 = pd.DataFrame()

        if logical_file.casing9_max > logical_file.min_depth and float(logical_file.correction_factor_9) > 1.0:
            start_slice_9 = logical_file.casing9_min if logical_file.casing9_min >= logical_file.min_depth else logical_file.min_depth
            end_slice_9 = logical_file.casing9_max if logical_file.casing9_max <= logical_file.max_depth else logical_file.max_depth
            df_cemo_data_9 = df_cemo_data_copy.loc[int(start_slice_9): int(end_slice_9), :]
            if not df_cemo_data_9.empty:
                logger.debug(df_cemo_data_9.head(1))
                df_cemo_data_atten_corrected_9 = ((df_cemo_data_9 * 0.01 * logical_file.span_9) + float(
                    logical_file.free_pipe_atten_9)) / logical_file.correction_factor_9
                logger.debug(df_cemo_data_atten_corrected_9.head(1))
                df_cemo_data_atten_corrected.loc[int(start_slice_9): int(end_slice_9),
                :] = df_cemo_data_atten_corrected_9

        if logical_file.casing7_min < logical_file.max_depth and float(logical_file.free_pipe_atten_7) > 1.0:
            start_slice_7 = logical_file.casing7_min if logical_file.casing7_min >= logical_file.min_depth else logical_file.min_depth
            end_slice_7 = logical_file.casing7_max if logical_file.casing7_max <= logical_file.max_depth else logical_file.max_depth
            df_cemo_data_7 = df_cemo_data_copy.loc[int(start_slice_7): int(end_slice_7), :]
            if not df_cemo_data_7.empty:
                logger.debug(df_cemo_data_7.head(1))
                df_cemo_data_atten_corrected_7 = ((df_cemo_data_7 * 0.01 * logical_file.span_7) + float(
                    logical_file.free_pipe_atten_7)) / logical_file.correction_factor_7
                logger.debug(df_cemo_data_atten_corrected_7.head(1))
                df_cemo_data_atten_corrected.loc[int(start_slice_7): int(end_slice_7),
                :] = df_cemo_data_atten_corrected_7

        # if not df_cemo_data_atten_corrected_9.empty:
        #     df_cemo_data_atten_corrected = df_cemo_data_atten_corrected.merge(df_cemo_data_atten_corrected_9, on=df_cemo_data_atten_corrected_9.index)
        #
        # if not df_cemo_data_atten_corrected_7.empty:
        #     df_cemo_data_atten_corrected = df_cemo_data_atten_corrected.merge(df_cemo_data_atten_corrected_7, on=df_cemo_data_atten_corrected_7.index)

        # Copy index column back to TDEP column
        df_cemo_data_atten_corrected[io_const.TDEP_COLUMN] = df_cemo_data_atten_corrected.index
        logger.debug(df_cemo_data_atten_corrected.head(2))

        return df_cemo_data_atten_corrected

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def apply_correction_to_single_dim_data(df_single_dim_data, corrected_coloumns, logical_file):
    ''' df_single_dim_data = df_single_dim_data/correction_factor_9 or correction_factor_7

    :param df_single_dim_data:
    :param logical_file:
    :return:
    '''
    logger.debug("Correcting ATC data...")
    try:
        # copy dataframe data to modify
        df_single_dim_data_corrected = df_single_dim_data[corrected_coloumns]

        df_single_dim_data_corrected = df_single_dim_data_corrected.replace(to_replace=io_const.BAKER_DEFALUT_NAN,
                                                                            value=0)

        # df_single_dim_data_corrected_9 = pd.DataFrame()
        # df_single_dim_data_corrected_7 = pd.DataFrame()

        if logical_file.casing9_max > logical_file.min_depth and float(logical_file.correction_factor_9) > 1.0:
            start_slice_9 = logical_file.casing9_min if logical_file.casing9_min >= logical_file.min_depth else logical_file.min_depth
            end_slice_9 = logical_file.casing9_max if logical_file.casing9_max <= logical_file.max_depth else logical_file.max_depth
            df_single_dim_data_9 = df_single_dim_data[corrected_coloumns].loc[int(start_slice_9): int(end_slice_9), :]
            if not df_single_dim_data_9.empty:
                # logger.debug(df_single_dim_data_9.head(1))
                df_single_dim_data_corrected_9 = df_single_dim_data_9 / float(logical_file.correction_factor_9)
                # logger.debug(df_single_dim_data_corrected_9.head(1))
                df_single_dim_data_corrected.loc[int(start_slice_9): int(end_slice_9),
                :] = df_single_dim_data_corrected_9
                # logger.debug(df_single_dim_data_corrected.loc[int(start_slice_9): int(end_slice_9), :].head(1))

        if logical_file.casing7_min < logical_file.max_depth and float(logical_file.free_pipe_atten_7) > 1.0:
            start_slice_7 = logical_file.casing7_min if logical_file.casing7_min >= logical_file.min_depth else logical_file.min_depth
            end_slice_7 = logical_file.casing7_max if logical_file.casing7_max <= logical_file.max_depth else logical_file.max_depth
            df_single_dim_data_7 = df_single_dim_data[corrected_coloumns].loc[int(start_slice_7): int(end_slice_7), :]
            if not df_single_dim_data_7.empty:
                # logger.debug(df_single_dim_data_7.head(1))
                df_single_dim_data_corrected_7 = df_single_dim_data_7 / float(logical_file.correction_factor_7)
                # logger.debug(df_single_dim_data_corrected_7.head(1))
                df_single_dim_data_corrected.loc[int(start_slice_7): int(end_slice_7),
                :] = df_single_dim_data_corrected_7
                # logger.debug(df_single_dim_data_corrected.loc[int(start_slice_7): int(end_slice_7), :].head(1))

        # Copy index column back to TDEP column
        df_single_dim_data_corrected[io_const.TDEP_COLUMN] = df_single_dim_data_corrected.index

        return df_single_dim_data_corrected

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def convert_corrected_cemo_to_bond_index(df_cemo_data_atten_corrected, logical_file):
    ''' ((Correct Attenuation(CEMO) – Attenuation minimum)/(Attenuation(max) – Attenuation(min))) * 100

    :param df_cemo_data_atten_corrected:
    :param logical_file:
    :return:
    '''
    logger.debug("Converting CEMO Attenuation corrected data back to Bond Index")
    try:
        df_cemo_data_bi = df_cemo_data_atten_corrected.copy()

        # df_cemo_data_bi_9 = pd.DataFrame()
        # df_cemo_data_bi_7 = pd.DataFrame()

        if logical_file.casing9_max > logical_file.min_depth and float(logical_file.correction_factor_9) > 1.0:
            start_slice_9 = logical_file.casing9_min if logical_file.casing9_min >= logical_file.min_depth else logical_file.min_depth
            end_slice_9 = logical_file.casing9_max if logical_file.casing9_max <= logical_file.max_depth else logical_file.max_depth
            df_cemo_data_attn_9 = df_cemo_data_atten_corrected.loc[int(start_slice_9): int(end_slice_9), :]
            if not df_cemo_data_attn_9.empty:
                logger.debug(df_cemo_data_attn_9.head(1))
                df_cemo_data_bi_9 = ((df_cemo_data_attn_9 - float(logical_file.free_pipe_atten_9)) / float(
                    logical_file.span_9)) * 100
                logger.debug(df_cemo_data_bi_9.head(1))
                df_cemo_data_bi.loc[int(start_slice_9): int(end_slice_9), :] = df_cemo_data_bi_9
                logger.debug(df_cemo_data_bi_9.head(1))

        if logical_file.casing7_min < logical_file.max_depth and float(logical_file.free_pipe_atten_7) > 1.0:
            start_slice_7 = logical_file.casing7_min if logical_file.casing7_min >= logical_file.min_depth else logical_file.min_depth
            end_slice_7 = logical_file.casing7_max if logical_file.casing7_max <= logical_file.max_depth else logical_file.max_depth
            df_cemo_data_attn_7 = df_cemo_data_atten_corrected.loc[int(start_slice_7): int(end_slice_7), :]
            if not df_cemo_data_attn_7.empty:
                logger.debug(df_cemo_data_attn_7.head(1))
                df_cemo_data_bi_7 = ((df_cemo_data_attn_7 - float(logical_file.free_pipe_atten_7)) / float(
                    logical_file.span_7)) * 100
                logger.debug(df_cemo_data_bi_7.head(1))
                df_cemo_data_bi.loc[int(start_slice_7): int(end_slice_7), :] = df_cemo_data_bi_7
                logger.debug(df_cemo_data_bi_7.head(1))

        # if not df_cemo_data_bi_9.empty:
        #     df_cemo_data_bi.merge(df_cemo_data_bi_9, on=df_cemo_data_bi.index)
        #
        # if not df_cemo_data_bi_7.empty:
        #     df_cemo_data_bi.merge(df_cemo_data_bi_7, on=df_cemo_data_bi.index)

        # Copy index column back to TDEP column
        df_cemo_data_bi[io_const.TDEP_COLUMN] = df_cemo_data_bi.index
        logger.debug(df_cemo_data_bi.head(2))

        return df_cemo_data_bi

    except Exception as ex:
        logger.error(f"ERROR : {ex}")

    return pd.DataFrame()


def validate_zonal_isolation_at_target_reservoir(df_final_flags, logical_file):
    '''
    Zonal isolation at target reservoir

    Pick TDEP bottom depth value
    Above 30ft, there should be continuous good and moderate cement

    :param df_final_flags:
    :param logical_file:
    :return:
    '''
    logger.debug("Validation Zonal isolation at target reservoir")
    try:

        if not df_final_flags.empty:

            bottom_depth = logical_file.max_depth
            start_depth = bottom_depth - io_const.MIN_THICKNESS_AT_TARGET_RESERVOIR
            #logger.debug(start_depth, bottom_depth)

            # get records from cement quality dataframe based on start_depth and bottom_depth Depth at target reservoir
            # [1 0 2 3] # consider sum of depths >=3
            df_final_flags_at_target_reservoir = df_final_flags.query(
                io_const.TDEP_COLUMN + f" >= {start_depth} & " + io_const.TDEP_COLUMN + f" <= {bottom_depth}")[
                [io_const.TDEP_COLUMN, io_const.FINAL_FLAG_COLUMN]]

            #logger.debug(df_final_flags_at_target_reservoir.head(5))

            #logger.debug(df_final_flags_at_target_reservoir[io_const.FINAL_FLAG_COLUMN].unique())

            good_qc_sum = 0
            for row in df_final_flags_at_target_reservoir.itertuples(index=False):
                # logger.debug(row)
                if row[1] in [3, 4, 5]:
                    good_qc_sum = good_qc_sum + logical_file.unit_depth
                    #logger.debug(f"Cumilative sum :{good_qc_sum}")
                    if good_qc_sum >= int(io_const.MIN_VALID_THICKNESS_AT_TARGET_RESERVOIR):
                        logical_file.zonal_isolation_at_target_reservoir = f"Zonal isolation at target reservoir {start_depth, bottom_depth} Confirmed"
                        break
                    else:
                        logical_file.zonal_isolation_at_target_reservoir = f"Zonal isolation at target reservoir {start_depth, bottom_depth} not Confirmed as it doesnt meet {io_const.MIN_VALID_THICKNESS_AT_TARGET_RESERVOIR}ft. continues thickness good/moderate cement."
                else:
                    good_qc_sum = 0

        else:
            logger.debug("Final flags not available...")

    except Exception as ex:

        logger.error(f"ERROR : {ex}")

    return True


def validate_zonal_isolation_at_acquifer(df_final_flags, df_zone_info_db, logical_file):
    '''
    Zonal isolation at acquifer
    Above Shuabia-1 (BAB member) in 300ft layer thickness ,
    There should be 150ft good and moderate cement (it doesn’t required to be continuous)

    :param df_final_flags:
    :param df_zone_info_db:
    :param logical_file:
    :return:
    '''

    logger.debug("Validation Zonal isolation at acquifer")

    try:

        if not df_zone_info_db.empty:

            df_zone_filtered = df_zone_info_db.query(db_prop.DB_LAYER_TYPE_COLUMN + " == @db_prop.DB_LAYER_TYPE_ZONE ")
            # sort by topdepth and pick first top depth as base
            df_zone_filtered.sort_values(by=db_prop.DB_TOP_COLUMN, ascending=True, inplace=True)
            #logger.debug(df_zone_filtered.head(5))
            df_zone_filtered.reset_index(inplace=True)
            #logger.debug(df_zone_filtered.head(10))
            bottom_depth = df_zone_filtered.loc[0, db_prop.DB_TOP_COLUMN]
            #logger.debug(bottom_depth)
            start_depth = bottom_depth - io_const.MIN_THICKNESS_AT_ACQUIFER
            #logger.debug(start_depth, bottom_depth)

            if not df_final_flags.empty:

                # get records from cement quality dataframe based on start_depth and bottom_depth Depth at acquifer
                df_final_flags_at_acquifer = df_final_flags.query(
                    io_const.TDEP_COLUMN + f" >= {start_depth} & " + io_const.TDEP_COLUMN + f" <= {bottom_depth}")[
                    [io_const.TDEP_COLUMN, io_const.FINAL_FLAG_COLUMN]]

                #logger.debug(df_final_flags_at_acquifer.head(5))

                if not df_final_flags_at_acquifer.empty:
                    acquifer = df_final_flags_at_acquifer[io_const.FINAL_FLAG_COLUMN].value_counts()
                    #logger.debug(acquifer)
                    total_quality = 0
                    for flag in acquifer.index:
                        if flag >= 3:
                            total_quality = total_quality + (acquifer[flag] * logical_file.unit_depth)

                    #logger.debug(total_quality)
                    if total_quality >= (io_const.MIN_THICKNESS_AT_ACQUIFER * 0.5):

                        logical_file.zonal_isolation_at_acquifer_msg = f"Zonal isolation at acquifer {start_depth, bottom_depth}ft Confirmed as it has {total_quality}ft. thickness of good/moderate cement"
                    else:

                        logical_file.zonal_isolation_at_acquifer_msg = f"Zonal isolation at acquifer {start_depth, bottom_depth}ft not Confirmed as it has only {total_quality}ft. thickness of good/moderate cement"
                else:
                    logger.debug("Final flags not matching...")
                    logical_file.zonal_isolation_at_acquifer_msg = f"Data not available in the cement log for evaluating Zonal isolation at acquifer at {start_depth, bottom_depth}ft."

            else:

                logger.debug("Final flags not available...")
                logical_file.zonal_isolation_at_acquifer_msg = f"Data not available in the cement log for evaluating Zonal isolation at acquifer at {start_depth, bottom_depth}ft."


        else:
            logger.debug("Zone data not retrieved from EXPRIS...")
            logical_file.zonal_isolation_at_acquifer_msg = f"Zones data not available in EXPRIS."

        return True

    except Exception as ex:

        logger.error(f"ERROR : {ex}")

    return False


def hexa_to_rgb(hexa_code: '#333333'):
    '''
    :param hexa_code:
    :return:
    '''
    rgb_0_1 = [i / 256 for i in img_color.getrgb(hexa_code)]

    return tuple(rgb_0_1)
