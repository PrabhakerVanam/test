# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains utility functions, which support creation of predictive
models during different stages of machine learning model development.

@author: Prabhaker Reddy Vanam
"""

import os

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.metrics import f1_score
from sklearn.model_selection import train_test_split

from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const

# Custom Logger
from logging_baker import logger

def save_model(model, model_file_ame='finalized_model.joblib'):
    """ save the model to disk
    """
    joblib.dump(model, model_file_ame)


def load_model(model_file_ame='finalized_model.joblib'):
    """ load model from the disk
    """
    model = joblib.load(model_file_ame)

    return model


def get_model_name(model_name, model_name_prefix, model_fold=None, scaled_var=None):
    """This function returns the name of a model to be saved to a file, based upon
    the parameters passed.

    Parameters
    ----------
    :param model_name: Name of the model
    :param model_name_prefix: Prefix for the name of model
    :param model_fold: Fold in KFold this model belongs to
    :param scaled_var: Input variable being scaled (optional, if not data scaler)

    Return value(s)
    ---------------
    :return model_name: Name of the model to be saved to file
    """
    model_name = model_name + io_const.MODEL_SEPARATOR + model_name_prefix
    if model_fold != None:
        model_name += io_const.MODEL_SEPARATOR + io_const.MODEL_FOLD + \
                      str(model_fold)
    if scaled_var != None:
        model_name += io_const.MODEL_SEPARATOR + scaled_var
    model_name += io_const.MODEL_NAME_SUFFIX
    return model_name


def build_cbl_cement_to_casing_model(df, feature_names=io_const.ATC_COLUMN_LIST,  target_label='CCB'):
    """This python function develops machine learning (ML) models with KFold
    cross-validation for the provided dataframe, by using provided names
    of X and y columns in the dataframe. If instructed, it also saves the
    developed models to files.

    Paramaters
    ----------
    :param df: Pandas dataframe with the values to model   
    :param feature_names: List providing names of columns to be used as input
                    features (X), and target variable (y; last column has target)
    :param target_label: target variable


    Return value(s)
    ---------------
    :return conf_matrix:
    :return classify_report:
    :return accur_score:
    """
    # Extract the Pandas dataframe rows, where all the columns have finite
    # values, and target column has non-zero values
    rename_col_dict = {'TDEP, ft': 'TDEP', 'AMAV.I, mV': 'AMAV', 'ATAV.I, dB/ft': 'ATAV',
                       'ATC1.I, dB/ft': 'ATC1', 'ATC2.I, dB/ft': 'ATC2', 'ATC3.I, dB/ft': 'ATC3',
                       'ATC4.I, dB/ft': 'ATC4',
                       'ATC5.I, dB/ft': 'ATC5', 'ATC6.I, dB/ft': 'ATC6', 'CCL.I, mV': 'CCL', 'DTMN.I, us/ft': 'DTMN',
                       'DTMX.I, us/ft': 'DTMX', 'Cement_flag (CBL)': 'CQF'}

    df.rename(columns=rename_col_dict, inplace=True)
    # feature_names=io_const.ATC_COLUMN_LIST
    # target_label=['CQF']

    X = df[feature_names]
    y = df[target_label]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=ml_const.TEST_SIZE, random_state=ml_const.RANDOM_STATE)

    classifier = RandomForestClassifier(n_estimators=ml_const.N_ESTIMATORS, random_state=ml_const.RANDOM_STATE,
                                        max_depth=ml_const.MAX_DEPTH, min_samples_leaf=ml_const.MIN_SAMPLES_LEAF,
                                        verbose=ml_const.VERBOSE)
    classifier.fit(X_train, y_train.values.ravel())

    feature_imp = pd.Series(classifier.feature_importances_, index=feature_names).sort_values(ascending=False)
    print(feature_imp)

    y_pred = classifier.predict(X_test)

    conf_matrix = confusion_matrix(y_test, y_pred)
    print("confusion_matrix", conf_matrix)

    classify_report = classification_report(y_test, y_pred)
    print("classification_report", classify_report)

    accur_score = accuracy_score(y_test, y_pred)
    print("accuracy_score:", accur_score)

    f1score = f1_score(y_test, y_pred, average='weighted', labels=np.unique(y_pred))
    print("f1 accuracy_score:", f1score)

    # print(set(y_test) - set(y_pred))

    return conf_matrix, classify_report, accur_score, classifier


def build_cbl_free_pipe_model(df_free_pipe, feature_col_start_idx=29, feature_col_end_idx=140, \
                              target_label_idx=1):
    """This python function develops machine learning (ML) models for the provided dataframe (VDL) data,
    by using 30-140 columns of X and y columns in the dataframe. If instructed, it also saves the
    developed models to files.
    
    Paramaters
    ----------
    :param df: Pandas dataframe with the values to model
    :param feature_col_start_idx: Starting column index of the wave data
    :param feature_col_end_idx: Ending column index of the wave data
    :param target_label_idx: Target Label index


    Return value(s)
    ---------------
    :return conf_matrix:
    :return classify_report:
    :return accur_score:
    """
    df_free_pipe[io_const.FREE_PIPE_COLUMN] = df_free_pipe[io_const.FREE_PIPE_COLUMN].fillna(-1)
    X = df_free_pipe.iloc[:, feature_col_start_idx:feature_col_end_idx]
    y = df_free_pipe.iloc[:, target_label_idx]

    # X = df_free_pipe[feature_names]
    # y = df_free_pipe[target_label]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=ml_const.TEST_SIZE,
                                                        random_state=ml_const.RANDOM_STATE)

    classifier = RandomForestClassifier(n_estimators=ml_const.N_ESTIMATORS, random_state=ml_const.RANDOM_STATE,
                                        max_depth=ml_const.MAX_DEPTH, min_samples_leaf=ml_const.MIN_SAMPLES_LEAF,
                                        verbose=ml_const.VERBOSE)

    classifier.fit(X_train, y_train)

    feature_imp = pd.Series(classifier.feature_importances_,
                            index=range(feature_col_start_idx, feature_col_end_idx)).sort_values(ascending=False)
    print(feature_imp)

    y_pred = classifier.predict(X_test)

    conf_matrix = confusion_matrix(y_test, y_pred)
    print("confusion_matrix", conf_matrix)

    classify_report = classification_report(y_test, y_pred)
    print("classification_report", classify_report)

    accur_score = accuracy_score(y_test, y_pred)
    print("accuracy_score:", accur_score)

    return conf_matrix, classify_report, accur_score, classifier


def predict_cbl_cement_to_casinge(classify_model, df_values):
    """This function computes prediction from the model.

    Parameters
    ----------
    :param classify_model: Trained classification model
    :param df_values: np.ndarray to predicted class

    Return value(s)
    ---------------
    :return df_fp: predictions dataframe from model for CCB

    """
    y_pred = classify_model.predict(df_values)

    df_fp = pd.DataFrame({io_const.CCB_COLUMN: y_pred})

    return df_fp


def predict_cbl_free_pipe(classify_model, df_values):
    """This function computes prediction from the model on given VDL data (30-140 columns).
    
    Parameters
    ----------
    :param classify_model: Trained classification model
    :param df_values: np.ndarray to predicted class
    
    Return value(s)
    ---------------
    :return df_fp: predictions from model

    """
    y_pred = classify_model.predict(df_values)

    df_fp = pd.DataFrame({io_const.FREE_PIPE_COLUMN: y_pred})

    return df_fp


def get_rf_ccb_model(model_file_path):
    '''
    s
    :param model_file_path:
    :return:
    '''
    ccb_training_file = os.path.join(io_const.TRAINING_DATA_DIR, io_const.CCB_TRAINING_DATA_CSV)
    df_cbl = pd.read_csv(ccb_training_file)
    # print(Welltest)
    # df_cbl.columns

    rename_col_dict = ml_const.CCB_TRAINING_COLUMN_DICT
    df_cbl.rename(columns=rename_col_dict, inplace=True)

    #df_cbl.columns
    feature_names = io_const.ATC_COLUMN_LIST
    target_label = [io_const.CCB_COLUMN]

    # df_cbl.replace({-999.25: 0}, inplace=True)
    for atc_channel in io_const.ATC_COLUMN_LIST:
        df_cbl = df_cbl[df_cbl[atc_channel] != io_const.BAKER_DEFALUT_NAN]

    df_cbl = df_cbl[df_cbl[io_const.CCB_COLUMN] != io_const.QUALITY_DEFALUT_NAN]

    # df_cbl = df_cbl[df_cbl != -999.25]
    # df_cbl.dropna(inplace=True)
    # df_cbl.replace({-9999: 0}, inplace=True)

    print(df_cbl.head())

    conf_matrix, classify_report, accur_score, classifier = build_cbl_cement_to_casing_model(df=df_cbl,
                                                                                             feature_names=feature_names, \
                                                                                             target_label=target_label)

    save_model(classifier, model_file_path)

    return classifier


def get_rf_free_pipe_model(model_file_path):
    '''

    :param model_file_path:
    :return:
    '''
    # Extract the Pandas dataframe rows, where all the columns have finite
    # values, and target column has non-zero values

    fp_training_file = os.path.join(io_const.TRAINING_DATA_DIR, io_const.FREE_PIPE_TRAINING_DATA_CSV)
    df_fp = pd.read_csv(fp_training_file)

    feature_col_start_idx = io_const.WAVE_START_IDX
    feature_col_end_idx = io_const.WAVE_END_IDX
    target_label_idx = 1

    df_fp.replace({io_const.BAKER_DEFALUT_NAN: np.nan}, inplace=True)
    df_fp.replace({io_const.QUALITY_DEFALUT_NAN: np.nan}, inplace=True)
    df_fp.dropna(inplace=True)
    # df_fp = df_fp[df_fp != -999.25]

    # df_fp.dropna(inplace=True)
    #df_fp.replace({-9999: 0}, inplace=True)

    print(df_fp.head())

    conf_matrix, classify_report, accur_score, classifier = build_cbl_free_pipe_model(df_free_pipe=df_fp, \
                                                                                      feature_col_start_idx=feature_col_start_idx, \
                                                                                      feature_col_end_idx=feature_col_end_idx, \
                                                                                      target_label_idx=target_label_idx)

    save_model(classifier, model_file_path)

    return classifier
