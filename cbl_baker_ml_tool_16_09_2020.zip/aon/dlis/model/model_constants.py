# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains constants, which are used during the various 
stages of machine learning model development.

@author: Prabhaker Reddy Vanam
"""
CCB_TRAINED_RF_MODEL_JOBLIB = "CBL_BAKER_RF_BB1342_TRAINED.joblib"
FREE_PIPE_TRAINED_RF_MODEL_JOBLIB = "FREE_PIPE_BAKER_RF_BB1342_TRAINED.joblib"

# Numerical constants for RFC model development
N_ESTIMATORS=150
RANDOM_STATE=1337
MAX_DEPTH=20
MIN_SAMPLES_LEAF=1
VERBOSE=1
TEST_SIZE=0.2


# CCB Training Data column rename dictionary
CCB_TRAINING_COLUMN_DICT = {'TDEP, ft': 'TDEP', 'AMAV.I, mV': 'AMAV', 'ATAV.I, dB/ft': 'ATAV',
                       'ATC1.I, dB/ft': 'ATC1', 'ATC2.I, dB/ft': 'ATC2', 'ATC3.I, dB/ft': 'ATC3',
                       'ATC4.I, dB/ft': 'ATC4',
                       'ATC5.I, dB/ft': 'ATC5', 'ATC6.I, dB/ft': 'ATC6', 'CCL.I, mV': 'CCL',
                       'DTMN.I, us/ft': 'DTMN', 'DTMX.I, us/ft': 'DTMX', 'Cement_flag (CBL)': 'CCB'}

