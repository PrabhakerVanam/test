import cx_Oracle
'''
Class to manage database related operations, Connection , Fetch records, create/update records
'''

class ExprisDatabase:

    def __init__(self, server_name, port_number, service_name, username, password):

        self.server_name = server_name
        self.port_number = port_number
        self.service_name = service_name
        self.username = username
        self.password = password

    def connect_db(self):
        """

        Returns
        -------
        Connect
        """
        dsn_tns = cx_Oracle.makedsn(self.server_name, self.port_number, service_name=self.service_name)

        conn = cx_Oracle.connect(user=self.username, password=self.password, dsn=dsn_tns, encoding="UTF-8")

        return conn

    def execute_query(self, conn, query):
        """
        Parameters
        ----------
        :param conn
        :param query string

        Returns
        -------
        object: cursor
        """
        return conn.cursor().execute(query)

    def release(self, conn):
        ''' Release database connection if connected

        Parameters
        ----------
        conn
        '''
        if conn is not None:
            conn.close()

