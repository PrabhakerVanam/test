# -*- coding: utf-8 -*-
"""
Created on Monday July 23 12:25:11 2020

This Python module describes connection details to Oracle DB.

@author: Prabhaker Reddy Vanam
"""

DB_SERVER_NAME = 'expora'
DB_PORT_NUMBER = '2739'
DB_SERVICE_NAME = 'PSPRD'
DB_USER = 'EXPRIS_IAOM'
DB_PWD = 'IAOM_EXPRIS'

DB_VIEW_NAME = 'ep_well_marker_zn2'
DB_UWI_COLUMN ='UWI'
DB_UBHI_COLUMN = 'UBHI'
DB_LAYER_NAME_COLUMN='LAYER_NAME'
DB_TOP_COLUMN= 'TOP'
DB_BASE_COLUMN= 'BASE'
DB_LAYER_TYPE_COLUMN = 'LAYER_TYPE'
DB_LAYER_TYPE_ZONE_DENSE = 'ZONE DENSE'
DB_LAYER_TYPE_ZONE='ZONE'