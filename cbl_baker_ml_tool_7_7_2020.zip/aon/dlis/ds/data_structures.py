# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains data structures/classes to support 
object-oriented approach of data input/output and model building 
functionality.

@author: Prabhaker Reddy Vanam
"""

class WellHeader:
    """The class aon.dlis.io.data_structures.WellHeader provides data
    structure for storing well log header/parameters and other related information.

    The class is initialized with WellHeader(field_name, well_name, producer_name, set_name, frame_name)
    Class constructor has following parameters:
        :param field_name: Field Name
        :param well_name: Well Name
        :param producer_name: Producer Name
        :param set_name: Logical File Set Name
        :param frame_name: Frame name in the logical File
        
    Attributes
    ----------

    Additionally, this class has following attributes:
        * date_time: list of dates and times of data collection
        * cum_date_time: list of dates and times of cum. prod. data collection
        * drainage_radius: drainage radius of the well
        * well_zones: list of adnoc.wellopt.io.data_structures.WellZone objetcs
        TODO
    """

    def __init__(self, field_name, well_name, producer_name, set_name, frame_name):
        """ This function initializes an aon.dlis.io.data_structures.WellData
        object with the provided parameters.

        Parameters
        ----------
        :param field_name: Field Name
        :param well_name: Well Name
        :param producer_name: Producer Name
        :param set_name: Logical File Set Name
        :param frame_name: Frame name in the logical File
        """

        self.field_name = field_name
        self.well_name = well_name
        self.producer_name = producer_name
        self.set_name = set_name
        self.frame_name = frame_name
        self.cum_date_time = None
        self.drainage_radius = -1.e3
        self.well_zones = None
        # Parameters commonn to all wells


class WellZone:
    """The class adnoc.wellopt.io.data_structures.WellZone provides data 
    structure for storing well bottomhole conditions, ICV positions, oil 
    production rates, and location information for different reservoirs zones.

    The class is initialized with WellZone(well_name, zone_name, zone_min, zone_max)
    Class constructor has following parameters:
        :param well_name: Name of the well
        :param zone_name: Name of the reservoir zone
        :param zone_min:  Zone start Depth
        :param zone_max: Zone End Depth
        
    Attributes
    ----------

    Additionally, this class has following attributes:
        * date_time: list of dates and times of data collection
        TODO
    """

    def __init__(self, well_name, zone_name, zone_min, zone_max):
        """This function initializes an aon.dlis.io.data_structures.WellZone
        object with the provided parameters.

        Parameters
        ----------
        :param well_name: Name of the well
        :param zone_name: Name of the reservoir zone
        :param zone_min:  Zone start Depth
        :param zone_max: Zone End Depth
        """
        self.well_name = well_name
        self.zone_name = zone_name
        self.zone_min = zone_min
        self.zone_max = zone_max
        self.date_time = None

