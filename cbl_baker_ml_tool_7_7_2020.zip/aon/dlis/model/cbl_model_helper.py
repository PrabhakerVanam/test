# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains utility functions, which support creation of predictive
models during different stages of machine learning model development.

@author: Prabhaker Reddy Vanam
"""

import os

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
import joblib
from joblib import load
from matplotlib import pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report , confusion_matrix , accuracy_score
from sklearn.metrics import f1_score
from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const


def save_model(model, model_file_ame='finalized_model.joblib'):
    """ save the model to disk
    """
    joblib.dump(model, model_file_ame)


def load_model(model_file_ame='finalized_model.joblib'):
    """ load model from the disk
    """
    model = joblib.load(model_file_ame)

    return model


def get_model_name(model_name, model_name_prefix, model_fold=None,
                   scaled_var=None):
    """This function returns the name of a model to be saved to a file, based upon
    the parameters passed.

    Parameters
    ----------
    :param model_name: Name of the model
    :param model_name_prefix: Prefix for the name of model
    :param model_fold: Fold in KFold this model belongs to
    :param scaled_var: Input variable being scaled (optional, if not data scaler)

    Return value(s)
    ---------------
    :return model_name: Name of the model to be saved to file
    """
    model_name = model_name + io_const.MODEL_SEPARATOR + model_name_prefix
    if model_fold != None:
        model_name += io_const.MODEL_SEPARATOR + io_const.MODEL_FOLD + \
                      str(model_fold)
    if scaled_var != None:
        model_name += io_const.MODEL_SEPARATOR + scaled_var
    model_name += io_const.MODEL_NAME_SUFFIX
    return model_name


def develop_model_cbl_cement_to_casing(df, feature_names=io_const.ATC_COLUMN_LIST, target_label=['CQF'] , test_size=0.20 , random_state=1 , n_estimators=200):
    """This python function develops machine learning (ML) models with KFold
    cross-validation for the provided dataframe, by using provided names
    of X and y columns in the dataframe. If instructed, it also saves the
    developed models to files.

    Paramaters
    ----------
    :param df: Pandas dataframe with the values to model   
    :param feature_names: List providing names of columns to be used as input
                    features (X), and target variable (y; last column has target)
    :param target_label: target variable
    :param test_size: Train and Test size.
    :param random_state: Random state
    :param n_estimators : no.of RF estimators

    Return value(s)
    ---------------
    :return conf_matrix:
    :return classify_report:
    :return accur_score:
    """
    # Extract the Pandas dataframe rows, where all the columns have finite
    # values, and target column has non-zero values
    rename_col_dict = {'TDEP, ft':'TDEP', 'AMAV.I, mV':'AMAV', 'ATAV.I, dB/ft':'ATAV',
       'ATC1.I, dB/ft':'ATC1', 'ATC2.I, dB/ft':'ATC2', 'ATC3.I, dB/ft':'ATC3', 'ATC4.I, dB/ft':'ATC4',
       'ATC5.I, dB/ft':'ATC5', 'ATC6.I, dB/ft':'ATC6', 'CCL.I, mV':'CCL', 'DTMN.I, us/ft':'DTMN',
       'DTMX.I, us/ft':'DTMX', 'Cement_flag (CBL)':'CQF'}
    
    df.rename(columns=rename_col_dict, inplace=True)
    #feature_names=io_const.ATC_COLUMN_LIST
    #target_label=['CQF']

    X = df[feature_names]
    y = df[target_label]
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size, random_state=random_state)

    classifier = RandomForestClassifier(n_estimators=n_estimators)
    classifier.fit(X_train, y_train.values.ravel())

    y_pred = classifier.predict(X_test)

    conf_matrix = confusion_matrix(y_test, y_pred)
    print("confusion_matrix", conf_matrix)

    classify_report = classification_report(y_test, y_pred)
    print("classification_report", classify_report)

    accur_score = accuracy_score(y_test, y_pred)
    print("accuracy_score:", accur_score)

    f1score = f1_score(y_test, y_pred, average='weighted', labels=np.unique(y_pred))
    print("f1 accuracy_score:", f1score)

    #print(set(y_test) - set(y_pred))

    return conf_matrix, classify_report, accur_score, classifier


def predict_cbl_cement_to_casinge(classify_model, df_values):
    """This function computes prediction from the model.

    Parameters
    ----------
    :param classify_model: Trained classification model
    :param df_values: np.ndarray to predicted class

    Return value(s)
    ---------------
    :return df_fp: predictions dataframe from model for CCB

    """
    y_pred = classify_model.predict(df_values)

    df_fp = pd.DataFrame({io_const.CCB_COLUMN: y_pred})

    return df_fp


def develop_model_vdl_free_pipe(df, well_name, xy_cols, test_size=0.20, random_state=1, n_estimators=200):
    """This python function develops machine learning (ML) models with KFold 
    cross-validation for the provided dataframe, by using provided names 
    of X and y columns in the dataframe. If instructed, it also saves the 
    developed models to files.
    
    Paramaters
    ----------
    :param df: Pandas dataframe with the values to model
    :param well_name: Name of the well
    :param xy_cols: List providing names of columns to be used as input 
                    features (X), and target variable (y; last column has target)
    :param test_size: Train and Test size.
    :param random_state: Random state
    :param n_estimators : no.of RF estimators

    Return value(s)
    ---------------
    :return conf_matrix:
    :return classify_report:
    :return accur_score:
    """
    # Extract the Pandas dataframe rows, where all the columns have finite
    # values, and target column has non-zero values

    X = df.iloc[ : , 2:144 ]
    y = df.iloc[ : , 1 ]

    X_train , X_test , y_train , y_test = train_test_split(X , y , test_size=test_size , random_state=random_state)

    classifier = RandomForestClassifier(n_estimators=n_estimators)
    classifier.fit(X_train , y_train)

    y_pred = classifier.predict(X_test)

    conf_matrix = confusion_matrix(y_test , y_pred)
    print("confusion_matrix" , conf_matrix)

    classify_report = classification_report(y_test , y_pred)
    print("classification_report" , classify_report)

    accur_score = accuracy_score(y_test , y_pred)
    print("accuracy_score:" , accur_score)

    return conf_matrix , classify_report , accur_score


def predict_vdl_free_pipe(classify_model , df_values):
    """This function computes prediction from the model.
    
    Parameters
    ----------
    :param classify_model: Trained classification model
    :param df_values: np.ndarray to predicted class
    
    Return value(s)
    ---------------
    :return df_fp: predictions from model

    """
    y_pred = classify_model.predict(df_values)

    df_fp = pd.DataFrame({'Free Pipe': y_pred})

    return df_fp

def get_trained_rf_model(model_file_path):

    training_file = os.path.join(io_const.RAINING_DATA_DIR, io_const.TRAINING_DATA_CSV)
    df_cbl = pd.read_csv(training_file)
    # print(Welltest)
    #df_cbl.columns

    rename_col_dict = {'TDEP, ft': 'TDEP' , 'AMAV.I, mV': 'AMAV' , 'ATAV.I, dB/ft': 'ATAV' ,
                       'ATC1.I, dB/ft': 'ATC1' , 'ATC2.I, dB/ft': 'ATC2' , 'ATC3.I, dB/ft': 'ATC3' ,
                       'ATC4.I, dB/ft': 'ATC4' ,
                       'ATC5.I, dB/ft': 'ATC5' , 'ATC6.I, dB/ft': 'ATC6' , 'CCL.I, mV': 'CCL' ,
                       'DTMN.I, us/ft': 'DTMN' ,
                       'DTMX.I, us/ft': 'DTMX' , 'Cement_flag (CBL)': 'CCB'}
    df_cbl.rename(columns=rename_col_dict, inplace=True)

    df_cbl.columns
    feature_names = io_const.ATC_COLUMN_LIST
    target_label = ['CCB']
    df_cbl = df_cbl[df_cbl != -999.25]

    df_cbl.dropna(inplace=True)

    df_cbl.replace({-9999: 0}, inplace=True)

    print(df_cbl.head())

    n_estimators = 350

    _, _, _, classifier = develop_model_cbl_cement_to_casing(df=df_cbl, feature_names=feature_names,\
                                                             target_label=target_label, n_estimators=n_estimators)

    joblib.dump(classifier, model_file_path)

    return classifier