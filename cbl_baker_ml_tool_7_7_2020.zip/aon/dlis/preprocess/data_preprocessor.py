# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains functions to support data imputation before 
generation of the input feature matrix for the prediction and forecasting 
algorithms. This module also provides utility functions for generating 
input feature dataframes, and scaling the data columns using MinMaxScaler.

@author: Prabhaker Reddy Vanam
"""

import os

import numpy as np
import pandas as pd
pd.options.mode.chained_assignment = None
from joblib import dump
from joblib import load
from sklearn.preprocessing import MinMaxScaler
from datetime import datetime

from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const
from aon.dlis.model import model_helper as ml_helper

def str_to_float32(x_arr):
    """This is a convenience function, which takes an array of strings, and 
    tries to convert them to np.float32 numbers. If the conversion fails, 
    it populates np.nan
    
    Parameters
    ----------
    :param x_arr: List of string values
    
    Return value(s)
    ---------------
    :return float_arr: List of converted np.float32 values
    """
    float_arr = []
    for x in x_arr:
        fval = np.nan
        try:
            x = str(x).replace(',', '')
            fval = np.float32(x)
        except ValueError:
            pass
        float_arr.append(fval)
    return float_arr

def str_to_int32(x_arr):
    """This is a convenience function, which takes an array of strings, and 
    tries to convert them to np.int32 numbers. If the conversion fails, 
    it populates np.nan
    
    Parameters
    ----------
    :param x_arr: List of string values
    
    Return value(s)
    ---------------
    :return int_arr: List of converted np.int32 values
    """
    int_arr = []
    for x in x_arr:
        ival = np.nan
        try:
            x = str(x).replace(',', '')
            ival = np.int32(x)
        except ValueError:
            pass
        int_arr.append(ival)
    return int_arr

def barg_to_psig(x_arr):
    """This is a convenience function, which takes an array of values with 
    pressure measured in barg (bar gauge) and converts it to an array of 
    pressure values in psig units.
    
    Parameters
    ----------
    :param x_arr: List of pressure values in barg (bar gauge)
    
    Return value(s)
    ---------------
    :return converted: List of converted pressure values in psig
    """
    converted = None
    if x_arr is not None and len(x_arr) > 0:
        converted = []
        p_atm_bar = 1.01325
        p_atm_psi = 14.6959
        bar_to_psi = 14.50377
        for x in x_arr:
            x_psig = np.nan
            if ~np.isnan(x) and np.isfinite(x):
                x_psig = (x + p_atm_bar) * bar_to_psi - p_atm_psi
            converted.append(x_psig)
    return converted

def bean_size_to_inches(x_arr):
    """This is a convenience function, which takes an array of values with 
    choke bean size, and converts it to an array of choke size in inches.
    
    Parameters
    ----------
    :param x_arr: List of choke bean size (1/64 inches)
    
    Return value(s)
    ---------------
    :return converted: List of converted choke sizes in inches
    """
    converted = None
    if x_arr is not None and len(x_arr) > 0:
        converted = []
        bean_to_inches = 1./64.
        for x in x_arr:
            x_inch = np.nan
            if ~np.isnan(x) and np.isfinite(x):
                x_inch = x * bean_to_inches
            converted.append(x_inch)
    return converted

def parse_date_time_combined(date_time_str):
    """This function takes date and time as strings in following format:
        date_time_str: DD-MON-YY HH:MM
    and parses it to at datetime.datetime representation.

    Parameters
    ----------
    :param date_time_str: Date string in DD-MON-YY HH:MM format
    
    Return value(s)
    ---------------
    :return date_time: Date and time in format with year as YYYY
    """
    if date_time_str == None or date_time_str.strip() == "" \
    or date_time_str == "nan":
        return None
    else:
        date_time = datetime.strptime(date_time_str,"%d-%b-%y %H:%M")
        if date_time.year > 2050:
            date_time = date_time.replace(year=(date_time.year - 100))
    return date_time

def prepare_oil_model_dataframe(well_test_data):
    """This function creates a Pandas dataframe based upon a WellTestData object.
    Following variables are populated as the columns in the dataframe:
        WHP, WHT, BHP, BHT, Flowline Pressure, % Choke open, 
        Choke Delta Pressure, Is well flowing flag, Oil Flow Rate.
    
    Parameters
    ----------
    :param well_test_data: Populated WellTestData object
    
    Return value(s)
    ---------------
    :return model_df: Pandas dataframe populated with selected variables from 
                      the WellData object.    
    """
    # Stacking variables as a column in 2D numpy.ndarray
    data_arr = np.c_[str_to_float32(well_test_data.whp), 
                     str_to_float32(well_test_data.wht), 
                     str_to_float32(well_test_data.bhp), 
                     str_to_float32(well_test_data.bht), 
                     str_to_float32(well_test_data.flp), 
                     str_to_float32(well_test_data.choke), 
                     str_to_float32(well_test_data.choke_dp), 
                     str_to_float32(well_test_data.is_well_flowing), 
                     str_to_float32(well_test_data.oil_rate)]
    # In the above ndarray, last column has oil rate
    # We'll keep only the rows, where oil rate is provided.
    data_arr = data_arr[np.isfinite(data_arr[:,-1])]
    col_names = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.BHP_COLUMN, 
                 io_const.BHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    model_df = pd.DataFrame(data_arr, columns=col_names)
    return model_df

def prepare_oil_pred_dataframe(well_data):
    """This function creates a Pandas dataframe based upon a WellData object.
    Following variables are populated as the columns in the dataframe:
        Date/Time, WHP, WHT, BHP, BHT, Flowline Pressure, % Choke open, 
        Choke Delta Pressure, Is well flowing flag, Oil Flow Rate.
    
    Parameters
    ----------
    :param well_data: Populated WellData object
    
    Return value(s)
    ---------------
    :return pred_df: Pandas dataframe populated with selected variables from 
                     the WellData object.    
    """
    # Stacking variables as a column in 2D numpy.ndarray
    data_arr = np.c_[well_data.date_time, 
                     str_to_float32(well_data.whp), 
                     str_to_float32(well_data.wht), 
                     str_to_float32(well_data.well_zones[0].bhp), 
                     str_to_float32(well_data.well_zones[0].bht), 
                     str_to_float32(well_data.flp), 
                     str_to_float32(well_data.choke), 
                     str_to_float32(well_data.choke_dp), 
                     str_to_float32(well_data.is_well_flowing)]
    col_names = [io_const.DATE_TIME_COLUMN, 
                 io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.BHP_COLUMN, 
                 io_const.BHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN]
    pred_df = pd.DataFrame(data_arr, columns=col_names)
    return pred_df

def prepare_bhp_bht_model_dataframe(well_test_data, output_variable):
    """This function creates a Pandas dataframe based upon a WellTestData object.
    Following variables are populated as the columns in the dataframe:
        WHP, WHT, Flowline Pressure, % Choke open, Choke Delta Pressure, 
        Is well flowing flag, BHP/BHT.
    
    Parameters
    ----------
    :param well_test_data: Populated WellTestData object
    :param output_variable: Model output variable, either BHP or BHT
    
    Return value(s)
    ---------------
    :return model_df: Pandas dataframe populated with selected variables from 
                      the WellData object.    
    """
    # Stacking variables as a column in 2D numpy.ndarray
    data_arr = np.c_[str_to_float32(well_test_data.whp), 
                     str_to_float32(well_test_data.wht), 
                     str_to_float32(well_test_data.flp), 
                     str_to_float32(well_test_data.choke), 
                     str_to_float32(well_test_data.choke_dp), 
                     str_to_float32(well_test_data.is_well_flowing), 
                     str_to_float32(well_test_data.bhp), 
                     str_to_float32(well_test_data.bht)]
    col_names = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN, 
                 io_const.BHP_COLUMN, 
                 io_const.BHT_COLUMN]
    model_df = pd.DataFrame(data_arr, columns=col_names)
    if output_variable == io_const.BHP_COLUMN:
        model_df.drop(columns=[io_const.BHT_COLUMN], inplace=True)
    elif output_variable == io_const.BHT_COLUMN:
        model_df.drop(columns=[io_const.BHP_COLUMN], inplace=True)
    # In the above dataframe, last column has BHFP or BHFT. 
    # We'll keep only the rows, where BHFP or BHFT is provided.
    model_df = model_df[pd.notnull(model_df.iloc[:,-1])]
    return model_df

def prepare_bhp_bht_pred_dataframe(well_data):
    """This function creates a Pandas dataframe based upon a WellData object.
    Following variables are populated as the columns in the dataframe:
        Date/Time, WHP, WHT, Flowline Pressure, % Choke open, 
        Choke Delta Pressure, Is well flowing flag.
    
    Parameters
    ----------
    :param well_data: Populated WellData object
    
    Return value(s)
    ---------------
    :return pred_df: Pandas dataframe populated with selected variables from 
                      the WellData object.    
    """
    # Stacking variables as a column in 2D numpy.ndarray
    data_arr = np.c_[well_data.date_time, 
                     str_to_float32(well_data.whp), 
                     str_to_float32(well_data.wht), 
                     str_to_float32(well_data.flp), 
                     str_to_float32(well_data.choke), 
                     str_to_float32(well_data.choke_dp), 
                     str_to_float32(well_data.is_well_flowing)]
    col_names = [io_const.DATE_TIME_COLUMN, 
                 io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN]
    pred_df = pd.DataFrame(data_arr, columns=col_names)
    return pred_df

def prepare_prosper_model_dataframe(prosper_well_data, target_variable):
    """This function creates a Pandas dataframe based upon a WellProsperData object, 
    and the specified target variable to be modeled.
    
    Parameters
    ----------
    :param prosper_well_data: Populated WellProsperData object
    :param target_variable: The variable, which is predicted by the model
    
    Return value(s)
    ---------------
    :return model_df: Pandas dataframe populated with selected variables from 
                      the WellProsperData object.    
    """
    # Stacking variables as a column in 2D numpy.ndarray
    data_arr = np.c_[str_to_float32(prosper_well_data.whp), 
                     str_to_float32(prosper_well_data.wht), 
                     str_to_float32(prosper_well_data.flp), 
                     str_to_float32(prosper_well_data.flt), 
                     str_to_float32(prosper_well_data.choke_dp), 
                     str_to_float32(prosper_well_data.choke_dt), 
                     str_to_float32(prosper_well_data.choke), 
                     str_to_float32(prosper_well_data.chp), 
                     str_to_float32(prosper_well_data.gl_rate)]
    col_names = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.FLT_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.CHOKE_DT_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHP_COLUMN, 
                 io_const.GL_RATE_COLUMN]
    model_df = pd.DataFrame(data_arr, columns=col_names)
    if target_variable == io_const.OIL_RATE_COLUMN:
        model_df[io_const.OIL_RATE_COLUMN] = str_to_float32(
                prosper_well_data.oil_rate)
    elif target_variable == io_const.LIQUID_RATE_COLUMN:
        model_df[io_const.LIQUID_RATE_COLUMN] = str_to_float32(
                prosper_well_data.liquid_rate)
    elif target_variable == io_const.GOR_COLUMN:
        model_df[io_const.GOR_COLUMN] = str_to_float32(
                prosper_well_data.gor)
    elif target_variable == io_const.WCT_COLUMN:
        model_df[io_const.WCT_COLUMN] = str_to_float32(
                prosper_well_data.wct)
    elif target_variable == io_const.BHP_COLUMN:
        model_df[io_const.BHP_COLUMN] = str_to_float32(
                prosper_well_data.bhp)
    elif target_variable == io_const.PROD_INDEX_COLUMN:
        model_df[io_const.BHP_COLUMN] = str_to_float32(
                prosper_well_data.bhp)
        model_df[io_const.PI_COLUMN] = str_to_float32(
                prosper_well_data.pi)
    elif target_variable == io_const.RES_PRESSURE_COLUMN:
        model_df[io_const.BHP_COLUMN] = str_to_float32(
                prosper_well_data.bhp)
        model_df[io_const.RES_PRESSURE_COLUMN] = str_to_float32(
                prosper_well_data.press_datum)
    # We'll keep only the rows, where target variable is provided.
    model_df = model_df[pd.notnull(model_df.iloc[:,-1])]
    return model_df

def prepare_prosper_pred_dataframe(well_data, target_variable):
    """This function creates a Pandas dataframe based upon a WellData object, 
    and the specified target variable to be predicted using pretrained Prosper 
    nodal analysis simulation data based machine learning models.
    
    Parameters
    ----------
    :param well_data: Populated WellData object
    :param target_variable: The variable, which is predicted by the model
    
    Return value(s)
    ---------------
    :return pred_df: Pandas dataframe populated with selected variables from 
                     the WellData object.    
    """
    # Stacking variables as a column in 2D numpy.ndarray
    data_arr = np.c_[well_data.date_time, 
                     str_to_float32(well_data.whp), 
                     str_to_float32(well_data.wht), 
                     str_to_float32(well_data.flp), 
                     str_to_float32(well_data.flt), 
                     str_to_float32(well_data.choke_dp), 
                     str_to_float32(well_data.choke_dt), 
                     str_to_float32(well_data.choke), 
                     str_to_float32(well_data.chp), 
                     str_to_float32(well_data.gl_rate)]
    col_names = [io_const.DATE_TIME_COLUMN,
                 io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.FLT_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.CHOKE_DT_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHP_COLUMN, 
                 io_const.GL_RATE_COLUMN]
    pred_df = pd.DataFrame(data_arr, columns=col_names)
    return pred_df

def fit_scale_dataframe_columns(df, well_name, scaler_prefix, save_model=False):
    """This function scales the variables in Pandas dataframe columns using 
    MinMaxScaler. Fitted data scalers are saved to files, if indicated by the 
    passed boolean flag.
    
    Parameters
    ----------
    :param df: Pandas dataframe
    :param well_name: Name of the well
    :param scaler_prefix: Prefix to the names of files to save data scalers
    :param save_models: Flag indicating whether or not save data scalers to files
    
    Return value(s)
    ---------------
    :return df: Pandas dataframe, with column-wise scaled values
    """
    col_names = list(df.columns)
    for col_name in col_names:
        col_scaler = MinMaxScaler()
        df[col_name] = col_scaler.fit_transform(df[col_name].values.reshape(-1, 1))
        model_name = ml_helper.get_model_name(well_name, scaler_prefix, 
                                              scaled_var=col_name)
        model_path = os.path.join(io_const.MODEL_DIR, model_name)
        dump(col_scaler, model_path)
    return df

def scale_feature_columns(df, well_name, scaler_prefix):
    """This function scales the variables in Pandas dataframe columns using 
    saved data scalers.
    
    Parameters
    ----------
    :param df: Pandas dataframe with input features
    :param well_name: Name of the well
    :param scaler_prefix: Prefix to the names of saved data scaler files
    
    Return value(s)
    ---------------
    :return df: Pandas dataframe, with column-wise scaled values
    """
    col_names = list(df.columns)
    for col_name in col_names:
        scaler_name = ml_helper.get_model_name(well_name, scaler_prefix, 
                                               scaled_var=col_name)
        scaler_path = os.path.join(io_const.MODEL_DIR, scaler_name)
        col_scaler = load(scaler_path)
        df[col_name] = col_scaler.transform(df[col_name].values.reshape(-1, 1))
    return df

def find_continous_data_rows(realtime_df, feature_columns, data_pitch):
    """This function finds data rows in the provided dataframe, which have time 
    continuity at the provided data pitch (in hours) vevel for the all of 
    the data columns, considering the rows with valid values.
    
    Parameters
    ----------
    :param realtime_df: A Pandas dataframe populated with realtime well data
    :param feature_columns: Dataframe columns with feature variables
    :param data_pitch: Data pitch in number of hours to consider it continuous

    Return value(s)
    ---------------
    :return df: Pandas dataframe with the filtered rows for the given combo_code
    :return cont_idxs: List of lists, where each sublist contains row indices, 
                       which represent data with time continuity.
    """
    idxs = realtime_df.index.values
    for col_name in feature_columns:
        realtime_df = realtime_df[pd.notnull(realtime_df[col_name]) & \
                                  pd.notna(realtime_df[col_name])]
    realtime_df.reset_index(drop=True, inplace=True)
    date_time = realtime_df[io_const.DATE_TIME_COLUMN].values
    cont_idxs = []
    start_new = True
    for idx in range(len(date_time)):
        if start_new:
            idxs = []
            idxs.append(idx)
            start_new = False
        else:
            # Compute time difference between consecutive rows in hours
            hours_elapsed = int((date_time[idx] - date_time[idx - 1]) / \
            np.timedelta64(1, 'h'))
            #print(date_time[idx], date_time[idx-1], hours_elapsed, data_pitch)
            if hours_elapsed == data_pitch:
                idxs.append(idx)
            else:
                cont_idxs.append(idxs)
                start_new = True
    return realtime_df, cont_idxs

def prepare_timeseries_input_for_rnn(well_name, realtime_df, lookback, lookahead, 
                                     target_column, data_pitch):
    """This function prepares input features for Recurrent Neural Network (RNN) 
    with Long Short-Term Memory (LSTM), using the WellData object, and other 
    provided input parameters.
    
    Parameters
    ----------
    :param well_name: Name of the well
    :param realtime_df: A Pandas dataframe populated with realtime well data
    :param lookback: Number of time-steps to lookback in LSTM model
    :param lookahead: Number of time-steps to forecast in multi-step LSTM model
    :param target_column: Dataframe column with target variable values
    :param data_pitch: Data pitch in number of hours to consider it continuous
         
    Return Value(s)
    ---------------
    :return features: Input feature for training LSTM model
    :return target: Target values for training LSTM model
    """
    feature_columns = ml_helper.get_timeseries_feature_columns(target_column)
    df, cont_idxs = find_continous_data_rows(realtime_df, feature_columns, 
                                             data_pitch)
    df = df[feature_columns]
    #print(df)
    #print(cont_idxs)
    scaler_prefix = ml_helper.get_model_prefix(ml_const.DATA_SCALER, 
                                               target_column, 
                                               ml_const.TS_MODEL_COMBO_CODE)
    df = fit_scale_dataframe_columns(df, well_name, scaler_prefix, True)
    feat_idxs = []
    target_idxs = []
    for idxs in cont_idxs:
        num_idxs = len(idxs)
        #print(idxs)
        if num_idxs >= (lookback + lookahead):
            for i in range(lookback, num_idxs - lookahead + 1):
                start_idx = i - lookback
                end_idx = i - 1
                target_start_idx = i
                target_end_idx = i + lookahead - 1
                feat_idxs.append([idxs[j] for j in range(start_idx, end_idx + 1)])
                target_idxs.append([idxs[j] for j in \
                                   range(target_start_idx, target_end_idx + 1)])
                #print(feat_idxs[-1])
                #print(target_idxs[-1])
    features = []
    targets = []
    num_targets = len(target_idxs)
    num_feat_cols = len(feature_columns)
    target_values = df[target_column].values
    for i in range(num_targets):
        target = np.zeros((1, lookahead)).astype(np.float32)
        target[0] = target_values[target_idxs[i]]
        targets.append(target)
        feat = np.zeros((num_feat_cols, lookback)).astype(np.float32)
        for j in range(num_feat_cols):
            feat[j] = df[feature_columns[j]].values[feat_idxs[i]]
        features.append(feat.T)
    features = np.array(features).reshape(num_targets, lookback, num_feat_cols)
    targets = np.array(targets).reshape(num_targets, lookahead)
    return features, targets

def prepare_timeseries_input_for_stacking(well_name, realtime_df, lookback, 
                                          target_column, data_pitch, model_type):
    """This function prepares input features for training a stacked model using 
    the realtime well data, and other provided input parameters.
    
    Parameters
    ----------
    :param well_name: Name of the well
    :param realtime_df: A Pandas dataframe populated with realtime well data
    :param lookback: Number of time-steps to lookback in stacked model
    :param target_column: Dataframe column with target variable values
    :param data_pitch: Data pitch in number of hours to consider it continuous
         
    Return Value(s)
    ---------------
    :return features: Input feature for training stacked model
    :return target: Target values for training stacked model
    """
    feature_columns = ml_helper.get_timeseries_feature_columns(target_column)
    df, cont_idxs = find_continous_data_rows(realtime_df, feature_columns, 
                                             data_pitch)
    df = df[feature_columns]
    #print(df)
    #print(cont_idxs)
    scaler_prefix = ml_helper.get_model_prefix(ml_const.DATA_SCALER, 
                                               target_column, 
                                               ml_const.TS_MODEL_COMBO_CODE)
    df = fit_scale_dataframe_columns(df, well_name, scaler_prefix, True)
    feat_idxs = []
    target_idxs = []
    for idxs in cont_idxs:
        num_idxs = len(idxs)
        #print(idxs)
        if num_idxs > lookback:
            for i in range(lookback, num_idxs):
                start_idx = i - lookback
                end_idx = i - 1
                feat_idxs.append([idxs[i] for i in range(start_idx, end_idx)])
                target_idxs.append(i)
                #print(feat_idxs[-1])
    features = []
    targets = []
    num_targets = len(target_idxs)
    num_feat_cols = len(feature_columns)
    target_values = df[target_column].values
    for i in range(num_targets):
        targets.append(target_values[target_idxs[i]])
        feat = []
        for j in range(num_feat_cols):
            feat_col_values = df[feature_columns[j]].values
            for k in feat_idxs[i]:
                feat.append(feat_col_values[k])
            if feature_columns[j] != target_column:
                feat.append(feat_col_values[target_idxs[i]])
        features.append(feat)
    features = np.array(features).reshape(num_targets, -1)
    targets = np.array(targets).reshape(num_targets, 1)
    return features, targets

def split_timeseries_data(features, targets, test_fraction):
    """This function splits timeseries data into training and test data. No random 
    shuffling takes place while splitting the data into training and test datasets.
    
    Parameters
    ----------
    :param features: Input feature for training timeseries model
    :param target: Target values for training timeseries model
    :param test_fraction: Fraction of data to be used as blind-test data
    
    Return value(s)
    ---------------
    :return train_X: Input features for training data
    :return test_X: Input features for testing data
    :return train_y: Target values for training data
    :return test_y: Target values for testing data
    """
    num_rows = features.shape[0]
    num_test = int(test_fraction * num_rows)
    train_idxs = range(num_rows - num_test)
    test_idxs = range(num_rows - num_test, num_rows)
    train_X = features[train_idxs]
    test_X = features[test_idxs]
    train_y = targets[train_idxs]
    test_y = targets[test_idxs]
    return train_X, test_X, train_y, test_y

def fill_with_test_values(date_time, test_dates, test_data, do_back_fill=True):
    """This function fills missing values in the well test data using the last 
    valid value available in the well test data. If backfill is set to true, then 
    initial missing values before first well test are filled using the valid well 
    test value from the first well test.
    
    Parameters
    ----------
    :param date_time: All date and times to fill test data
    :param test_dates: Dates and times with valid well test data available
    :param test_data: Available valid well test data
    :param do_back_fill: Whether backfill initial missing values with first 
                         valid well test data
                         
    Return value(s)
    ---------------
    :return filled_values: List containing values filled with the latest well 
                           test data in the dates and times with missing data
    """
    filled_values = None
    if date_time is not None:
        num_times = len(date_time)
        if test_dates is not None and len(test_dates) > 1 \
        and test_data is not None and len(test_data) > 1:
            filled_values = []
            num_tests = len(test_dates)
            for i in range(num_times):
                for j in range(num_tests):
                    #print(j)
                    #print(test_data[j])
                    if j == 0: 
                        if date_time[i] < test_dates[j]:
                            if ~np.isnan(test_data[j]):
                                if do_back_fill:
                                    filled_values.append(test_data[j])
                                    #print(filled_values[i])
                                else:
                                    filled_values.append(np.nan)
                                break
                            else:
                                continue
                        elif test_dates[j] <= date_time[i] < test_dates[j + 1]:
                            if ~np.isnan(test_data[j]):
                                filled_values.append(test_data[j])
                                #print(filled_values[i])
                                break
                            else:
                                continue
                    elif j > 0 and j < (num_tests - 1):
                        if test_dates[j] <= date_time[i] < test_dates[j + 1]:
                            if ~np.isnan(test_data[j]):
                                filled_values.append(test_data[j])
                                #print(filled_values[i])
                                break
                            else:
                                continue
                    elif j == (num_tests - 1):
                        if ~np.isnan(test_data[j]):
                            filled_values.append(test_data[j])
                            #print(filled_values[i])
                            break
                        else:
                            continue
        elif test_dates is not None and len(test_dates) == 1:
            if test_data is not None and len(test_data) == 1:
                if ~np.isnan(test_data[0]):
                    filled_values = np.zeros(num_times)
                    filled_values[:] = test_data[0]
                    filled_values = filled_values.tolist()
    return filled_values

def add_previous_value_column(df, col_name, date_column):
    """This function first fills the missing values in the specified column of 
    the provided dataframe, and then appends a new column containing last value of 
    the specified column.
    
    Parameters
    ----------
    :param df: Pandas dataframe with modeling input data
    :param col_name: Column name for which previous column will be added
    :param date_column: Name of the date and time column
    
    Return value(s)
    ---------------
    :return df: Dataframe with appended last value column
    """
    date_time = df[date_column].values
    if isinstance(date_time[0], str):
        date_time = [parse_date_time_combined(x) for x in date_time]
        df[date_column] = date_time
    df = df.sort_values(by=date_column, ascending=True)
    df = df.reset_index(drop=True)
    date_time = df[date_column].values
    col_values = df[col_name].values
    valid_idxs = np.where(np.isfinite(col_values))[0]
    filled_values = fill_with_test_values(date_time, date_time[valid_idxs], 
                                          col_values[valid_idxs], do_back_fill=False)
    filled_values.insert(0, np.nan)
    filled_values = filled_values[:-1]
    df[col_name + io_const.LAST_DATA_SUFFIX] = filled_values
    return df

def add_previous_well_test_columns(df, date_column, well_test_df, 
                                   test_date_column, test_column):
    """This function appends a new column to the provided dataframe by using the 
    values from the specified column of the well test data using the latest well 
    test values.
    
    Parameters
    ----------
    :param df: Pandas dataframe with modeling input data
    :param date_column: Name of the date and time column
    :param well_test_df: Pandas dataframe with the well test data
    :param test_date_column: Name of the date and time column in well test dataframe
    :param test_column: Column name to be added from well test dataframe
    
    Return value(s)
    ---------------
    :return df: Dataframe with appended last well test value column
    """    
    date_time = df[date_column].values
    if isinstance(date_time[0], str):
        date_time = [parse_date_time_combined(x) for x in date_time]
        df[date_column] = date_time
    df = df.sort_values(by=date_column, ascending=True)
    df = df.reset_index(drop=True)
    date_time = df[date_column].values
    
    test_dates = well_test_df[test_date_column].values
    if isinstance(test_dates[0], str):
        test_dates = [parse_date_time_combined(x) for x in test_dates]
        well_test_df[test_date_column] = test_dates
    well_test_df = well_test_df.sort_values(by=test_date_column, ascending=True)
    well_test_df = well_test_df.reset_index(drop=True)
    test_values = well_test_df[test_column].values
    test_dates = well_test_df[test_date_column].values
    valid_idxs = np.where(np.isfinite(test_values))[0]
    filled_values = fill_with_test_values(date_time, test_dates[valid_idxs], 
                                          test_values[valid_idxs], do_back_fill=True)
    df[test_column + io_const.LAST_DATA_SUFFIX] = filled_values
    return df    

def add_cum_prod_column(df, cum_prod_df, date_column, cum_prod_column):
    """This function appends a column with cumulative production data to the 
    provided modeling input dataframe by using cumulative production data from 
    the provided dataframe with cumulative production data.
    
    Parameters
    ----------
    :param df: Pandas dataframe with modeling input data
    :param cum_prod_df: Pandas dataframe with cumulative production data
    :param date_column: Name of the column with date and time
    :param cum_prod_column: Name of the column with cumulative production data
    
    Return value(s)
    ---------------
    :param df: Pandas dataframe with appended cumulative production column
    """
    cum_dates = cum_prod_df[date_column].values
    if isinstance(cum_dates[0], str):
        cum_dates = [parse_date_time_combined(x) for x in cum_dates]
        cum_prod_df[date_column] = cum_dates
    cum_prod_df = cum_prod_df.sort_values(by=date_column, ascending=True)
    cum_prod_df = cum_prod_df.reset_index(drop=True)
    cum_dates = pd.to_datetime(cum_prod_df[date_column].values)

    date_time = df[date_column].values
    if isinstance(date_time[0], str):
        date_time = [parse_date_time_combined(x) for x in date_time]
        df[date_column] = date_time
    df = df.sort_values(by=date_column, ascending=True)
    df = df.reset_index(drop=True)
    date_time = pd.to_datetime(df[date_column].values)

    cum_prod_values = str_to_float32(cum_prod_df[cum_prod_column].values)
    cum_prod_rows = len(cum_prod_values)
    cum_prod_dict = {}
    for i in range(cum_prod_rows):
        cum_prod_dict[cum_dates[i].strftime('%d-%b-%Y')] = cum_prod_values[i]

    num_rows = len(df)
    cum_prod_list = []
    date_keys = cum_prod_dict.keys()
    for i in range(num_rows):
        date_key = date_time[i].strftime('%d-%b-%Y')
        if date_key in date_keys:
            cum_prod_list.append(cum_prod_dict[date_key])
        else:
            if i > 0:
                cum_prod_list.append(cum_prod_list[i - 1])
            else:
                cum_prod_list.append(0)
    df[cum_prod_column] = cum_prod_list
    return df

def get_aggregate_data(df, hours_to_agg, date_column):
    """This function aggregates data in the provided dataframe based upon the 
    time in the date and time column, and provided aggregation frequency.
    
    Parameters
    ----------
    :param df: Pandas dataframe with hourly well test or realtime data
    :param hours_to_agg: Aggregate data every hours_to_agg hours
    :param date_column: Name of dataframe column with date and time
    
    Return value(s)
    ---------------
    :return agg_df: Pandas dataframe with aggregated data
    """
    if hours_to_agg % 2 != 0:
        print("Number of hours for data aggregation should be an even number."\
              + " Returning...")
        return df

    date_time = df[date_column].values
    num_rows = len(date_time)
    if isinstance(date_time[0], str):
        date_time = [parse_date_time_combined(x) for x in date_time]
        df[date_column] = date_time
    df = df.sort_values(by=date_column, ascending=True)
    df = df.reset_index(drop=True)
    
    # Find new date and times for representing aggregate data time stamps
    agg_date_time = []
    row = 0
    while row < num_rows:
        central_row = row + int(hours_to_agg / 2)
        if central_row < num_rows:
            agg_date_time.append(df[date_column][central_row])
        else:
            central_row = row + int((num_rows - row) / 2)
            agg_date_time.append(df[date_column][central_row])
        row += hours_to_agg
    
    agg_df = pd.DataFrame(np.c_[agg_date_time], columns=[date_column])

    col_names = df.columns.tolist()
    col_names.remove(date_column)
    for col_name in col_names:
        row = 0
        col_values = []
        while row < num_rows:
            if col_name == io_const.CUM_LIQUID_COLUMN or \
            col_name == io_const.CUM_GAS_COLUMN:
                if (row + hours_to_agg) <= num_rows:
                    col_values.append(df[col_name][row + hours_to_agg - 1])
                else:
                    col_values.append(df[col_name][num_rows - 1])
            elif col_name == io_const.WING_VALVE_STATUS_COLUMN or \
            col_name == io_const.MASTER_VALVE_STATUS_COLUMN:
                status = io_const.VALVE_STATE_OPEN
                for i in range(hours_to_agg):
                    if (row + i) < num_rows:
                        if df[col_name][row + i] != status:
                            status = io_const.VALVE_STATE_CLOSE
                            break
                col_values.append(status)
            else:
                val = 0.
                nval = 0
                for i in range(hours_to_agg):
                    if (row + i) < num_rows:
                        if type(df[col_name][row + i]) == np.float32 or \
                        type(df[col_name][row + i]) == np.float64:
                            val += df[col_name][row + i]
                            nval += 1
                if nval > 0:
                    val = val / float(nval)
                col_values.append(val)
            row += hours_to_agg
        agg_df[col_name] = col_values
    return agg_df

def remove_well_closed_rows(df):
    """This function removes all rows from the dataframe other than the rows, 
    where status of the master valve and wing valve both is "OPEN".
    
    Parameters
    ----------
    :param df: Pandas dataframe with realtime well data
    
    Return value(s)
    ---------------
    :return df: Pandas dataframes with the rows where valve status is "OPEN"
    """
    col_names = df.columns.tolist()
    if io_const.MASTER_VALVE_STATUS_COLUMN in col_names and \
    io_const.WING_VALVE_STATUS_COLUMN in col_names:
        df = df[(df[io_const.MASTER_VALVE_STATUS_COLUMN] == io_const.VALVE_STATE_OPEN) & \
                (df[io_const.WING_VALVE_STATUS_COLUMN] == io_const.VALVE_STATE_OPEN)]
    df.drop(columns=[io_const.MASTER_VALVE_STATUS_COLUMN, 
                     io_const.WING_VALVE_STATUS_COLUMN], inplace=True)
    df.reset_index(drop=True, inplace=True)
    return df

def preprocess_prod_alloc_dataframe(prod_alloc_df):
    """This function processes date and time column of production allocation dataframe.
    
    Parameters
    ----------
    :param prod_alloc_df: Pandas dataframe with production allocation data
    
    Return value(s)
    ---------------
    :return prod_alloc_df: Pandas dataframe with processed date and time column
    """
    col_names = prod_alloc_df.columns.tolist()
    for col_name in col_names:
        if col_name != io_const.DATE_TIME_COLUMN:
            prod_alloc_df[col_name] = str_to_float32(prod_alloc_df[col_name].values)
        else:
            prod_alloc_df[col_name] = [parse_date_time_combined(x) for x in \
                         prod_alloc_df[col_name].values]
    return prod_alloc_df

def preprocess_well_test_dataframe(well_test_df, test_variables):
    """This function preprocesses pandas dataframe with well test data by converting 
    date time from string to date time object, adding WHP and WHT squared value columns, 
    and replacing NaN values of gas-lift rates with zeros.
    
    Parameters
    ----------
    :param well_test_df: Pandas dataframe with well test data
    :param test_variables: Well test variables to be modeled using machine 
                           learning algorithms
                   
    Return value(s)
    ---------------
    :return well_test_df: Pandas dataframe with processed well test data
    """
    for col_name in well_test_df.columns.tolist():
        if col_name != io_const.DATE_TIME_COLUMN:
            well_test_df[col_name] = str_to_float32(well_test_df[col_name].values)
    # Adding last well test value for the following variabes:
    #   ResPres, Liq_Rate, Oil_Rate, Wat_Rate, Gas_Rate, GOR, WCT
    for variable in test_variables:
        well_test_df = add_previous_value_column(well_test_df, variable, 
                                                 io_const.DATE_TIME_COLUMN)
    
    well_test_df[io_const.WHP_SQ_COLUMN] = well_test_df[io_const.WHP_COLUMN] * \
    well_test_df[io_const.WHP_COLUMN]
    well_test_df[io_const.WHT_SQ_COLUMN] = well_test_df[io_const.WHT_COLUMN] * \
    well_test_df[io_const.WHT_COLUMN]
    
    # Replace NaN gas injection rates with zero
    gas_in = np.array(well_test_df[io_const.GL_RATE_COLUMN].values)
    gas_in[~np.isfinite(gas_in)] = 0.
    well_test_df[io_const.GL_RATE_COLUMN] = gas_in
    return well_test_df

def preprocess_realtime_dataframe(pred_df, prod_alloc_df, well_test_df, 
                                  test_variables, aggregration_freq):
    """ This function preprocesss the pandas dataframe with realtime sensor data 
    by converting date time from string to date time object, adding WHP and WHT 
    squared value columns, and replacing NaN values of gas-lift rates with zeros. 
    Previous well test data columns are added for defined test variables, and then 
    columns for cumulative liquid and gas production are also added.
    Finally, data is aggregated on the basis of provided number of hours to aggregate.
    
    Parameters
    ----------
    :param pred_df: Pandas dataframe with hourly realtime sensor data
    :param prod_alloc_df: Pandas dataframe with production allocation data
    :param well_test_df: Pandas dataframe with well test data
    :test_variables: Well test variables to be modeled using machine 
                           learning algorithms
    :param aggregration_freq: Aggregate data every aggregration_freq hours
    
    Return value(s)
    ---------------
    :return pred_df: Processed realtime sensor data dataframe
    """
    gas_in = np.array(pred_df[io_const.GL_RATE_COLUMN].values)
    gas_in[~np.isfinite(gas_in)] = 0.
    pred_df[io_const.GL_RATE_COLUMN] = gas_in
    pred_df[io_const.WHP_COLUMN] = str_to_float32(pred_df[io_const.WHP_COLUMN].values.tolist())
    pred_df[io_const.WHP_SQ_COLUMN] = pred_df[io_const.WHP_COLUMN] * pred_df[io_const.WHP_COLUMN]
    pred_df[io_const.WHT_COLUMN] = str_to_float32(pred_df[io_const.WHT_COLUMN].values.tolist())
    pred_df[io_const.WHT_SQ_COLUMN] = pred_df[io_const.WHT_COLUMN] * pred_df[io_const.WHT_COLUMN]
    for variable in test_variables:
        pred_df = add_previous_well_test_columns(pred_df, 
                                                 io_const.DATE_TIME_COLUMN, 
                                                 well_test_df, 
                                                 io_const.DATE_TIME_COLUMN, 
                                                 variable)
    pred_df = add_cum_prod_column(pred_df, prod_alloc_df, io_const.DATE_TIME_COLUMN, 
                                          io_const.CUM_LIQUID_COLUMN)
    pred_df = add_cum_prod_column(pred_df, prod_alloc_df, io_const.DATE_TIME_COLUMN, 
                                          io_const.CUM_GAS_COLUMN)
    if aggregration_freq > 1:
        pred_df = get_aggregate_data(pred_df, aggregration_freq, 
                                     io_const.DATE_TIME_COLUMN)
    pred_df = remove_well_closed_rows(pred_df)
    return pred_df

def fill_null_outliers_with_local_mean(y_values, lookback, sigma_cutoff):
    """This function finds null values and outliers in the data based upon the 
    cutoff value of standard deviations. Data in a running window is considered 
    for calculating standard deviation, and if a data point is defined cut-off 
    multiples of standard deviations outside the local mean, then the value is 
    replaced with the local.
    
    Paramaters
    ----------
    :param y_values: Predicted or forecasted mean values
    :param lookback: Number of previous values to include in the running window 
                     for local mean and standard deviation computation
    :param sigma_cutoff: Number of standard deviations from local mean, beyond 
                         which a point is considered outlier
    
    Return value(s)
    ---------------
    :param y_values: Updated predicted or forecasted mean values
    """
    if isinstance(y_values, list):
        y_values = np.array(y_values)
    num_samples = y_values.shape[0]
    valid_idxs = np.where(np.isfinite(y_values))
    global_mean = np.mean(y_values[valid_idxs])
    global_std = np.std(y_values[valid_idxs])
    for i in range(lookback, num_samples):
        y_chunk = y_values[range(i - lookback, i + 1)]
        valid_idxs = np.where(np.isfinite(y_chunk))
        y_values_valid = y_chunk[valid_idxs]
        mean = np.mean(y_values_valid)
        if np.isfinite(y_values[i]) == False or \
        y_values[i] > (global_mean + sigma_cutoff * global_std) or \
        y_values[i] < (global_mean - sigma_cutoff * global_std):
            y_values[i] = mean
    return y_values

def fill_null_outliers_with_global_mean(y_values, sigma_cutoff):
    """This function finds null values and outliers in the data based upon the 
    cutoff value of standard deviations. If a data point is defined cut-off 
    multiples of standard deviations outside the global mean, then the value 
    is replaced with the global mean.
    
    Paramaters
    ----------
    :param y_values: Predicted or forecasted mean values
    :param sigma_cutoff: Number of standard deviations from global mean, beyond 
                         which a point is considered outlier
    
    Return value(s)
    ---------------
    :param y_values: Updated predicted or forecasted mean values
    """
    if isinstance(y_values, list):
        y_values = np.array(y_values)
    valid_idxs = np.where(np.isfinite(y_values))
    mean = np.mean(y_values[valid_idxs])
    std = np.std(y_values[valid_idxs])
    num_samples = y_values.shape[0]
    for i in range(num_samples):
        if np.isfinite(y_values[i]) == False or \
        y_values[i] > (mean + sigma_cutoff * std) or \
        y_values[i] < (mean - sigma_cutoff * std):
            y_values[i] = mean
    return y_values
