# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module describes various constants used during input/output of data 
from/to the CSV files. These constants include expected names of columns in 
different input CSV files, names used as file and model prefix and suffix, etc.

@author: Prabhaker Reddy Vanam
"""

import os

# Flag to save extracted data to CSV
SAVE_DATA_TO_CSV = False

# Constants: Directory and file names
BASE_DATA_DIR = os.path.join(os.getcwd(), "data")
TRAINING_DATA_DIR = os.path.join(BASE_DATA_DIR, "training")
TRAINING_DATA_CSV = "cbl_training.csv"
OUTPUT_DATA_DIR = os.path.join(os.getcwd(), "output")
MODELS_DIR = os.path.join(os.getcwd(), "models")
PARAMS_DIR = os.path.join(BASE_DATA_DIR, "params")
CHANNEL_DATA_CSV_SUFFIX = "_channel_data.csv"
WAVE_DATA_CSV_SUFFIX = "_wave_data.csv"
CEMO_DATA_CSV_SUFFIX = "_cemo_data.csv"
HEADER_CSV_SUFFIX = "_header_data.csv"
ZONE_DATA_CSV_SUFFIX = "_zone_data.csv"
SUMMARY_DATA_CSV_SUFFIX = "_summary_data.csv"
PLOTS_DIR = os.path.join(os.getcwd(), "plots")
PLOT_FILE_SUFFIX = ".png"
WAVE_PLOT_FILE_SUFFIX = "_wave.png"
CEMO_PLOT_FILE_SUFFIX = "_cemo.png"
ATC_PLOT_FILE_SUFFIX = "_atc.png"
ALL_PLOTS_FILE_SUFFIX = "_all_plots.pdf"
CASING_PLOT_FILE_SUFFIX = "_casing.png"
CCB_PLOT_FILE_SUFFIX = "_ccb.png"
BAKER_PREFIX = "BK"

# Constants: Column names in the DLIS Logical file/CSV files containing input data, and
#            for the intermediate Pandas dataframes created during the 
#            model training and prediction process.
SUMMARY_DF_COLUMN_LIST = [ 'Field Name' , 'Well Name' , 'Company' , 'Producer Name' , 'Set Name' , 'Frame Name' ,
                           'Total Rows and Columns' , 'Depth Range' , 'Column Names' ]
HEADER_PARAM_LIST =['CN', 'WN', 'FN', 'UWID', 'SET', 'RUN', 'ABSE_FVAL', 'BS', 'CSOD', 'CSWT', 'FAMP',
                     'FPAT', 'BPLO', 'BPHI', '!', 'COUN', 'STAT', 'FL', 'FL1', 'FL2', 'FL3', 'DATE',
                     'TDD', 'BLI', 'TLI', 'EKB', 'EDF', 'EGL', 'CMST', 'SBHI', 'SBLO', 'LCNM', 'STAT',
                     'R1', 'R2', 'R3', 'R3', 'R5', 'R6', 'R7', 'R8', 'R9', 'R10', 'R11', 'R12', 'R13', 'R14',
                     'R15', 'R16', 'CS1', 'CW1', 'CG1', 'CS2', 'CW2', 'CG2', 'CS3', 'CW3', 'CG3', 'CS4', 'CW4', 'CG4',
                     'LPAS', 'LDIR']
SBT_CHANNEL_SET = ['TDEP', 'AMAV', 'ATAV', 'ATC1', 'ATC2', 'ATC3', 'ATC4', 'ATC5', 'ATC6', 'CCL', 'DTMN', 'DTMX', 'GR', 'WAVE', 'CEMO']
SBT_CHANNEL_SET_I = ['TDEP','AMAV.I', 'ATAV.I', 'ATC1.I', 'ATC2.I', 'ATC3.I', 'ATC4.I', 'ATC5.I', 'ATC6.I', 'CCL.I', 'DTMN.I', 'DTMX.I', 'GR.I', 'WAVE.I', 'CEMO.I']
ATC_COLUMN_LIST = ['ATC1', 'ATC2', 'ATC3', 'ATC4', 'ATC5', 'ATC6']
ATC_I_COLUMN_LIST = ['ATC1.I', 'ATC2.I', 'ATC3.I', 'ATC4.I', 'ATC5.I', 'ATC6.I']
WAVE_COLUMN = 'WAVE'
WAVE_I_COLUMN = 'WAVE.I'
CEMO_COLUMN = 'CEMO'
CEMO_I_COLUMN = 'CEMO.I'
TDEP_COLUMN = 'TDEP'
DTMN_I_COLUMN = 'DTMN.I'
DTMX_I_COLUMN = 'DTMX.I'
GR_I_COLUMN = 'GR.I'
AMAV_I_COLUMN = 'AMAV.I'
ATAV_I_COLUMN = 'ATAV.I'
CCL_I_COLUMN = 'CCL.I'
DTMN_COLUMN = 'DTMN'
DTMX_COLUMN = 'DTMX'
GR_COLUMN = 'GR'
AMAV_COLUMN = 'AMAV'
ATAV_COLUMN = 'ATAV'
CCL_COLUMN = 'CCL'
CCB_COLUMN = 'CCB'

# Constants: These constants define the path and names of saved machine learning 
#            models, created using scikit-learn and Keras libraries.
MODEL_DIR = os.path.join(os.getcwd(), "models")
MODEL_NAME_SUFFIX = ".joblib"
MODEL_SEPARATOR = "-"
MODEL_FOLD = "fold"
KERAS_MODEL_SUFFIX = ".hdf5"

# For data scalers and prediction models
CQF_MODEL_PREFIX = "cqf"

# Hyper-parameters for the forecasting RNN training
RNN_NUM_HIDDEN_PARAM = "num_hidden"
RNN_BATCH_SIZE_PARAM = "batch_size"
RNN_NUM_EPOCHS_PARAM = "num_epochs"
RNN_PATIENCE_PARAM = "patience"
RNN_LOOKBACK_PARAM = "lookback"
RNN_LOOKAHEAD_PARAM = "lookahead"
RNN_DROPOUT_PARAM = "dropout"

# For writing outputs to files
PRED_MEAN_SUFFIX = "_MEAN"
PRED_STD_SUFFIX = "_STD"
OUTPUT_FILE_SUFFIX = "_output.csv"
INPUT_FILE_SUFFIX = "_input.csv"
MERGED_FILE_SUFFIX = "_merged_results.csv"

# Other String constants
WHITESPACE = " "
NOON_HOUR = "12:00"
NOON_HOUR_INT = 12

# Plotting related constants
CI_MULTIPLIER = 1.96
CUM_PLOT_OFFSET = 0.001
DEFAULT_PLOT_OFFSET = 0.2
MAX_CI_RATIO = 1.5