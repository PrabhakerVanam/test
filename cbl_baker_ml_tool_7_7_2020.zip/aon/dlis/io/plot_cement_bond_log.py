# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module provides utility function to plot prediction and  
forecasting results obtained from the trained machine learning models.

@author: Prabhaker Reddy Vanam
"""

import os

import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as plticker

from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const
from aon.dlis.io import data_reader as reader
from matplotlib.backends.backend_pdf import PdfPages, FigureCanvasPdf
#from aon.dlis.postprocess import data_postprocessor as postproc

from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()

"Set a default DPI for all figures in this file. Lower DPI gives smaller figures, higher bigger.",
mpl.rcParams['figure.dpi'] = 300
mpl.rcParams['axes.linewidth'] = 0.5 # set the value globally

def plot_cqf_predictions(well_name, cqf_array, tdept, target_file_path):
    """This function plots the predicted target variable (CQF) computed by a model,
    along with the TDEP values if available.
    
    Parameters
    ----------
    :param well_name: WWell Name
    :param cqf_array: Cement Qualify Flag in 2-D array form
    :param tdept: TDEP array values for indexing
    :param target_file_path: Target file path to save the generated plot
    """
    print("Plotting for well %s " % (well_name))
    extent = [0, len(cqf_array) * .015, 0, len(cqf_array)]

    fig, ax = plt.subplots(nrows=1, ncols=1, sharey=False, figsize=(2, 25), constrained_layout=True)

    plotted = ax.imshow(cqf_array, cmap='viridis', vmin=1, vmax=3,
                        extent=extent,
                        interpolation='nearest', origin='lower', alpha=1.0)

    cb = fig.colorbar(plotted, ax=ax, location='top', pad=0.005, shrink=0.2, spacing='uniform', label='Quality')
    cb.ax.tick_params(labelsize=2)
    # cb.set_label("Quality")

    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_major_locator(plticker.NullLocator())
    ax.xaxis.set_minor_locator(plticker.NullLocator())
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.0)
    ax.yaxis.set_tick_params(width=0.1)
    loc = plticker.MultipleLocator(base=25)
    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)

    return fig

def paint_channel(ax, curve, y_axis, x_axis, **kwargs):
    """Plot an image channel into an axes using an index channel for the y-axis

    Parameters
    ----------
    :param ax: matplotlib.axes
    :param curve : numpy array  - The curve to be plotted
    :param index : numpy array  - The depth index as a Channel object (slower) or a numpy array (faster)
    :param **kwargs : dict      - Keyword arguments to be passed on to ax.imshow()
    """
    # Determine the extent of the image so that the pixel centres correspond with the correct axis values
    dx = np.mean(x_axis[1:] - x_axis[:-1])
    dy = np.mean(y_axis[1:] - y_axis[:-1])
    # Y - Top to Bottom
    # extent = (x_axis[0] - dx/2, x_axis[-1] + dx/2, y_axis[0] - dy/2, y_axis[-1] + dy/2)
    # Y - Bottom To Top
    extent = (x_axis[0] - dx / 2, x_axis[-1] + dx / 2, y_axis[-1] + dy / 2, y_axis[0] - dy / 2)

    # Determine the correct orientation of the image
    if y_axis[1] < y_axis[0]:  # Frame recorded from the bottom to the top of the well
        origin = 'lower'
    else:  # Frame recorded from the top to the bottom of the well
        origin = 'upper'

    return ax.imshow(curve, aspect='auto', origin=origin, extent=extent, **kwargs)


def plot_single_wave_form(frame, curvedata, channel_name, image_file_path):
    """Plot an wave image channel into an axes using an index channel for the y-axis

    Parameters
    -----------
    :param frame:
    :param curvedata:
    :param channel_name:
    :param image_file_path:
    :return:
    """
    wf1 = reader.get_channel(frame, channel_name)

    # Determine the maximum absolute value of WF1 and WF2 so that we can balance the colormap around 0
    wf_max = np.max(np.abs(curvedata[channel_name]))
    wf_lim = 0.12 * wf_max

    # Parameters for plotting the waveforms
    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic' #'viridis'
        'vmin': -wf_lim,
        'vmax': wf_lim,
    }

    wf_samples = np.arange(wf1.dimension[0])  # x values to use in plotting

    # Create figure and axes
    fig, axes = plt.subplots(nrows=1, ncols=1, sharey=True, figsize=(3.5, 18), constrained_layout=True)

    # Plot WF1 as an image
    ax = axes
    im = paint_channel(ax, curvedata[channel_name], curvedata[frame.index], wf_samples, **wf_pltargs)
    cbar = fig.colorbar(im, ax=ax, location='top')
    cbar.set_label(f'{wf1.name}: {wf1.long_name}')
    ax.set_ylabel('Depth $z$ [m]')
    ax.set_xlabel('Sample $k$')

    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.1)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)

    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    plt.savefig(image_file_path)

    return fig


def plot_single_cem_form(frame, curvedata, channel_name, image_file_path):
    """ Plot an CEMO image channel into an axes using an index channel for the y-axis

    Parameters
    ----------
    :param frame: Dlis frame
    :param curvedata: ndarray contains the Cemo data
    :param channel_name: Channel name in the frame
    :param image_file_path: File path to save Cemo plot
    :return:
    """
    cem = reader.get_channel(frame, channel_name)

    cem_data = pd.DataFrame(curvedata[channel_name])
    cem_data = cem_data[cem_data != -999.25].dropna()

    # Determine the maximum absolute value of cemo so that we can balance the colormap around 0
    # cem_max = np.max(np.abs(cem_data))
    # cem_lim = 0.25 * cem_max
    colors = ['red', 'deepskyblue', 'orange', 'turquoise', 'darkturquoise', 'lightseagreen', 'darkcyan', 'teal',
              'darkslategray', 'black']
    cmap = mpl.colors.ListedColormap(colors)
    # Parameters for plotting the cemo
    cem_pltargs = {
        'cmap': cmap,
        'vmin': -10.0,
        'vmax': 100,
    }
    wf_samples = np.arange(cem.dimension[0])

    # Create figure and axes
    fig, axes = plt.subplots(nrows=1, ncols=1, sharey=True, figsize=(3.5, 18), constrained_layout=True)

    # Plot WF1 as an image
    ax = axes
    im = paint_channel(ax, curvedata[channel_name], curvedata[frame.index], wf_samples, **cem_pltargs)
    cbar = fig.colorbar(im, ax=ax, location='top', shrink=0.99)
    cbar.set_label(f'{cem.name}: {cem.long_name}')
    ax.set_ylabel('Depth $z$ [m]')
    ax.set_xlabel('Sample $k$')

    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.1)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)
    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    plt.savefig(image_file_path)

    return fig


def plot_single_atc(frame, curvedata, atc_channel_names, image_file_path):
    """ Plot ATC channels into an axes using an index channel for the y-axis

    Parameters
    ----------
    :param frame: dlis's logical files frame
    :param curvedata: ndarray ATC channel data
    :param atc_channel_names: List of ATC channels names
    :param image_file_path: File path to save plot
    :return: fig
    """
    tdept_column = io_const.TDEP_COLUMN
    logs = pd.DataFrame(curvedata[[tdept_column] + atc_channel_names])
    logs = logs[logs != -999.25].dropna()

    fig, axs = plt.subplots(nrows=1, ncols=len(atc_channel_names), figsize=(3.5, 18), sharey=True)
    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    color_list = ['green', 'red', 'blue', 'yellow', 'black', 'gray']

    for (ax, channel, color) in list(zip(axs, atc_channel_names, color_list)):
        ax.plot(logs[channel], logs[tdept_column], color=color, linewidth=0.4)
        ax.set_xlabel(channel, fontsize=2)
        ax.set_xlim(logs[channel].min(), logs[channel].max())

        ax.set_ylim(logs[tdept_column].min(), logs[tdept_column].max())

        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=4)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1)
        ax.yaxis.set_tick_params(width=0.01)

        ax.tick_params(labelsize=2)
        ax.yaxis.set_major_locator(loc)

    axs[0].set_ylabel("Depth(ft)", fontsize=2)
    axs[0].yaxis.set_tick_params(width=0.1)

    # f.suptitle('{} - Well Log - by {}'.format(well_name, producer_name), fontsize=14,y=0.94)
    plt.savefig(image_file_path)

    return fig


def plot_well_casing(nda_values,  min_depth, max_depth,  file_path):
    """ This function generates 2D well casing plot.

    Parameters
    -----------
    :param nda_values: ndarray values to plot well casing
    :param file_path: Path to save the image

    :return:
    """
    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic', #'viridis',
        'vmin': 0,
        'vmax': 2,
    }

    fig, axs = plt.subplots(nrows=1, ncols=1, sharey=True, figsize=(2, 50), constrained_layout=True)
    ylocator = mpl.ticker.MultipleLocator(base=25)

    # ax = fig.add_subplot(1,5,1)
    ax = axs
    ax.invert_yaxis()
    ax.yaxis.set_major_locator(ylocator)
    c2 = ax.imshow(nda_values, aspect='auto', origin='upper', extent=[0, 1, max_depth, min_depth], **wf_pltargs)
    cbar = fig.colorbar(c2, ax=ax, location='top', label='Well Image')

    plt.savefig(file_path, dpi=300)

    return fig

def plot_cement_quality(qf_ndarray,  min_depth, max_depth,  file_path):
    """ This function generates 2D cement Quality plot.

    Parameters
    -----------
    :param nda_values: ndarray values to plot Cement Quality
    :param file_path: Path to save the image

    :return:
    """
    wf_pltargs = {
        'cmap': 'viridis',  # plt.cm.Greys, #'seismic', #'viridis',
        'vmin': 1,
        'vmax': 3,
        'alpha': 1.0,
    }

    fig, axs = plt.subplots(nrows=1, ncols=1, sharey=True, figsize=(2, 50), constrained_layout=True)
    ylocator = mpl.ticker.MultipleLocator(base=25)

    # extent=[0, len(qf_ndarray)*.015, max_depth, min_depth]
    ax = axs
    ax.invert_yaxis()
    ax.yaxis.set_major_locator(ylocator)
    extent = [0, len(qf_ndarray) * .015, max_depth, min_depth]
    c2 = ax.imshow(qf_ndarray, origin='upper', extent=extent, interpolation='nearest', **wf_pltargs)
    cbar = fig.colorbar(c2, ax=ax, location='top', pad=0.005, shrink=0.2, spacing='uniform', label='Cement Quality')
    cbar.ax.tick_params(labelsize=2)

    plt.savefig(file_path, dpi=300)

    return fig


def plot_combo_log(casing_plot_data, frame, wave_channel_name, cemo_channel_name,\
                    atc_channel_names, min_depth, max_depth, file_path):
    """ This function generates combined plots for casing, WAVE, CEMO, ATC etc.

        Parameters
        -----------
        :param casing_plot_data: ndarray values to plot well casing
        :param frame
        :param min_depth
        :param max_depth
        :param file_path: Path to save the image

        :return:
    """

    print("""------------------------------CASING------------------------------------""")
    curves_data = frame.curves(strict=False)

    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic', #'viridis',
        'vmin': 0,
        'vmax': 2,
    }

    #fig, axes = plt.subplots(nrows=1, ncols=10, sharey=True, figsize=(7, max_depth*.01), constrained_layout=False)
    #fig5 = plt.figure(constrained_layout=True)
    widths = [2, 5, 5, 1, 1, 1, 1, 1, 1, 4, 2, 2]
    heights = [max_depth*.01]

    gs_kw = dict(width_ratios=widths, height_ratios=heights)
    fig, axes = plt.subplots(nrows=1, ncols=12, sharey=True, figsize=(7, max_depth*.01), constrained_layout=False,
                             gridspec_kw=gs_kw)

    ylocator = mpl.ticker.MultipleLocator(base=25)

    #ax = fig5.add_subplot(spec5[0, 0])
    ax = axes[0]
    ax.invert_yaxis()
    ax.set_ylabel('Depth [m]')
    ax.yaxis.set_major_locator(ylocator)
    ax.set_xlabel('CASING', fontsize=2)
    ax.yaxis.set_tick_params(width=0.05, colors='blue')
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)
    ax.xaxis.set_label_position('top')
    c2 = ax.imshow(casing_plot_data, aspect='auto', origin='upper', extent=[0, 1, max_depth, min_depth],
                   **wf_pltargs)
    #cbar = fig.colorbar(c2, ax=ax, location='top', label='Well Image')

    print("""------------------------------CEMO------------------------------------""")
    cem = reader.get_channel(frame, cemo_channel_name)

    cem_data = pd.DataFrame(curves_data[cemo_channel_name])
    cem_data = cem_data[cem_data != -999.25].dropna()

    # Determine the maximum absolute value of cemo so that we can balance the colormap around 0
    # cem_max = np.max(np.abs(cem_data))
    # cem_lim = 0.25 * cem_max
    colors = ['red', 'deepskyblue', 'orange', 'turquoise', 'darkturquoise', 'lightseagreen', 'darkcyan',
               'teal', 'darkslategray', 'black']
    cmap = mpl.colors.ListedColormap(colors)
    # Parameters for plotting the cemo
    cem_pltargs = {
        'cmap': cmap,
        'vmin': -10.0,
        'vmax': 100,
    }
    wf_samples = np.arange(cem.dimension[0])

    # Plot CEMO as an image
    #ax = fig5.add_subplot(spec5[0, 1])
    ax = axes[1]
    im = paint_channel(ax, curves_data[cemo_channel_name], curves_data[frame.index], wf_samples, **cem_pltargs)
    #cbar = fig.colorbar(im, ax=ax, location='top', shrink=0.99)
    #cbar.set_label(f'{cem.name}: {cem.long_name}')
    #ax.set_xlabel('Cemo Plot $k$')
    ax.set_xlabel('CEMO', fontsize=2)
    ax.xaxis.set_label_position('top')

    ax.xaxis.set_tick_params(width=0.01)
    ax.yaxis.set_tick_params(width=0.01)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)
    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------WAVE---------------------------------""")
    wf1 = reader.get_channel(frame, wave_channel_name)

    wf_max = np.max(np.abs(curves_data[wave_channel_name]))
    wf_lim = 0.12 * wf_max

    # Parameters for plotting the waveforms
    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic' #'viridis'
        'vmin': -wf_lim,
        'vmax': wf_lim,
    }

    wf_samples = np.arange(wf1.dimension[0])  # x values to use in plotting

    # Plot WAVE as an image
    #ax = fig5.add_subplot(spec5[0, 2])
    ax = axes[2]
    im = paint_channel(ax, curves_data[wave_channel_name], curves_data[frame.index], wf_samples, **wf_pltargs)
    #cbar = fig.colorbar(im, ax=ax, location='top')
    #cbar.set_label(f'{wf1.name}: {wf1.long_name}')
    #ax.set_ylabel('Depth $z$ [m]')
    #ax.set_xlabel('Sample $k$')
    ax.set_xlabel('WAVE', fontsize=2)
    ax.xaxis.set_label_position('top')

    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.1)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)

    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------ATC---------------------------------""")
    tdep_column = io_const.TDEP_COLUMN
    logs = pd.DataFrame(curves_data[[tdep_column] + atc_channel_names])
    logs = logs[logs != -999.25].dropna()

    #fig , axs = plt.subplots(nrows=1 , ncols=len(atc_channel_names) , figsize=(3.5, 18), sharey=True)
    #loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    color_list = ['green', 'red', 'blue', 'yellow', 'darkcyan', 'black']

    #axs = [fig5.add_subplot(spec5[0, 3], fig5.add_subplot(spec5[0, 4]), fig5.add_subplot(spec5[0, 5]),
    #                        fig5.add_subplot(spec5[0, 6]), fig5.add_subplot(spec5[0, 7]), fig5.add_subplot(spec5[0, 8]))]
    axs = axes[3:9]
    for (ax, channel, color) in list(zip(axs, atc_channel_names, color_list)):

        ax.plot(logs[channel], logs[tdep_column], color=color, linewidth=0.4)
        ax.set_xlabel(channel, fontsize=2)
        ax.set_xlim(logs[channel].min(), logs[channel].max())

        ax.set_ylim(logs[tdep_column].min(), logs[tdep_column].max())

        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=4)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1)
        ax.yaxis.set_tick_params(width=0.01)

        ax.tick_params(labelsize=2)
        ax.yaxis.set_major_locator(loc)

    print("""-----------------------------GR, DTMN & DTMX---------------------------------""")
    # DTMN DTMX in single Axis
    channel_dtmn = 'DTMN.I'
    channel_dtmx = 'DTMX.I'
    channle_gr = 'GR.I'

    df_dtmnmx = pd.DataFrame(curves_data[ [ tdep_column ] + [ channel_dtmn , channel_dtmx , channle_gr ] ])
    df_dtmnmx = df_dtmnmx[ df_dtmnmx != -999.25 ].dropna()

    # mu1 = df_dtmnmx[channel_dtmn].mean(axis=1)
    # sigma1 = df_dtmnmx[channel_dtmn].std(axis=1)
    # mu2 = df_dtmnmx[tdep_column].mean(axis=1)
    # sigma2 = df_dtmnmx[tdep_column].std(axis=1)

    ax = axes[ 9 ]
    ax.plot(df_dtmnmx[ channel_dtmn ] , df_dtmnmx[ tdep_column ] , color='green' , linewidth=0.4)
    ax.plot(df_dtmnmx[ channel_dtmx ] , df_dtmnmx[ tdep_column ] , color='red' , linewidth=0.4)
    ax.plot(df_dtmnmx[ channle_gr ] , df_dtmnmx[ tdep_column ] , color='blue' , linewidth=0.4)

    ax.set_xlabel(channle_gr + ' - ' + channel_dtmn + ' - ' + channel_dtmx , fontsize=2)
    ax.set_xlim(min(df_dtmnmx[ channel_dtmn ].min() , df_dtmnmx[ channel_dtmx ].min() , df_dtmnmx[ channle_gr ].min()) ,
                max(df_dtmnmx[ channel_dtmn ].max() , df_dtmnmx[ channel_dtmx ].max() , df_dtmnmx[ channle_gr ].max()))

    ax.set_ylim(logs[tdep_column].min(), logs[tdep_column].max())
    ax.fill_between(0, df_dtmnmx[channel_dtmx], facecolor='blue', alpha=0.5)
    #ax.fill(df_dtmnmx[channel_dtmx], 0, df_dtmnmx[channel_dtmx], facecolor='yellow', alpha=0.5)

    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.01)

    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------AMAV & ATAV---------------------------------""")
    # AMAV & ATAV in single Axis
    channel_amav = 'AMAV.I'
    channel_atav = 'ATAV.I'

    df_amtav = pd.DataFrame(curves_data[ [ tdep_column ] + [ channel_amav , channel_atav ] ])
    df_amtav = df_amtav[ df_amtav != -999.25 ].dropna()

    ax = axes[ 10 ]
    ax.plot(df_amtav[ channel_amav ] , df_amtav[ tdep_column ] , color='green' , linewidth=0.4)
    ax.plot(df_amtav[ channel_atav ] , df_amtav[ tdep_column ] , color='red' , linewidth=0.4)

    ax.set_xlabel(channel_amav + ' - ' + channel_atav , fontsize=2)
    ax.set_xlim(min(df_amtav[ channel_amav ].min() , df_amtav[ channel_atav ].min()) ,
                max(df_amtav[ channel_amav ].max() , df_amtav[ channel_atav ].max() ))

    ax.set_ylim(df_amtav[ tdep_column ].min() , df_amtav[ tdep_column ].max())
    ax.fill_between(0 , df_amtav[ channel_amav ] , facecolor='blue' , alpha=0.5)

    ax.tick_params(axis="x" , labelsize=2)
    ax.tick_params(axis="y" , labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.01)

    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------CCL---------------------------------""")
    # CCL in single Axis
    channel_ccl = 'CCL.I'

    df_ccl = pd.DataFrame(curves_data[ [ tdep_column ] + [ channel_ccl] ])
    df_ccl = df_ccl[ df_ccl != -999.25 ].dropna()

    ax = axes[ 11 ]
    ax.plot(df_ccl[ channel_ccl ] , df_ccl[ tdep_column ] , color='green' , linewidth=0.4)

    ax.set_xlabel(channel_ccl , fontsize=2)
    ax.set_xlim(df_ccl[ channel_ccl ].min(), df_ccl[ channel_ccl ].max())

    ax.set_ylim(df_ccl[ tdep_column ].min() , df_ccl[ tdep_column ].max())
    ax.fill_between(0 , df_ccl[ channel_ccl ] , facecolor='blue' , alpha=0.5)

    ax.tick_params(axis="x" , labelsize=2)
    ax.tick_params(axis="y" , labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.01)

    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)


    # get rid of the frame
    for spine in plt.gca().spines.values():
        spine.set_visible(True)

    with PdfPages(file_path) as pdf:
        pdf.savefig(fig,  dpi=300, bbox_inches="tight", pad_inches=0.5)

    fig.savefig("D:\\Temp\\test.svg", format='svg', dpi=300,  bbox_inches="tight", pad_inches=0.5)

    return fig


def plot_combo_grid(casing_plot_data, frame, ccb_ndarray, wave_channel_name, cemo_channel_name,\
                    atc_channel_names, ccl_challen_name, gr_challen_name, amav_challen_name,\
                    atav_challen_name, dtmn_challen_name, dtmx_challen_name, min_depth, max_depth, file_path):
    """ This function generates combined plots for casing, WAVE, CEMO, ATC etc.

        Parameters
        -----------
        :param casing_plot_data: ndarray values to plot well casing
        :param frame
        :param min_depth
        :param max_depth
        :param file_path: Path to save the image

        :return:
    """

    print("""------------------------------CASING------------------------------------""")
    curves_data = frame.curves(strict=False)

    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic', #'viridis',
        'vmin': 0,
        'vmax': 2,
    }

    #fig, axes = plt.subplots(nrows=1, ncols=10, sharey=True, figsize=(7, max_depth*.01), constrained_layout=False)
    #fig5 = plt.figure(constrained_layout=True)
    widths = [2, 5, 5, 1, 1, 1, 1, 1, 1, 4, 2, 2, 1]
    heights = [max_depth*.01]

    gs_kw = dict(width_ratios=widths, height_ratios=heights)
    fig, axes = plt.subplots(nrows=1, ncols=13, sharey=True, figsize=(7, max_depth*.01), constrained_layout=False,
                             gridspec_kw=gs_kw)

    ylocator = mpl.ticker.MultipleLocator(base=25)

    #ax = fig5.add_subplot(spec5[0, 0])
    ax = axes[0]
    ax.invert_yaxis()
    ax.set_ylabel('Depth [m]')
    ax.yaxis.set_major_locator(ylocator)
    ax.set_xlabel('CASING', fontsize=2)
    ax.yaxis.set_tick_params(width=0.05, colors='blue')
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)
    ax.xaxis.set_label_position('top')
    c2 = ax.imshow(casing_plot_data, aspect='auto', origin='upper', extent=[0, 1, max_depth, min_depth],
                   **wf_pltargs)
    #cbar = fig.colorbar(c2, ax=ax, location='top', label='Well Image')

    print("""------------------------------CEMO------------------------------------""")
    cem = reader.get_channel(frame, cemo_channel_name)

    cem_data = pd.DataFrame(curves_data[cemo_channel_name])
    cem_data = cem_data[cem_data != -999.25].dropna()

    # Determine the maximum absolute value of cemo so that we can balance the colormap around 0
    # cem_max = np.max(np.abs(cem_data))
    # cem_lim = 0.25 * cem_max
    colors = ['red', 'deepskyblue', 'orange', 'turquoise', 'darkturquoise', 'lightseagreen', 'darkcyan',
               'teal', 'darkslategray', 'black']
    cmap = mpl.colors.ListedColormap(colors)
    # Parameters for plotting the cemo
    cem_pltargs = {
        'cmap': cmap,
        'vmin': -10.0,
        'vmax': 100,
    }
    wf_samples = np.arange(cem.dimension[0])

    # Plot CEMO as an image
    #ax = fig5.add_subplot(spec5[0, 1])
    ax = axes[1]
    im = paint_channel(ax, curves_data[cemo_channel_name], curves_data[frame.index], wf_samples, **cem_pltargs)
    #cbar = fig.colorbar(im, ax=ax, location='top', shrink=0.99)
    #cbar.set_label(f'{cem.name}: {cem.long_name}')
    #ax.set_xlabel('Cemo Plot $k$')
    ax.set_xlabel('CEMO', fontsize=2)
    ax.xaxis.set_label_position('top')

    ax.xaxis.set_tick_params(width=0.01)
    ax.yaxis.set_tick_params(width=0.01)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)
    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------WAVE---------------------------------""")
    wf1 = reader.get_channel(frame, wave_channel_name)

    wf_max = np.max(np.abs(curves_data[wave_channel_name]))
    wf_lim = 0.12 * wf_max

    # Parameters for plotting the waveforms
    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic' #'viridis'
        'vmin': -wf_lim,
        'vmax': wf_lim,
    }

    wf_samples = np.arange(wf1.dimension[0])  # x values to use in plotting

    # Plot WAVE as an image
    #ax = fig5.add_subplot(spec5[0, 2])
    ax = axes[2]
    im = paint_channel(ax, curves_data[wave_channel_name], curves_data[frame.index], wf_samples, **wf_pltargs)
    ax.set_xlabel('WAVE', fontsize=2)
    ax.xaxis.set_label_position('top')

    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.1)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)

    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------ATC---------------------------------""")
    tdep_column = io_const.TDEP_COLUMN
    logs = pd.DataFrame(curves_data[[tdep_column] + atc_channel_names])
    logs = logs[logs != -999.25].dropna()

    #fig , axs = plt.subplots(nrows=1 , ncols=len(atc_channel_names) , figsize=(3.5, 18), sharey=True)
    #loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    color_list = ['green', 'red', 'blue', 'yellow', 'darkcyan', 'black']

    #axs = [fig5.add_subplot(spec5[0, 3], fig5.add_subplot(spec5[0, 4]), fig5.add_subplot(spec5[0, 5]),
    #                        fig5.add_subplot(spec5[0, 6]), fig5.add_subplot(spec5[0, 7]), fig5.add_subplot(spec5[0, 8]))]
    axs = axes[3:9]
    for (ax, channel, color) in list(zip(axs, atc_channel_names, color_list)):

        ax.plot(logs[channel], logs[tdep_column], color=color, linewidth=0.4)
        ax.set_xlabel(channel, fontsize=2)
        ax.set_xlim(logs[channel].min(), logs[channel].max())

        ax.set_ylim(logs[tdep_column].min(), logs[tdep_column].max())

        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=4)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1)
        ax.yaxis.set_tick_params(width=0.01)

        ax.tick_params(labelsize=2)
        ax.yaxis.set_major_locator(loc)

    print("""-----------------------------GR, DTMN & DTMX---------------------------------""")
    # GR , DTMN,  DTMX in single Axis


    df_dtmnmx = pd.DataFrame(curves_data[ [ tdep_column ] + [ dtmn_challen_name , dtmx_challen_name , gr_challen_name ] ])
    df_dtmnmx = df_dtmnmx[ df_dtmnmx != -999.25 ].dropna()

    # mu1 = df_dtmnmx[channel_dtmn].mean(axis=1)
    # sigma1 = df_dtmnmx[channel_dtmn].std(axis=1)
    # mu2 = df_dtmnmx[tdep_column].mean(axis=1)
    # sigma2 = df_dtmnmx[tdep_column].std(axis=1)

    ax = axes[ 9 ]
    ax.plot(df_dtmnmx[ dtmn_challen_name ] , df_dtmnmx[ tdep_column ] , color='green' , linewidth=0.4)
    ax.plot(df_dtmnmx[ dtmx_challen_name ] , df_dtmnmx[ tdep_column ] , color='red' , linewidth=0.4)
    ax.plot(df_dtmnmx[ gr_challen_name ] , df_dtmnmx[ tdep_column ] , color='blue' , linewidth=0.4)

    ax.set_xlabel(gr_challen_name + ' - ' + dtmn_challen_name + ' - ' + dtmx_challen_name , fontsize=2)
    ax.set_xlim(min(df_dtmnmx[ dtmn_challen_name ].min() , df_dtmnmx[ dtmx_challen_name ].min() , df_dtmnmx[ gr_challen_name ].min()) ,
                max(df_dtmnmx[ dtmn_challen_name ].max() , df_dtmnmx[ dtmx_challen_name ].max() , df_dtmnmx[ gr_challen_name ].max()))

    ax.set_ylim(logs[tdep_column].min(), logs[tdep_column].max())
    ax.fill_between(0, df_dtmnmx[dtmx_challen_name], facecolor='blue', alpha=0.5)
    #ax.fill(df_dtmnmx[channel_dtmx], 0, df_dtmnmx[channel_dtmx], facecolor='yellow', alpha=0.5)

    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.01)

    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------AMAV & ATAV---------------------------------""")
    # AMAV & ATAV in single Axis

    df_amtav = pd.DataFrame(curves_data[ [ tdep_column ] + [ amav_challen_name , atav_challen_name ] ])
    df_amtav = df_amtav[ df_amtav != -999.25 ].dropna()

    ax = axes[ 10 ]
    ax.plot(df_amtav[ amav_challen_name ] , df_amtav[ tdep_column ] , color='green' , linewidth=0.4)
    ax.plot(df_amtav[ atav_challen_name ] , df_amtav[ tdep_column ] , color='red' , linewidth=0.4)

    ax.set_xlabel(amav_challen_name + ' - ' + atav_challen_name , fontsize=2)
    ax.set_xlim(min(df_amtav[ amav_challen_name ].min() , df_amtav[ atav_challen_name ].min()) ,
                max(df_amtav[ amav_challen_name ].max() , df_amtav[ atav_challen_name ].max() ))

    ax.set_ylim(df_amtav[ tdep_column ].min() , df_amtav[ tdep_column ].max())
    ax.fill_between(0 , df_amtav[ amav_challen_name ] , facecolor='blue' , alpha=0.5)

    ax.tick_params(axis="x" , labelsize=2)
    ax.tick_params(axis="y" , labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.01)

    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------CCL---------------------------------""")
    # CCL in single Axis

    df_ccl = pd.DataFrame(curves_data[ [ tdep_column ] + [ ccl_challen_name] ])
    df_ccl = df_ccl[ df_ccl != -999.25 ].dropna()

    ax = axes[ 11 ]
    ax.plot(df_ccl[ ccl_challen_name ] , df_ccl[ tdep_column ] , color='green' , linewidth=0.4)

    ax.set_xlabel(ccl_challen_name , fontsize=2)
    ax.set_xlim(df_ccl[ ccl_challen_name ].min(), df_ccl[ ccl_challen_name ].max())

    ax.set_ylim(df_ccl[ tdep_column ].min() , df_ccl[ tdep_column ].max())
    ax.fill_between(0 , df_ccl[ ccl_challen_name ] , facecolor='blue' , alpha=0.5)

    ax.tick_params(axis="x" , labelsize=2)
    ax.tick_params(axis="y" , labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.01)

    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)

    print("""-----------------------------CCB---------------------------------""")
    # CCB in single Axis
    wf_pltargs = {
        'cmap': 'RdYlGn',  # plt.cm.Greys, #'seismic', #'viridis',
        'vmin': 1 ,
        'vmax': 3 ,
        'alpha': 1.0 ,
        'interpolation' : 'nearest',
    }

    ax = axes[ 12 ]
    extent = [ 0 , len(ccb_ndarray) * .015 , max_depth , min_depth ]
    #c2 = ax.imshow(ccb_ndarray , origin='upper', extent=extent , **wf_pltargs)
    im = paint_channel(ax, ccb_ndarray, curves_data[frame.index], wf_samples, **wf_pltargs)
    #cbar = fig.colorbar(c2 , ax=ax, pad=0.005, shrink=0.2, spacing='uniform',  label='Cement Quality')
    #cbar.ax.tick_params(labelsize=2)

    ax.set_xlabel('CCB' , fontsize=2)
    ax.xaxis.set_label_position('top')

    ax.tick_params(axis="x" , labelsize=2)
    ax.tick_params(axis="y" , labelsize=4)

    #ax.invert_yaxis()
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.01)

    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)


    # get rid of the frame
    # for spine in plt.gca().spines.values():
    #     spine.set_visible(True)

    with PdfPages(file_path) as pdf:
        pdf.savefig(fig,  dpi=300, bbox_inches="tight", pad_inches=0.5)

    fig.savefig(file_path+".svg", format='svg', dpi=300,  bbox_inches="tight", pad_inches=0.5)

    return fig

