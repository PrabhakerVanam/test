# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module reads data from given DLIS files for Cement Bond logs,
and returns populated Pandas dataframes. Purpose of this module is to provide a loose
coupling between the data population module and the data source. 
In future, beyond PoC scope, this module may be substituted with a module 
reading data from other data source, and providing similar dataframes.

@author: Prabhaker Reddy Vanam
"""

import os
import pandas as pd
import numpy as np
from aon.dlis.io import io_constants as io_const
import logging


def get_frame_from_logical_file(lfile):
    """Extract 'frame' from Logical File

    Parameters
    ----------
    :param lfile : Logical File from a dlis

    Returns
    -------
    frame : 'frame' from Logical File
    """
    try:
        frame = lfile.object('frame' , '0_250000B0')

    except Exception as e:
        logging.error(f"ERROR : {e}")
        frame = lfile.object('frame' , '0_500000B0')

    return frame


def index_of(frame):
    """Return the index channel of the frame"""
    return next(ch for ch in frame.channels if ch.name == frame.index)


def get_channel(frame, name):
    """Get a channel with a given name from a given frame; fail if the frame does not have exactly one such channel"""
    [channel] = [x for x in frame.channels if x.name == name]
    return channel


def get_channel_names(frame , duplicate_channel_list):
    """Create a List that contains the single dimensional channel names of 'frame',
    duplicate channels are ignored

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    # print("--------------------------------------------")
    # keep default column name as FRAMENO
    # channel_names = ['FRAMENO']
    channel_names = [ ]
    for ch in frame.channels:

        dim = ch.dimension
        name = ch.name
        # print(dim[0])
        if dim[ 0 ] == 1:
            if name not in duplicate_channel_list:
                channel_names.append(name)

    return channel_names


def get_all_channel_names_of_logical_file(logical_file , duplicate_channel_list):
    """Create a List that contains all channel names of 'logical file',
    duplicate channels are ignoted

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    # channel_names = ['FRAMENO']
    channel_names = [ ]
    for ch in logical_file.channels:
        # dim = ch.dimension
        name = ch.name
        if name not in duplicate_channel_list:
            channel_names.append(name)

    return channel_names


def get_all_channel_names(frame , duplicate_channel_list):
    """Create a List that contains all channel names of 'frame',
    duplicate channels are ignored

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    # channel_names = ['FRAMENO']
    channel_names = [ ]
    for ch in frame.channels:
        # dim = ch.dimension
        name = ch.name
        if name not in duplicate_channel_list:
            channel_names.append(name)

    return channel_names


def get_wave_channel_name(frame , duplicate_channel_list):
    """Create a List that contains the multi dimensional channel names of 'frame', One
    channel pr. CEMO/WAVE

    Parameters
    ----------
    :param frame : Frame
        frame from a logical file
    :param duplicate_channel_list : list of duplicate channel names

    Returns
    -------
    channle_names : list
    """
    channel_names = [ ]
    for ch in frame.channels:

        dim = ch.dimension
        name = ch.name
        if dim[ 0 ] >= 250 and (name == 'WAVE' or name == 'CEMO' or name == 'WAVE.I' or name == 'CEMO.I'):

            print("Channel Name : {} and Size {}".format(name , dim[ 0 ]))
            if name not in duplicate_channel_list:
                channel_names.append(name)

    return channel_names


''' 
To explore the parameters and channels in the file, we create a helper function that iterates through a sequence of 
dlisio objects and compiles a pandas dataframe from selected object attributes. We will show how the function is used 
in the next cell.
'''


def summarize(objs , **kwargs):
    """Create a pd.DataFrame that summarize the content of 'objs', One
    object pr. row

    Parameters
    ----------
    :param objs : list()
        list of metadata objects

    :param **kwargs
        Keyword arguments
        Use kwargs to tell summarize() which fields (attributes) of the
        objects you want to include in the DataFrame. The parameter name
        must match an attribute on the object in 'objs', while the value
        of the parameters is used as a column name. Any kwargs are excepted,
        but if the object does not have the requested attribute, 'KeyError'
        is used as the value.

    Returns
    -------
    summary : pd.DataFrame
    """
    summary = [ ]
    for attr , label in kwargs.items():
        column = [ ]
        for obj in objs:
            try:
                value = getattr(obj , attr)
            except AttributeError:
                value = 'KeyError'

            column.append(value)
        summary.append(column)

    summary = pd.DataFrame(summary).T
    summary.columns = kwargs.values()

    return summary


def populate_csv_data_dataframes(csv_file_path ,
                                 header_info_file_path):
    """This is a utility function, which returns Pandas dataframes containing
    information specific to a desired well.
    
    Parameters
    ----------
    :param csv_file_path: Path to the file containing dlis Extracted CSV Data.
    :param header_info_file_path: CSV File path contains the header info

    Return value(s)
    ---------------
    :return well_test_df: Pandas dataframe with well test data
    """
    well_log_df = None
    header_df = None

    # Reading the CBL data file
    if os.path.isfile(csv_file_path):
        well_log_df = pd.read_csv(csv_file_path)
    # Reading the Header Info data file
    if os.path.isfile(header_info_file_path):
        header_df = pd.read_csv(header_info_file_path)

    # Reading well location file
    well_log_df = well_log_df.loc[ well_log_df[ io_const.BAKER_COLUMN_NAMES ] ]
    return well_log_df , header_df


def get_casing_plot_data(casing_df):
    """This is a utility function, which returns Tdept min and Max, dataframe to plot well casing

    :param casing_df: Casing info Dataframe (casing size, zone name , zone min, zone max etc.)
    :return:
    min_depth - Casing start depth
    max_depth - Casing End depth
    casing_dataframe - Casing dataframe to plot
    """
    casing_df.rename(columns={'Value(s)': 'Value'} , inplace=True)
    casing_size_list = casing_df.Value.unique()
    casing18_min = 0
    casing18_max = 0
    casing13_min = 0
    casing13_max = 0
    casing9_min = 0
    casing9_max = 0
    casing7_min = 0
    casing7_max = 0
    # print(parameter_table)
    print(casing_size_list)
    for cs in casing_size_list:
        cs_values = casing_df[ [ 'Minimum' , 'Maximum' ] ][ casing_df.Value == cs ].values
        print("Min: {}".format(cs_values.min()) , "Max: {}".format(cs_values.max()))
        if cs.startswith('7'):
            casing7_min = cs_values.min()
            casing7_max = cs_values.max()
        if cs.startswith('9'):
            casing9_min = cs_values.min()
            casing9_max = cs_values.max()
        if cs.startswith('13'):
            casing13_min = cs_values.min()
            casing13_max = cs_values.max()
        if cs.startswith('18'):
            casing18_min = cs_values.min()
            casing18_max = cs_values.max()

    min_depth = min(casing18_min , casing18_max , casing13_min , casing13_max , casing9_min , casing9_max ,
                    casing7_min ,
                    casing7_max)
    max_depth = max(casing18_min , casing18_max , casing13_min , casing13_max , casing9_min , casing9_max ,
                    casing7_min ,
                    casing7_max)

    return min_depth , max_depth , prepare_casing_plot_data(casing18_min , casing18_max , casing13_min , casing13_max ,
                                                            casing9_min , casing9_max , casing7_min , casing7_max)


def prepare_casing_plot_data(casing18_min , casing18_max , casing13_min , casing13_max , casing9_min , casing9_max ,
                             casing7_min , casing7_max):
    """ Create a pd.DataFrame that filled with casing data used to plot the casing plot

    Parameters
    ----------
    :param casing13_min: 18" casing min depth
    :param casing13_max: 18" casing max depth
    :param casing13_min: 13" casing min depth
    :param casing13_max: 13" casing max depth
    :param casing9_min: 9.5" casing min depth
    :param casing9_max: 9.5" casing max depth
    :param casing7_min: 7" casing min depth
    :param casing7_max: 7" casing max depth

    Return value(s)
    ---------------
    :return casing_df: Pandas dataframe with well test data
    """
    min_depth = min(casing18_min , casing18_max , casing13_min , casing13_max , casing9_min , casing9_max ,
                    casing7_min , casing7_max)
    max_depth = max(casing18_min , casing18_max , casing13_min , casing13_max , casing9_min , casing9_max ,
                    casing7_min , casing7_max)

    index = np.arange(min_depth , max_depth)

    # Dataframe Columns to differentiate the casings
    columns = [ 'C18L' , 'C13L' , 'C9L' , 'C7L' , 'C00' , 'C11' , 'C7R' , 'C9R' , 'C13R' , 'C18R' ]

    casing_df = pd.DataFrame(index=index , columns=columns)
    casing_df = casing_df.fillna(-2)
    casing_df[ 'idx' ] = casing_df.index

    casing_df[ 'C18L' ] = casing_df[ [ 'idx' , 'C18L' ] ].apply(lambda x: 2 if x.idx <= casing13_max else -2 , axis=1)
    casing_df[ 'C18R' ] = casing_df[ 'C18L' ]

    casing_df[ 'C13L' ] = casing_df[ [ 'idx' , 'C13L' ] ].apply(lambda x: 2 if x.idx <= casing13_max else -2 , axis=1)
    casing_df[ 'C13R' ] = casing_df[ 'C13L' ]

    casing_df[ 'C9L' ] = casing_df[ [ 'idx' , 'C9L' ] ].apply(lambda x: 2 if x.idx <= casing9_max else -2 , axis=1)
    casing_df[ 'C9R' ] = casing_df[ 'C9L' ]

    casing_df[ 'C7L' ] = casing_df[ [ 'idx' , 'C7L' ] ].apply(lambda x: 2 if x.idx >= casing7_min else -2 , axis=1)
    casing_df[ 'C7R' ] = casing_df[ 'C7L' ]

    # drop the index  not to display in the ndarray
    casing_df.drop(columns=[ 'idx' ] , inplace=True)

    return casing_df
