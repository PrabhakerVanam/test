# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 12:53:04 2020

This Python script provides an entry-point for building machine learning
prediction models for BAKER Cement Bond Logs. The methods extracts dlis files,
develop machine learning models by considering several combinations of the
ATC channels, and develop predictive models for
Cement Bond Quality (CQF). This script can be executed from Spyder IDE, or
from a Windows command prompt as > python entry_dlis_baker.py

Note:
    Training and predictions should run separately. Please don't provide \
    both training and prediction flags as True at the same time.

Usage:
    Following commands assume that dlis/data is provided for BAKER,
    and we are generating predictions for the Cement quality.

    Execute this file from command-line using following commands:

        * Training

        python entry_dlis_baker.py -dlis XXX.dlis -input_csv Well_Locations.csv \
        -tr True -pr False -df False -dft False

@author: Prabhaker Reddy Vanam
"""
import os
import sys
import pandas as pd
import numpy as np
import dlisio
from aon.dlis.io import data_reader as reader
from aon.dlis.model import model_constants as ml_const
from aon.dlis.io import io_constants as io_const
from aon.dlis.io import plot_cement_bond_log as plot_cbl
from aon.dlis.model import cbl_model_helper as ml_helper
import joblib

from matplotlib.backends.backend_pdf import PdfPages , FigureCanvasPdf

import logging

np.random.seed(ml_const.RANDOM_SEED)

# Set encodings for dlisio
dlisio.set_encodings([ 'latin1' ])

training_data_dir = ""

logical_file_info_dict = {}


def main(dlis_file='xyz.dlis'):
    print(dlis_file)

    training_data_dir = os.path.join(io_const.BASE_DATA_DIR , io_const.TRAINING_DATA_DIR)

    print(training_data_dir)

    extract_dlis(dlis_file)


def extract_dlis(source_dlis_file):
    duplicate_channel_list = [ ]

    source_dlis_file = source_dlis_file.replace('/' , '\\\\')

    dlis_summary = pd.DataFrame(columns=io_const.SUMMARY_DF_COLUMN_LIST)

    with dlisio.load(source_dlis_file) as files:

        print(files.describe())

        is_casing_plotted = False

        for lfile in files:
            # print(lfile.describe())

            problematic_list = lfile.problematic

            # check for duplicate channels to skip by the code
            if len(problematic_list) > 0:

                print("Its Problematic files : {}".format(problematic_list))

                prob_channel_list = [ x[ 0 ] for x in problematic_list ]

                for dup_chn in prob_channel_list:

                    prob_channel_name = dup_chn.name
                    # print(prob_channel_name)

                    if prob_channel_name not in duplicate_channel_list:
                        duplicate_channel_list.append(prob_channel_name)

            # Validate columns
            lfile_channels: list = reader.get_all_channel_names_of_logical_file(lfile , duplicate_channel_list)

            # 1. Validate required channels
            channel_missing = False

            for (ch , ch_i) in zip(io_const.SBT_CHANNEL_SET , io_const.SBT_CHANNEL_SET_I):

                print((lfile_channels.count(ch) , lfile_channels.count(ch_i)))

                if ch not in lfile_channels and ch_i not in lfile_channels:
                    channel_missing = True

                if channel_missing:
                    break
            fig_list = [ ]
            casing_fig = None
            if not channel_missing:

                print("All required channels exist in the logical file  {} ".format(lfile.describe()))

                parameter_table = reader.summarize(lfile.parameters , name='Name' , long_name='Long name' ,
                                                   values='Value(s)' , zones='Zone(s)')

                zone_table = reader.summarize(lfile.zones , name='Name' , minimum='Minimum' , maximum='Maximum')

                # parameter_table['Value(s)'] = parameter_table['Value(s)'].apply(lambda x: str(x).strip('[]'))
                parameter_table[ 'Zone(s)' ] = parameter_table[ 'Zone(s)' ].apply(lambda x: str(x).strip('[]'))

                # Hide parameters containing names; see the privacy note in the Introduction. Comment out these lines
                # to show them.
                exclude_mask = ~parameter_table[ 'Name' ].isin([ 'RR1' , 'WITN' , 'ENGI' ])

                parameter_table = parameter_table[ exclude_mask ]

                well_name = 'NOT EXISTS'
                exists = 'WN' in parameter_table[ "Name" ].values
                if exists:
                    well_name = parameter_table[ parameter_table[ "Name" ] == "WN" ][ 'Value(s)' ].values[ 0 ]

                company_name = 'NOT EXISTS'
                exists = 'CN' in parameter_table[ "Name" ].values
                if exists:
                    company_name = parameter_table[ parameter_table[ "Name" ] == "CN" ][ 'Value(s)' ].values[ 0 ]

                producer_name = 'NOT EXISTS'
                exists = 'LCNM' in parameter_table[ "Name" ].values
                if exists:
                    producer_name = parameter_table[ parameter_table[ "Name" ] == "LCNM" ][ 'Value(s)' ].values[ 0 ]

                set_name = 'NOT EXISTS'
                exists = 'SET' in parameter_table[ "Name" ].values
                if exists:
                    set_name = parameter_table[ parameter_table[ "Name" ] == "SET" ][ 'Value(s)' ].values[ 0 ]

                field_name = 'NOT EXISTS'
                exists = 'FN' in parameter_table[ "Name" ].values
                if exists:
                    field_name = parameter_table[ parameter_table[ "Name" ] == "FN" ][ 'Value(s)' ].values[ 0 ]

                # extract Casing data from header (Params and Zones)
                cs_table = parameter_table[ parameter_table[ 'Name' ].str.startswith("CS") ]
                cs_table[ 'Value(s)' ] = cs_table[ 'Value(s)' ].apply(lambda x: str(x).strip('[]'))
                cs_table[ 'Zone(s)' ] = cs_table[ 'Zone(s)' ].apply(lambda x: str(x).strip('Zone()'))

                cs_table = cs_table.merge(zone_table , left_on='Zone(s)' , right_on='Name')

                well_name = str(well_name).strip('[]')
                company_name = str(company_name).strip('[]')
                set_name = str(set_name).strip('[]')
                set_name = str(set_name).strip('\'\'')
                producer_name = str(producer_name).strip('[]')

                if not is_casing_plotted:
                    max_depth , min_depth , casing_df = reader.get_casing_plot_data(cs_table)

                    casing_plot_path = "{}\\{}_{}_{}".format(io_const.OUTPUT_DATA_DIR , well_name , company_name ,
                                                             io_const.CASING_PLOT_FILE_SUFFIX)
                    # casing_df = reader.prepare_casing_plot_data(casing18_min, casing18_max, casing13_min,
                    # casing13_max, casing9_min, casing9_max, casing7_min, casing7_max)
                    casing_fig = plot_cbl.plot_well_casing(casing_df.values , min_depth , max_depth , casing_plot_path)

                    is_casing_plotted = True
                # append casing fig to the list
                fig_list.append(casing_fig)

                channel_table = reader.summarize(lfile.channels , name='Name' , long_name='Long name' , units='Units' ,
                                                 dimension='Dimension' , frame='Frame')
                channel_table.sort_values('Name')

                tool_table = reader.summarize(lfile.tools , name='Name' , generic_name='Generic name' ,
                                              trademark_name='Trademark name', description='Description')
                tool_table.sort_values('Name')
                print(tool_table)

                print(list(io_const.HEADER_PARAM_LIST))
                header_info = parameter_table.loc[ parameter_table['Name'].isin(list(io_const.HEADER_PARAM_LIST)) ]. \
                    drop(columns='Zone(s)', axis=1)
                print(header_info)

                problematic_list = lfile.problematic

                if len(problematic_list) > 0:

                    print("Its Problematic files : {}".format(problematic_list))
                    prob_channel_list = [ x[ 0 ] for x in problematic_list ]

                    for dup_chn in prob_channel_list:
                        prob_channel_name = dup_chn.name
                        # print(prob_channel_name)

                        if prob_channel_name not in duplicate_channel_list:
                            duplicate_channel_list.append(prob_channel_name)

                origin , *origin_tail = lfile.origins

                if len(origin_tail):
                    logging.warning('Logical file contains multiple origins')

                for origin in lfile.origins:
                    origin.describe()

                    file_number = origin.file_nr
                    producer_name = origin.producer_name
                    well_name = origin.well_name
                    # copy_no = origin.copynumber
                    # org_no = origin.origin
                    field_name = origin.field_name
                    # namespace_name = origin.namespace_name

                for frm in lfile.frames:

                    file_name_pattern = "{}_{}_{}_{}_{}".format(field_name, well_name, producer_name, set_name, frm.name)
                    print(file_name_pattern)

                    index_channel = next(ch for ch in frm.channels if ch.name == frm.index)
                    print(f'Frame {frm.name}:')
                    print(frm.index)

                    try:
                        frm_curves = frm.curves(strict=False)
                        curve_index = reader.index_of(frm)

                        print(frm_curves.shape)
                    except Exception as e:
                        logging.error("ERROR in reading curve data.... : {}".format(e))

                    try:
                        selected_curves_names = reader.get_channel_names(frm, duplicate_channel_list)
                        print(selected_curves_names)

                        selected_curves_data = frm_curves[selected_curves_names]

                        # print("*********************************************************")
                        df_curves = pd.DataFrame(selected_curves_data, index=frm_curves[frm.index])
                        # print(df_curves.head())

                        min_depth = frm_curves[io_const.TDEP_COLUMN].min()
                        max_depth = frm_curves[io_const.TDEP_COLUMN].max()
                        depth_range = (min_depth, max_depth)  # df_curves.shape

                        cemo_wave_channel_names: list = reader.get_wave_channel_name(frm, duplicate_channel_list)
                        # print(cemo_wave_channel_names)

                        if len(cemo_wave_channel_names) > 1:

                            for channel_name in cemo_wave_channel_names:
                                print("Processing : {}".format(channel_name))

                                cs_wave_data = frm_curves[channel_name]

                                df_wave_data = pd.DataFrame(cs_wave_data, index=frm_curves[frm.index])
                                df_wave_data[io_const.TDEP_COLUMN] = df_wave_data.index
                                # df_wave_data.reset_index(drop=True)
                                df_wave_data.head()
                                # save wave data
                                cemo_wave_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, io_const.CEMO_DATA_CSV_SUFFIX)
                                print("Saving wave data to : {} ".format(cemo_wave_file_name))

                                with open(cemo_wave_file_name, "w") as f:
                                    if io_const.SAVE_DATA_TO_CSV:
                                        df_wave_data.to_csv(f)

                                print("{} Multi dimensional DataFrame Saved to CSV : {}".format(channel_name ,
                                                                                                cemo_wave_file_name))

                        else:

                            logging.warning("No Multi dimensional columns found in the frame/logical file")

                        df_full_data = df_curves.copy()

                        print("*********************************************************")
                        channel_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, io_const.CHANNEL_DATA_CSV_SUFFIX)

                        with open(channel_file_name, "w") as f:
                            if io_const.SAVE_DATA_TO_CSV:
                                df_full_data.to_csv(f)

                        print("DataFrame Saved to CSV : {}" + channel_file_name)

                        param_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, io_const.HEADER_CSV_SUFFIX)
                        with open(param_file_name, "w") as f:
                            parameter_table.to_csv(f)

                        zone_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, io_const.ZONE_DATA_CSV_SUFFIX)
                        with open(zone_file_name, "w") as f:
                            zone_table.to_csv(f)

                        # depth_range = (df_curves.index[0], df_curves.index[-1])
                        logical_file_info_dict = {'Field Name': field_name , 'Well Name': well_name ,
                                                  'Company': company_name , 'Producer Name': producer_name ,
                                                  'Set Name': set_name , 'Frame Name': frm.name ,
                                                  'Total Rows and Columns': depth_range , 'Depth Range': depth_range ,
                                                  'Column Names': list(df_curves.columns) + list(
                                                      cemo_wave_channel_names)}
                        print(logical_file_info_dict)

                        dlis_summary = dlis_summary.append(logical_file_info_dict , ignore_index=True)

                        summary_file_name = f"{io_const.OUTPUT_DATA_DIR}\\{field_name}_{well_name}_{producer_name}" \
                                            f"{io_const.SUMMARY_DATA_CSV_SUFFIX}"

                    except Exception as e:
                        # print("*********************************************************")
                        logging.error("Got Error with dlisio library.... : {}".format(e))

                    # Convert the index to metres if needed
                    if curve_index.units == '0.1 in':
                        frm_curves[ frm.index ] *= 0.00254

                    print("----------------1--------------------")
                    print('Shape of depth index curve array:' , frm_curves[ frm.index ].shape)

                    channel_names = lfile_channels  # reader.get_all_channel_names(frm, duplicate_channel_list)
                    print("channel_names" , channel_names)
                    try:
                        cemo_channel_name = io_const.CEMO_COLUMN
                        wave_channel_name = io_const.WAVE_COLUMN
                        ccl_challen_name = io_const.CCL_COLUMN
                        #ccb_challen_name = io_const.CCB_COLUMN
                        amav_challen_name = io_const.AMAV_COLUMN
                        atav_challen_name = io_const.ATAV_COLUMN
                        gr_challen_name = io_const.GR_COLUMN
                        dtmn_challen_name = io_const.DTMN_COLUMN
                        dtmx_challen_name = io_const.DTMX_COLUMN

                        if io_const.CCL_I_COLUMN in channel_names:
                            ccl_challen_name = io_const.CCL_I_COLUMN
                        if io_const.GR_I_COLUMN in channel_names:
                            gr_challen_name = io_const.GR_I_COLUMN
                        if io_const.AMAV_I_COLUMN in channel_names:
                            amav_challen_name = io_const.AMAV_I_COLUMN
                        if io_const.ATAV_I_COLUMN in channel_names:
                            atav_challen_name = io_const.ATAV_I_COLUMN
                        if io_const.DTMN_I_COLUMN in channel_names:
                            dtmn_challen_name = io_const.DTMN_I_COLUMN
                        if io_const.DTMX_I_COLUMN in channel_names:
                            dtmx_challen_name = io_const.DTMX_I_COLUMN

                        if io_const.CEMO_I_COLUMN in channel_names:
                            cemo_channel_name = io_const.CEMO_I_COLUMN

                        #print('Shape of CEMO curve array:       {}'.format(frm_curves[ cemo_channel_name ].shape))

                        if io_const.WAVE_I_COLUMN in channel_names:
                            wave_channel_name = io_const.WAVE_I_COLUMN

                        #print('Shape of WAVE curve array:        {}'.format(frm_curves[ wave_channel_name ].shape))

                        # Plot wave data with single column
                        cemo_plot_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range,  io_const.CEMO_PLOT_FILE_SUFFIX)
                        fig = plot_cbl.plot_single_cem_form(frm , frm_curves , cemo_channel_name , cemo_plot_file_name)
                        fig_list.append(fig)

                        # Plot wave data with single column
                        wave_plot_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, io_const.WAVE_PLOT_FILE_SUFFIX)
                        fig = plot_cbl.plot_single_wave_form(frm , frm_curves , wave_channel_name , wave_plot_file_name)
                        fig_list.append(fig)

                        # Plot ATC data with single column
                        atc_plot_file_name = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, io_const.ATC_PLOT_FILE_SUFFIX)
                        atc_channel_names = [ ]
                        try:
                            print("Validate ATC channels...")
                            for (atc_ch , atc_i_ch) in zip(io_const.ATC_COLUMN_LIST, io_const.ATC_I_COLUMN_LIST):
                                print(atc_ch , atc_i_ch)
                                if atc_ch in channel_names:
                                    atc_channel_names = io_const.ATC_COLUMN_LIST
                                    break
                                elif atc_i_ch in channel_names:
                                    atc_channel_names = io_const.ATC_I_COLUMN_LIST
                                    break

                            print(atc_channel_names)

                            if len(atc_channel_names) > 0:
                                print("Plot ATC channels")
                                fig = plot_cbl.plot_single_atc(frm, frm_curves, atc_channel_names,
                                                               atc_plot_file_name)
                                fig_list.append(fig)

                                # save all plots to pdf
                                merged_plot_pdf_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR, file_name_pattern,
                                                                           depth_range, io_const.ALL_PLOTS_FILE_SUFFIX)

                                # fig = plot_cbl.plot_combo_log(casing_df.values, frm, wave_channel_name,
                                #                               cemo_channel_name, atc_channel_names, min_depth,
                                #                               max_depth, merged_plot_pdf_path)
                                # fig_list.append(fig)
                                # predict the CCB
                                rf_model_file_path = os.path.join(io_const.MODELS_DIR, ml_const.TRAINED_RF_MODEL_JOBLIB)
                                classifier = None
                                try:
                                    classifier = joblib.load(rf_model_file_path)
                                    logging.debug(f"Existing model : {classifier}")
                                except Exception as e:
                                    logging.error(f"ERROR while loading the model....{e}")

                                if classifier is None:
                                    logging.debug(f"Training the RF model...")
                                    classifier = ml_helper.get_trained_rf_model(rf_model_file_path)

                                feature_names = atc_channel_names
                                print("------------------1-------------\n", feature_names)
                                df_atc = pd.DataFrame(frm_curves[[io_const.TDEP_COLUMN] + feature_names])
                                print("------------------2-------------\n", df_atc.head(2))
                                ccb_df = ml_helper.predict_cbl_cement_to_casinge(classifier,\
                                                                                df_atc[feature_names].values)
                                print("------------------3-------------\n", ccb_df.head(2))
                                # save all plots to pdf
                                ccb_plot_path = "{}\\{}_{}{}".format(io_const.OUTPUT_DATA_DIR,
                                                                            file_name_pattern,
                                                                            depth_range,
                                                                            io_const.CCB_PLOT_FILE_SUFFIX)
                                #print("------------------4-------------\n", ccb_plot_path)
                                print(f"Predicted df shape : {ccb_df.shape}")
                                ccb_ndarray = ccb_df[io_const.CCB_COLUMN].values.reshape(-1, 1)
                                #plot_cbl.plot_cement_quality(ccb_ndarray, min_depth, max_depth, ccb_plot_path)

                                # Grid plot
                                fig = plot_cbl.plot_combo_grid(casing_df.values, frm, ccb_ndarray, wave_channel_name,\
                                                               cemo_channel_name, atc_channel_names, ccl_challen_name,\
                                                               gr_challen_name, amav_challen_name, atav_challen_name,\
                                                               dtmn_challen_name, dtmx_challen_name, min_depth,\
                                                               max_depth, merged_plot_pdf_path)
                                fig_list.append(fig)
                            else:
                                logging.warning("ATC channels not found in the logical file.")

                        except Exception as e:
                            logging.error(f"ERROR while plotting the channel data....{e}")

                    except Exception as e:
                        logging.error(f"ERROR while plotting the WAVE data....{e}")

                    # with PdfPages(merged_plot_pdf_path) as pdf:
                    #
                    #     for fig in fig_list:
                    #         pdf.savefig(fig)
                    #
                    #     d = pdf.infodict()
                    #     d['Title'] = well_name
                    #     d['Author'] = 'Prabhaker Reddy Vanam'
                    #     d['Subject'] = 'Cement Bond Long Plots'
                    #     d['Keywords'] = 'BAKER, SBT, CEMO, WAVE, ATC'

            else:
                logging.warning("Required Channels are missing.")

            with open(summary_file_name, "w") as f:
                if io_const.SAVE_DATA_TO_CSV:
                    dlis_summary.to_csv(f)


print("Done!")

if __name__ == "__main__":
    main(str(sys.argv[1]))
