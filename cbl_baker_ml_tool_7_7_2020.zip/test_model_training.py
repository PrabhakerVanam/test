# -*- coding: utf-8 -*-
"""
Created on Mon Jul  6 22:06:40 2020

@author: ad1006362
"""

import pandas as pd
import numpy as np

from sklearn.metrics import confusion_matrix, classification_report
from sklearn.ensemble import RandomForestClassifier
from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const

from aon.dlis.io import plot_cement_bond_log as plot_cbl
from aon.dlis.model import cbl_model_helper as ml_helper

# load the dataset
#Cement Classification flag (1-Good, 2-Moderate, 3-Poor) - SQF
df_cbl = pd.read_csv('.\\data\\training\\cbl_training.csv')
#print(Welltest)
df_cbl.columns

rename_col_dict = {'TDEP, ft':'TDEP', 'AMAV.I, mV':'AMAV', 'ATAV.I, dB/ft':'ATAV',
       'ATC1.I, dB/ft':'ATC1', 'ATC2.I, dB/ft':'ATC2', 'ATC3.I, dB/ft':'ATC3', 'ATC4.I, dB/ft':'ATC4',
       'ATC5.I, dB/ft':'ATC5', 'ATC6.I, dB/ft':'ATC6', 'CCL.I, mV':'CCL', 'DTMN.I, us/ft':'DTMN',
       'DTMX.I, us/ft':'DTMX', 'Cement_flag (CBL)':'CCB'}
df_cbl.rename(columns=rename_col_dict, inplace=True)

df_cbl.columns
feature_names=io_const.ATC_COLUMN_LIST
target_label=['CCB']
df_cbl = df_cbl[df_cbl != -999.25]

df_cbl.dropna(inplace=True)

df_cbl.replace({-9999:0}, inplace=True)

print(df_cbl.head())

n_estimators = 350

conf_matrix , classify_report , accur_score, classifier = ml_helper.develop_model_cbl_cement_to_casing(df=df_cbl, feature_names =feature_names, target_label= target_label, n_estimators=n_estimators)


df_validate = pd.read_csv('.\\output\\BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_channel_data.csv')

rename_col_i_dict = {'TDEP':'TDEP', 'AMAV.I':'AMAV', 'ATAV.I':'ATAV',
       'ATC1.I':'ATC1', 'ATC2.I':'ATC2', 'ATC3.I':'ATC3', 'ATC4.I':'ATC4',
       'ATC5.I':'ATC5', 'ATC6.I':'ATC6', 'CCL.I':'CCL', 'DTMN.I':'DTMN',
       'DTMX.I':'DTMX'}
df_validate.rename(columns=rename_col_i_dict, inplace=True)

print(df_validate.columns)
df_fp = ml_helper.predict_cbl_cement_to_casinge(classifier,df_validate[feature_names].values)

print(df_fp['CCB'].values.reshape(-1, 1))
plot_cbl.plot_cement_quality(df_fp['CCB'].values.reshape(-1, 1), 126.0, 11463.0, '.\\output\\BAB_BB14591101H_ATLAS_00001_MAIN_PRESSURE_0_500000B0_(126.0, 11463.0)_CCB_plot.png')

print(df_fp.head())

