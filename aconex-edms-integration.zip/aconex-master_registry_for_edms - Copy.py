# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 19:09:52 2020

@author: DELL
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Jun 15 13:39:15 2020

 

@author: ad1006362
"""

import requests

import xml.etree.ElementTree as ET

import pandas as pd

import os

from pandas.io.json import json_normalize

import re 

import xmltodict, json
 
from pathlib import Path

import xml.dom.minidom
 
class DocumentRegister:
    
    def __init__(self, projectsurl, secreatkey, username, password):
        self.projectsurl = projectsurl
        self.headers = {'X-Application-Key': secreatkey}
        self.username = username
        self.password = password
        
    
    def loadDocumentRegister(self, projectId):
        
        # https://apidev.aconex.com/api/projects/{PROJECTID}/register?return_fields=trackingid
        #search_query=approved:[20200510%20TO%2020200619]   # [20200501 TO 20200630]
        #=search_query=((reviewstatus:940126422213604448 OR reviewstatus:940126422213604437) AND statusid:536871227) AND approved:[20200510%20TO%2020200619]
        
        doclist_url = "{}/{}/register?".format(self.projectsurl,projectId)
        doclist_url =  doclist_url + "search_query=((reviewstatus:940126422213604448 OR reviewstatus:940126422213604437) AND statusid:536871227)"
        doclist_url =  doclist_url + "&search_type=NUMBER_LIMITED&search_result_size=1500"
        doclist_url =  doclist_url + "&return_fields=AuthorisedBy,Category,Comments,Discipline,FileSize,FileType,Filename,ReviewStatus,statusid"
        doclist_url =  doclist_url + ",Revision,Title,SelectList1,SelectList10,SelectList2,SelectList3,selectList4,SelectList5"
        doclist_url =  doclist_url + ",SelectList8,SelectList9,attribute1,received,statusid,trackingid,doctype,revisiondate"
        doclist_url =  doclist_url + ",docno,vendorrev,forreview,approved,reviewed,current,scale,versionNumber"
        #doclist_url = doclist_url.format(self.projectsurl,projectId)
  
        return self.getResponse(doclist_url,self.headers, self.username, self.password)
    
    def downloadContentFile(self, projectId, documentId):
     
        # https://apidev.aconex.com/api/projects/{PROJECTID}/register/{DOCUMENTID}/markedup
        doccontent_url="{}/{}/register/{}/markedup"
        doccontent_url=doccontent_url.format(self.projectsurl,projectId,documentId)
        
        isDownloadable = False
        isDownloadable = self.is_downloadable(doccontent_url)
        print("is downloadeable URL ? " , isDownloadable)
        
        return self.getResponse(doccontent_url, self.headers, self.username, self.password)
    
    @staticmethod
    def getResponse(apiurl, headers, username, password):
    
        print(apiurl)
        with requests.Session() as session:
            
            session.auth = (username, password)        
            # Instead of requests.get(), you'll use session.get()
            response = session.get(apiurl, headers=headers, verify=False)
            response.encoding ='utf-8'
            
        return response
    
    @staticmethod
    def is_downloadable(url):
        """
        Does the url contain a downloadable resource
        """
        h = requests.head(url, allow_redirects=True)
        header = h.headers
        content_type = header.get('content-type')
        if 'text' in content_type.lower():
            return False
        if 'html' in content_type.lower():
            return False
        return True
    
    def formatxmlstring(self, uglyxml):
        
        xmlstr = xml.dom.minidom.parseString(uglyxml)
        xml_pretty_str = xmlstr.toprettyxml()
        
        return xml_pretty_str
    
#def main():
    
# =============================================================================
#     print("Aconex Development Site!")
#     projectsurl = 'https://apidev.aconex.com/api/projects/'
#     secretekey = '0c3d68fa-4348-4eee-8a1b-eff1c7b2f030'
#     username = 'poleary'
#     password='Auth3nt1c'
# =============================================================================
    
print("Aconex- ADNOC Onshore Site!")
projectsurl = 'https://mea.aconex.com/api/projects/'
secretekey = '0331002e-a23a-46e9-b06c-26a4bdce9be1'
username = 'dmadmin'
password='Document001'


mstrProjectid=1744831808
 
apiclient = DocumentRegister(projectsurl, secretekey, username, password)
 
response = apiclient.loadDocumentRegister(mstrProjectid)
 

#response2=response2.encode('utf8')
xmlcontent = response.text.encode('utf8')
print(xmlcontent)
elevations = xmltodict.parse(xmlcontent)
print(elevations.keys())

TotalResults = elevations['RegisterSearch']['@TotalResults']
Documents = elevations['RegisterSearch']['SearchResults']['Document']
print(Documents)

values=[]
for i in range(len(Documents)):
    values.append(Documents[i])

dfx = pd.DataFrame(values)

norm_dfx= json_normalize(dfx.Attribute1)

dfx1 = dfx.merge(norm_dfx, left_index=True, right_index=True)

dfx1.fillna('',inplace=True)

column_names_dict = {'@DocumentId': 'DocumentId',
        'AttributeTypeNames.AttributeTypeName': 'Project Code',
        'AuthorisedBy': 'MOC Number',
        'Category': 'Area',
        'Comments': 'Project_Source_Doc_number',
        'DateModified': 'Date Modified',
        'Discipline': 'Discipline',
        'DocumentNumber': 'Document No',
        'DocumentStatus': 'Status',
        'DocumentType': 'Type',
        'Filename': 'File Name',
        'FileSize': 'Size',
        'FileType': 'File',
        'ReviewStatus': 'Review Status',
        'Revision': 'Revision',
        'RevisionDate': 'Revision Date',
        'Scale': 'Scale',
        'SelectList1': 'Priority',
        'SelectList10': 'Creator',
        'SelectList2': 'Plant Area',
        'SelectList3': 'Document Classification Code',
        'SelectList4': 'Drawing Size',
        'SelectList5': 'Action Type Code',
        'SelectList8': 'Task Order',
        'SelectList9': 'Contract Number',
        'Title': 'Subject',
        'VersionNumber':'Version'
        }

dfx1.rename(columns=column_names_dict, inplace = True)

dfx1['DocumentId'] = dfx1['DocumentId'].astype('str')

dfx1['local_file_path'] = "D:/Temp/" + dfx1['DocumentId'] + "." + dfx1['File']

dfx1.drop(['Attribute1','AttributeType'], axis = 1, inplace=True)

# Filter drawings only
dfx_drawings =  dfx1[dfx1['Type']=='Drawing']
dfx_drawings =  dfx_drawings[ dfx_drawings['Review Status']=='Approved']

file_name= ".\\output\\df_aconex_drawings_final.xlsx"
#with open(file_name, "wb") as f:
#    dfx_drawings.to_excel(f, sheet_name='Aconex Data', index = False)

# create excel writer object
writer = pd.ExcelWriter(file_name)
# write dataframe to excel
dfx_drawings.to_excel(writer, sheet_name='Aconex Data', index = False)
# save the excel
writer.save()

dfx_drawings.to_excel(".\\input\\Aconex - metadata.xls", sheet_name='Aconex Data', index = False)

for doc_id, file_path in dfx_drawings[['DocumentId','local_file_path']].itertuples(index=False):
    print("Processiong Tracking : " + doc_id, file_path)     
    response = apiclient.downloadContentFile(mstrProjectid, doc_id)
    #response5=response5.encode('utf8')
    print("Response file content type" , response.headers.get('content-type'))
  
    filename = Path(file_path)
    file = open(filename, 'wb').write(response.content)
    
    print("Content file saved as : ", filename)
   

    #file.close()
#    
#if __name__ == '__main__':
#    main()