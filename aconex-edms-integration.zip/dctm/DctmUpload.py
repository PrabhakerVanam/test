# -*- coding: utf-8 -*-
"""
Created on Wed Mar 11 14:24:34 2020

@author: ad1006362
"""

#import collections
import inspect
import logging
import logging.config
import sys
import time
#from builtins import input
from configparser import ConfigParser

#from model import RestLink
#from model.QueryDocument import Sort, ExpSet, FtExp, FacetDefinition
from network import RestClient
#from network.RestClient import MEDIA_TYPE_DM_JSON
from util import ResourceUtility
#from util.DemoUtil import format_json
#from util.DemoUtil import print_properties
from util.DemoUtil import print_resource_properties

__author__ = 'Prabhaker Vanam'

ENG_CABINET_NAME = 'Engineering & Projects (EP)'
ACN_FOLDER_NAME='Aconex1'
ENG_FOLDER_TYPE = 'ad_eng-folder'
ENG_TECH_DOC_TYPE='ad_eng_technical_doc'

NEW_DOCUMENT_NAME='NEW REST DOCUMENT'

logger = logging.getLogger(__name__)

class UploadDocument:    
    
    def __init__(self):       
        
        self._init_client()
        
        self._init_logger()

    @staticmethod
    def _get_method_version(demo):
        return inspect.getdoc(demo).split('\n')[1].split(':')[1].strip()

    @staticmethod
    def _get_method_doc(demo):
        return inspect.getdoc(demo).split('\n')[0]
    
    def _init_client(self):
        config_parser = ConfigParser()
        config_parser.read("resources/rest.properties")
    
        self.REST_URI = config_parser.get("environment", "rest.host")        
    
        self.REST_REPOSITORY = config_parser.get("environment", "rest.repository")        
    
        self.REST_USER = config_parser.get("environment", "rest.username")       
    
        self.REST_PWD = config_parser.get("environment", "rest.password")
        
        self.REST_LOGGER_DEBUG=config_parser.get("environment", "rest.logger.debug")
    
        self.client = RestClient.RestClient(self.REST_USER, self.REST_PWD, self.REST_URI, self.REST_REPOSITORY)
        
    
    def _init_logger(self):
        logging.getLogger("requests").setLevel(logging.WARNING)

        is_debug = self.REST_LOGGER_DEBUG
        if is_debug == 'yes':
            level = 'DEBUG'
        else:
            level = 'INFO'
        logging.config.dictConfig({
            'version': 1,
            'disable_existing_loggers': False,

            'handlers': {
                'default': {
                    'level': level,
                    'class': 'logging.StreamHandler',
                },
            },
            'loggers': {
                '': {
                    'handlers': ['default'],
                    'level': 'DEBUG',
                    'propagate': True
                }
            }
        })

    @staticmethod
    def quit():
        """Quit the Tool  
        version: 7.2
        """

        logger.info("\nQuit the Tool.")
        sys.exit(0)
        
    def content_upload(self, content_file_path):
        """REST content upload
        version: 7.2
        """
        logger.info("\n+++++++++++++++++++++++++++++++Content File Upload Start+++++++++++++++++++++++++++++++")

        logger.info('Get cabinet %s...' % ENG_CABINET_NAME)
        eng_cabinet = self.client.get_cabinet(ENG_CABINET_NAME)
        logger.info("\n eng_cabinet : ", eng_cabinet)

        query1 = 'select * from dm_folder where FOLDER(\'/{}\') and object_name=\'{}\''.format(ENG_CABINET_NAME,ACN_FOLDER_NAME)
        logger.info('Query \'{}\' '.format(query1))
        results = self.client.dql(query1, {'items-per-page': '1', 'page': '1'})
        logger.info("\n query executed...")
        logger.info(results)
        
        
        if results is None:
           logger.info('Create temp folder %s in cabinet %s...' % (ACN_FOLDER_NAME, ENG_CABINET_NAME))
           aconex_folder = self.client.create_folder(eng_cabinet, ResourceUtility.generate_folder(object_name=ACN_FOLDER_NAME))
           logger.info("\n aconex_folder : ", aconex_folder)
           
           query1 = 'select * from dm_folder where FOLDER(\'/{}\') and object_name=\'{}\''.format(ENG_CABINET_NAME,ACN_FOLDER_NAME)
           self.run_dql(query1)
           logger.info("\n query executed...")
        
        else:
            
            logger.info('Get Folder %s...' % ACN_FOLDER_NAME)
            aconex_folder = self.client.get_folder_by_name(eng_cabinet, ACN_FOLDER_NAME)
            logger.info("\n aconex_folder : ", aconex_folder)


        logger.info('Create new document %s with content...' % ENG_TECH_DOC_TYPE)
        new_doc = self.client.create_document(aconex_folder,
                                              ResourceUtility.generate_eng_document(object_name=NEW_DOCUMENT_NAME),
                                              'It\'s created by python client', params={'format': 'crtext'})
        print_resource_properties(logger, new_doc, 'object_name', 'r_object_id')

        logger.info('Get primary content of %s...' % NEW_DOCUMENT_NAME)
        primary_content = self.client.get_primary_content(new_doc, params={'media-url-policy': 'all'})
        print_resource_properties(logger, primary_content, 'object_name', 'r_object_id', 'format_name',
                                  'full_content_size')

        logger.info('All media URLs for primary content of %s...' % NEW_DOCUMENT_NAME)
        for link in primary_content.all_links():
            logger.info(str(link) + '\n')

# =============================================================================
#         logger.info('Create new html rendition for document %s...' % NEW_DOCUMENT_NAME)
#         new_content = self.client.create_content(new_doc, content='This is html rendition.', content_type='text/html',
#                                                  params={'primary': 'false'})
#         print_resource_properties(logger, new_content, 'object_name', 'r_object_id', 'format_name', 'full_content_size')
# =============================================================================

        logger.info('Create new rendition with large file for document %s...' % NEW_DOCUMENT_NAME)
        path = content_file_path
        if path:
            
            logger.info('Start to create document with file %s', path)
            try:
                with open(path, 'rb') as f:
                    new_content = self.client.create_content(new_doc, content=f,
                                                             content_type=RestClient.MEDIA_TYPE_OCTET_STREAM,
                                                             params={'primary': 'false'})
                    print_resource_properties(logger, new_content, 'object_name', 'r_object_id', 'format_name',
                                              'full_content_size')
            except IOError:
                
                logger.info('The file %s does not exist or can not be opened.' % path)
        else:
            
            logger.info('Skip create new rendition with large file for document %s...' % NEW_DOCUMENT_NAME)

        logger.info('Get contents for document %s...' % NEW_DOCUMENT_NAME)
        contents = self.client.get_contents(new_doc)

        logger.info('All renditions for document %s...' % NEW_DOCUMENT_NAME)
        for rendition in contents.get_entries():
            logger.info(str(rendition.get('content')) + '\n')

        #logger.info('Delete document %s' % NEW_DOCUMENT_NAME)
        #self.client.delete(new_doc)

      
        logger.info("+++++++++++++++++++++++++++++++Content File Upload End+++++++++++++++++++++++++++++++")
        
        
    def run_dql(self, dql):
        """
        REST DQL
        version: 7.2
        """
        logger.info("\n+++++++++++++++++++++++++++++++DQL Start+++++++++++++++++++++++++++++++")

        logger.info('Query \'{}\' with items-per-page=1,page=1...'.format(dql))
        results = self.client.dql(dql, {'items-per-page': '1', 'page': '1'})
        logger.info(results)

        logger.info('Object names in page %d...', 1)
        for result in results.get_entries():
            logger.info(result.get('content').get('properties').get('object_name'))
        logger.info('')

        logger.info('Navigate to next page...')
        results = self.client.next_page(results)

        if results is None:
            logger.info('Next page does not exist.')
        else:
            logger.info('Object names in page %d...', 1)
            for result in results.get_entries():
                logger.info(result.get('content').get('properties').get('user_name'))

        logger.info("+++++++++++++++++++++++++++++++DQL End+++++++++++++++++++++++++++++++")
        
    def run(self):

        try:
            content_file_path = "D:\\Temp\\UsersManual_CCR_Rel_1-0_Draft_02.pdf"
            print("content_file_path: '{}'".format(content_file_path))
            self.content_upload(content_file_path)
            
        except ValueError:
            print("\n#Enter number of the demo items instead of other characters.#\n")
        except Exception as e:
            logger.exception(e)
            time.sleep(1)
            print("\n#Error is detected during demo. Please refer the log for the exception detail.#\n")

        


def main():
    UploadDocument().run()


if __name__ == '__main__':
    main()
else:
    logger.info('UploadDocument as a module')