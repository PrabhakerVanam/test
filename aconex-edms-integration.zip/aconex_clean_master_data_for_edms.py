# -*- coding: utf-8 -*-
"""
Created on Wed Jun 10 09:31:21 2020

 


@author: AD1006362
"""

import sys, getopt

import pandas as pd
 
def main(argv):
        
    inputfile = ''
    outputfile = ''
    
    try:
        opts, args = getopt.getopt(argv,"hi:o:",["ifile=","ofile="])
    except getopt.GetoptError:
        print('aconex-clean-master-data-for-edms.py -i <inputfile> -o <outputfile>')
        sys.exit(2)
    
    for opt, arg in opts:
      if opt == '-h':
         print('aconex-clean-master-data-for-edms.py -i <inputfile> -o <outputfile>')
         sys.exit()
      elif opt in ("-i", "--ifile"):
         inputfile = arg
      elif opt in ("-o", "--ofile"):
         outputfile = arg
    print('Input file is "', inputfile,'"')
    print('Output file is "', outputfile,'"')
    
    if len(inputfile)  <= 3:
        source_file = ".\\input\\Aconex - metadata.xls"
    else:
        source_file = inputfile
        
    if len(outputfile) <=3 :
        target_file = ".\\output\\df_edms_drawings_final.xlsx"
    else:
        target_file = outputfile
        
    execute(source_file, target_file)


def execute(source_file, target_file):

    aconex_data_skip_rows=0
    
    area_codes_src =".\\input\\Area Codes.xlsx"
    plant_area_codes_src=".\\input\\Plant Area Codes.xlsx"
    doc_classification_codes_src=".\\input\\Document Classification Codes.xlsx"
    
    df_area_codes = pd.read_excel(area_codes_src) 
    df_area_codes.columns
    
    df_plant_area_codes = pd.read_excel(plant_area_codes_src) 
    df_plant_area_codes.columns
    
    df_doc_classification_codes = pd.read_excel(doc_classification_codes_src) 
    df_doc_classification_codes.columns
    
    # Make code id as string colum with prefix with 0 for single digits 
    df_area_codes['code_id'] = df_area_codes['code_id'].astype('str').apply(lambda x: x.zfill(2))
    df_plant_area_codes['code_id'] = df_plant_area_codes['code_id'].astype('str').apply(lambda x: x.zfill(2))
    df_doc_classification_codes['code_id'] = df_doc_classification_codes['code_id'].astype('str').apply(lambda x: x.zfill(2))
    
    
    
    # convert it into data dictionary
    area_dictionary = dict(df_area_codes[['code_id', 'code_label']].values) 
    
    plant_area_dictionary = dict(df_plant_area_codes[['code_id', 'code_label']].values)
    
    doc_classification_dictionary = dict(df_doc_classification_codes[['code_id', 'code_label']].values)
    
    
    #dateparse = lambda x: pd.datetime.strptime(x, '%Y-%m-%d %H:%M:%S')
    
    df_aconex = pd.read_excel(source_file, skiprows=aconex_data_skip_rows) #, parse_dates=True, date_parser=dateparse)
    df_aconex.columns
    
    df_aconex['File'] = df_aconex['File'].str.lower()
    
    unique_formats = df_aconex['File'].unique()
    
    #temp = df_aconex[['File', 'Document No']]
    #temp['Document No'] = temp['Document No'].replace("-" +temp['File'], "")
    
    
    #temp['Document No'] = temp['Document No'].apply(lambda x: re.sub(temp.loc[temp['Document No'] == x, 'File'].values[0], '', x))
    #temp['Document No'].str.endswith("-")
    
    format_list = list(unique_formats)
    df_aconex['Document No'] = df_aconex['Document No'].str.replace('.', '-')
    df_aconex['Document No'] = df_aconex['Document No'].str.replace('_', '-')
    
    
    for file_type in format_list:
        name_ends_with = "-"+file_type
      
        df_aconex['Document No'] = df_aconex['Document No'].str.replace(name_ends_with, '')
    
    # Filter Drawing type only
    df_aconex_drawing = df_aconex[df_aconex['Type'] == 'Drawing']
    
    # Make MOC as integer value
    df_aconex_drawing['MOC Number'].fillna(0, inplace=True)
    df_aconex_drawing['MOC Number'] = df_aconex_drawing['MOC Number'].astype('int32')
    
    
    # remove all NANs
    df_aconex_drawing.fillna("", inplace=True)
    
    # Parse data fromat
    
    df_aconex_drawing['Revision Date'] = df_aconex_drawing['Revision Date'].dt.strftime('%m/%d/%Y %H:%M:%S')
    df_aconex_drawing['Date Modified'] = df_aconex_drawing['Date Modified'].dt.strftime('%m/%d/%Y %H:%M:%S')
    
    # Join the columns to make correct source document number
    df_aconex_drawing['Project_Source_Doc_number'] = df_aconex_drawing['Project Code'] + "-" + df_aconex_drawing['Project_Source_Doc_number']
    
    # Clean the data 
    df_aconex_drawing['Project_Source_Doc_number'] = df_aconex_drawing['Project_Source_Doc_number'].replace(",", "") 
    
    df_aconex_drawing['Area'] = df_aconex_drawing['Area'].str[:2]
    df_aconex_drawing['Plant Area'] = df_aconex_drawing['Plant Area'].str[:2]
    df_aconex_drawing['Document Classification Code'] = df_aconex_drawing['Document Classification Code'].str[:2]
    df_aconex_drawing['Discipline'] = df_aconex_drawing['Discipline'].str.split(' ',expand=True)[0]
    
    
    # Prepare the list for EDMS upload
    df_edms_drawings = df_aconex_drawing.copy()
    
    
    # Extract Serial Number and Sheet number
    df_edms_drawings['serial_no'] = df_edms_drawings['Document No'].str.split('-',expand=True)[4]
    df_edms_drawings['sheet_no'] = df_edms_drawings['Document No'].str.split('-',expand=True)[5]
    # Currently considering total sheet number is same as sheet number
    df_edms_drawings['total_no_of_sheets'] = df_edms_drawings['sheet_no'] 
    
    
    # merge some values into keywords
    df_edms_drawings['keywords'] = df_edms_drawings['MOC Number'].astype('str') + "\n" + df_edms_drawings['Action Type Code'] + "\n" +df_aconex_drawing['Version'].astype('str') + "\n" +  df_edms_drawings['Project Code'] 
    
    
    # Rename Aconex colums to EDMS column names
    colum_rename_dict = { 'DocumentId': 'aconex_document_id',
                         'TrackingId': 'aconex_tracking_Id',
                         'Document No': 'doc_no',
                         'Revision': 'doc_revision',
                         'Subject': 'subject',
                         'Type': 'doc_category',
                         'Status': 'review_type',
                         'Review Status': 'trn_final_status',
                         'Revision Date': 'received_date',
                         'Date Modified': 'trn_responded_date',
                         'Creator': 'contractor',
                         'Area': 'area_code',
                         'Plant Area': 'plant_area_code',
                         'Document Classification Code': 'doc_classification_code',
                         'File Name':'original_filename',
                         'Task Order':'contract_no',
                         'Contract Number':'project_no',
                         'Project_Source_Doc_number':'contractor_doc_no',
                         'Discipline':'title',
                         'File':'a_content_type',
                         'Version':'resolution_label',
                         'local_file_path':'local_file_path'
                         }
    
    
    df_edms_drawings.rename(columns=colum_rename_dict, inplace=True)
    df_edms_drawings.columns
    
    # Prefix 0 for single digit values
    df_edms_drawings['doc_revision'] = df_edms_drawings['doc_revision'].astype('str').apply(lambda x: x.zfill(2))
     
    format_dict = {'dwg':'acad','gp4':'cals1','xls':'excel','doc':'msw','docx':'msw12','xlsx':'excel12book','pdf':'pdf','dgn':'ustn'}
    df_edms_drawings['a_content_type'] = df_edms_drawings['a_content_type'].map(format_dict)
    
    # Add input channel value to identify the documetns from Aconex
    df_edms_drawings['input_channel'] = 99
    
    # create area, plant area ,document classification names columen
    df_edms_drawings['area_name'] = df_edms_drawings['area_code'].map(area_dictionary)
    df_edms_drawings['plant_area_name']  = df_edms_drawings['plant_area_code'].map(plant_area_dictionary)
    df_edms_drawings['doc_classification_name']  = df_edms_drawings['doc_classification_code'].map(doc_classification_dictionary)
    
    # flag hybrid document for ACAD content type
    df_hybrid = df_edms_drawings.copy()
    
    df_hybrid['is_hybrid_drawing'] = False
    
    # Sort dataframe with docnumber and content type
    df_hybrid.sort_values(by=['doc_no', 'a_content_type'], inplace=True)
    
    df_hybrid['doc_no_revision'] = df_hybrid['doc_no'] + '-' + df_hybrid['doc_revision'] 
    
    df_hybrid_key = df_hybrid[['doc_no_revision','is_hybrid_drawing']]
    hybrid_drawings = df_hybrid_key[df_hybrid_key['doc_no_revision'].duplicated(keep='last')]
    hybrid_drawings['is_hybrid_drawing'] = True
    #print(hybrid_drawings)
    hybrdi_drawings_index_list = hybrid_drawings.index
    
    for idx in hybrdi_drawings_index_list:
        df_hybrid.loc[idx, 'is_hybrid_drawing'] = True
     
    # validate the document number (Task ORder and Sheet number)
    df_doc_validae = df_hybrid[['doc_no','contract_no']]
    df_hybrid['doc_no'] = df_doc_validae['doc_no'].astype('str')
    df_hybrid[['to','ar','pa','dc','srn','shn']] = df_hybrid['doc_no'].str.split('-', expand=True)    
    df_hybrid['doc_no_valid?'] = df_hybrid.apply(lambda x: not str(x.shn).startswith('0') and str(x.to).startswith(str(x.contract_no)) , axis=1)
    
    selected_columns = ['doc_no_valid?', 'doc_no', 'doc_revision', 'a_content_type', 'is_hybrid_drawing', 'title', 'subject',
           'doc_category', 'review_type', 'trn_final_status', 
           'received_date', 'trn_responded_date', 'contractor', 
           'area_code', 'area_name', 'original_filename', 'plant_area_code', 'plant_area_name',
           'doc_classification_code', 'doc_classification_name', 'contract_no', 'project_no',
           'contractor_doc_no', 'serial_no', 'sheet_no', 'total_no_of_sheets', 
           'keywords','resolution_label', 'input_channel', 'aconex_document_id', 'aconex_tracking_Id', 'local_file_path']
    
    
    df_edms_drawings_final = df_hybrid[selected_columns]
     
    # save the final dataframe in to xls file 
    #file_name= ".\\output\\df_edms_drawings_final.xlsx"
    file_name = target_file
    # create excel writer object
    writer = pd.ExcelWriter(file_name)
    # write dataframe to excel
    df_edms_drawings_final.to_excel(writer, sheet_name='EDMS Data', index = False)
    # save the excel
    writer.save()
    


if __name__ == '__main__':
    
    print('Number of arguments:', len(sys.argv), 'arguments.')
    print('Argument List:', str(sys.argv))
    main(sys.argv[1:])
 