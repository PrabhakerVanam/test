
# -*- coding: utf-8 -*-
"""
Created on Mon Jun 15 13:39:15 2020

 

@author: ad1006362
"""

import requests

import xml.etree.ElementTree as ET

import pandas as pd

import numpy as np

from datetime import datetime

import os, ssl

import sys

from pandas.io.json import json_normalize

import re 

import xmltodict, json
 
from pathlib import Path

import xml.dom.minidom

import aconex_clean_master_data_for_edms as clean_to_edms

import configparser

import urllib

urllib.getproxies = lambda x = None: {}

#2020-06-16T20:00:00.000Z
date_format = "%Y-%m-%dT%H:%M:%S.%fZ" 

def main(properties_file = 'aconex_master_tool_prop.properties'):
    '''
    Main method executed by the tool
    '''
    print(properties_file)
    
    prop_keys, prop_values = get_properties(properties_file) # read contacts
    
    properties_dict={}
    for key, value in zip(prop_keys, prop_values):
        properties_dict[key] =value
        
    execute(properties_dict)
    
def get_properties(filename):
    """
    Return two lists keys, values containing property name and value
    read from a file specified by filename.
    """
    config = configparser.RawConfigParser()
    config.read(filename)
    section='AconexSection'
    option_list = config.options(section)
    
    key_list = []
    value_list = []
    
    for prop in option_list:
        print(prop)
        key_list.append(prop)
        value_list.append(config.get(section,prop))
        
    return key_list, value_list 

    

def execute(properties):
    """
    Method executes REST calls, extracts metadata and content files from Aconex Cloud services
    
    param: parameters - contains the list of properties info to execute the service
    
    """
    
    print(properties)
    print("Aconex- ADNOC Onshore Site!")
#    projectsurl = 'https://mea.aconex.com/api/projects/'
#    secretekey = '0331002e-a23a-46e9-b06c-26a4bdce9be1'
#    username = 'dmadmin'
#    password='Document001'
    projectsurl = properties['aconex_projects_url']
    secretekey = properties['aon_secrete_key']
    username = properties['username']
    password = properties['password']
    
    #mstrProjectid=1744831808    
    apiclient = DocumentRegister(projectsurl, secretekey, username, password)
     
    response = apiclient.loadDocumentRegister(properties)
     
    
    #response2=response2.encode('utf8')
    xmlcontent = response.text.encode(properties['response_encoding'])
    print(xmlcontent)
    elevations = xmltodict.parse(xmlcontent)
    print(elevations.keys())
    
    totalResults = elevations['RegisterSearch']['@TotalResults']
    print(totalResults)
    documents = elevations['RegisterSearch']['SearchResults']['Document']
    print(documents)
    
    values=[]
    for i in range(len(documents)):
        values.append(documents[i])
    
    dfx = pd.DataFrame(values)
    
    norm_dfx= json_normalize(dfx.Attribute1)
    
    df_aconex = dfx.merge(norm_dfx, left_index=True, right_index=True)
    
    df_aconex.fillna('',inplace=True)
    
    column_names_dict = {'@DocumentId': 'DocumentId',
            'AttributeTypeNames.AttributeTypeName': 'Project Code',
            'AuthorisedBy': 'MOC Number',
            'Category': 'Area',
            'Comments': 'Project_Source_Doc_number',        
            'Discipline': 'Discipline',
            'DocumentNumber': 'Document No',
            'DocumentStatus': 'Status',
            'DocumentType': 'Type',
            'Filename': 'File Name',
            'FileSize': 'Size',
            'FileType': 'File',
            'ReviewStatus': 'Review Status',
            'Revision': 'Revision',        
            'Scale': 'Scale',
            'SelectList1': 'Priority',
            'SelectList10': 'Creator',
            'SelectList2': 'Plant Area',
            'SelectList3': 'Document Classification Code',
            'SelectList4': 'Drawing Size',
            'SelectList5': 'Action Type Code',
            'SelectList8': 'Task Order',
            'SelectList9': 'Contract Number',
            'Title': 'Subject',
            'DateApproved': 'Date Approved',
            'DateCreated': 'Date Created',
            'DateForReview': 'Date For Review',
            'DateReviewed': 'Date Reviewed',
            'RevisionDate': 'Revision Date',
            'DateModified': 'Date Modified',
            'VersionNumber':'Version'
            }
    
    df_aconex.rename(columns=column_names_dict, inplace = True)
    
    df_aconex['DocumentId'] = df_aconex['DocumentId'].astype('str')
    
    content_download_folder = properties['edms_upload_content_folder']
    
    df_aconex['local_file_path'] = content_download_folder + df_aconex['DocumentId'] + "." + df_aconex['File']
    
    df_aconex.drop(['Attribute1','AttributeType'], axis = 1, inplace=True)
    
    '''['DocumentId', 'DateApproved', 'MOC Number', 'Area',
           'Project_Source_Doc_number', 'Current', 'DateCreated', 'DateForReview',
           'DateReviewed', 'Discipline', 'Document No', 'Status', 'Type', 'Size',
           'File', 'File Name', 'Review Status', 'Revision', 'Revision Date',
           'Scale', 'Priority', 'Creator', 'Plant Area',
           'Document Classification Code', 'Drawing Size', 'Action Type Code',
           'Task Order', 'Contract Number', 'Subject', 'TrackingId', 'Version',
           'Project Code', 'local_file_path']
    '''
    print(df_aconex.columns)
    
    #df_aconex['Date Approved'] = df_aconex['Date Approved'].apply(lambda x: datetime.strptime(x, date_format))
    #df_aconex['Revision Date'] = df_aconex['Revision Date'].apply(lambda x: datetime.strptime(x, date_format))
    #df_aconex['Date Reviewed'] = df_aconex['Date Reviewed'].apply(lambda x: datetime.strptime(x, date_format))
    #df_aconex['Date Created'] = df_aconex['Date Created'].apply(lambda x: datetime.strptime(x, date_format))
    
    #df_aconex['Date Created'] = df_aconex['Date Created'].apply(lambda x: datetime.strptime(x, date_format))
    
    # format the date columns in dataframe
    date_cols = []
    for col_name, data_type in zip(df_aconex.columns, df_aconex.dtypes):
        if 'Date' in col_name and data_type==object:
            date_cols.append(col_name)
    
    print("Date Columns : ", date_cols)
    for col in date_cols:
        #print(col)
        df_aconex[col]= df_aconex[col].apply(lambda x: datetime.strptime(x, date_format))
        #print(df_aconex[col])
    
    
    # Filter drawings only
    dfx_drawings =  df_aconex[df_aconex['Type']=='Drawing']
    mask = np.logical_or(dfx_drawings['Review Status']=='Approved' , dfx_drawings['Review Status']=='Approved with Comments')
    #dfx_drawings =  dfx_drawings[ dfx_drawings['Review Status']=='Approved']
    dfx_drawings =  dfx_drawings[mask]
    
    # convert Document id , tracking id to string - Prefix with some char to handle format in Excel file
    #df['col'] = df['col'].apply(lambda x: f"str{x}")
    dfx_drawings['TrackingId'] = dfx_drawings['TrackingId'].apply(lambda x: f"T{x}")
    dfx_drawings['DocumentId'] = dfx_drawings['DocumentId'].apply(lambda x: f"D{x}")
            
    #file_name= ".\\output\\df_aconex_drawings_final.xlsx"
    out_file_name = properties['out_excel_file_path']
    #with open(file_name, "wb") as f:
    #    dfx_drawings.to_excel(f, sheet_name='Aconex Data', index = False)
    
    # create excel writer object
    writer = pd.ExcelWriter(out_file_name)
    # write dataframe to excel
    dfx_drawings.to_excel(writer, sheet_name='Aconex Data', index = False)
    # save the excel
    writer.save()
    
    #clean_target_file = ".\\output\\df_edms_drawings_ready_for_upload.xlsx"
    clean_target_file = properties['edms_upload_excel_file_path']
    # Prepare Data for EDMS upload
    clean_to_edms.execute(out_file_name, clean_target_file)
    
    #dfx_drawings.to_excel(".\\input\\Aconex - metadata.xls", sheet_name='Aconex Data', index = False)
    
    for doc_id, file_path in dfx_drawings[['DocumentId','local_file_path']].itertuples(index=False):
        print("Processiong Tracking : " + doc_id, file_path)     
        response = apiclient.downloadContentFile(properties['project_id'], doc_id)
        #response5=response5.encode('utf8')
        print("Response file content type" , response.headers.get('content-type'))
      
        filename = Path(file_path)
        open(filename, 'wb').write(response.content)
        
        print("Content file saved as : ", filename)
        


 
class DocumentRegister:
    
    def __init__(self, projectsurl, secreatkey, username, password):
        self.projectsurl = projectsurl
        self.headers = {'X-Application-Key': secreatkey}
        self.username = username
        self.password = password
    
    '''
    Method which retrives records from document register,
    it takes project id and query arguments from the properties params
    '''
    def loadDocumentRegister(self, properties={}):
              
        doclist_url = "{}/{}/register?".format(self.projectsurl,properties['project_id'])
        doclist_url =  doclist_url + properties['master_search_query']
        doclist_url =  doclist_url + "&" + properties['master_search_type']
        doclist_url =  doclist_url + "&" + properties['master_return_fields']
        
        return self.getResponse(doclist_url,self.headers, self.username, self.password)
    
#    def loadDocumentRegister(self, projectId):
#        
#        # https://apidev.aconex.com/api/projects/{PROJECTID}/register?return_fields=trackingid
#        #search_query=approved:[20200510%20TO%2020200619]   # [20200501 TO 20200630]
#        #=search_query=((reviewstatus:940126422213604448 OR reviewstatus:940126422213604437) AND statusid:536871227) AND approved:[20200510%20TO%2020200619]
#        
#        doclist_url = "{}/{}/register?".format(self.projectsurl,projectId)
#        doclist_url =  doclist_url + "search_query=((reviewstatus:940126422213604448 OR reviewstatus:940126422213604437) AND statusid:536871227)"
#        doclist_url =  doclist_url + "&search_type=NUMBER_LIMITED&search_result_size=1500"
#        doclist_url =  doclist_url + "&return_fields=AuthorisedBy,Category,Comments,Discipline,FileSize,FileType,Filename,ReviewStatus,statusid"
#        doclist_url =  doclist_url + ",Revision,Title,SelectList1,SelectList10,SelectList2,SelectList3,selectList4,SelectList5"
#        doclist_url =  doclist_url + ",SelectList8,SelectList9,attribute1,received,statusid,trackingid,doctype,revisiondate"
#        doclist_url =  doclist_url + ",docno,vendorrev,approved,reviewed,current,scale,versionNumber"
#        
#  
#        return self.getResponse(doclist_url,self.headers, self.username, self.password)
    
    def downloadContentFile(self, projectId, documentId):
     
        # https://apidev.aconex.com/api/projects/{PROJECTID}/register/{DOCUMENTID}/markedup
        doccontent_url="{}/{}/register/{}/markedup"
        doccontent_url=doccontent_url.format(self.projectsurl,projectId,documentId)
        
        #isDownloadable = False
        #isDownloadable = self.is_downloadable(doccontent_url)
        #print("is downloadeable URL ? " , isDownloadable)
        
        return self.getResponse(doccontent_url, self.headers, self.username, self.password)
    
    @staticmethod
    def getResponse(apiurl, headers, username, password):
        
#        
#        if (not os.environ.get('PYTHONHTTPSVERIFY', '') and
#        getattr(ssl, '_create_unverified_context', None)):
#            ssl._create_default_https_context = ssl._create_unverified_context
        
        with requests.Session() as session:
            
            session.auth = (username, password)        
            # Instead of requests.get(), you'll use session.get()
            response = session.get(apiurl, headers=headers, verify=False)
            response.encoding ='utf-8'
            
        return response
    
    @staticmethod
    def is_downloadable(url):
        """
        Does the url contain a downloadable resource
        """
        h = requests.head(url, allow_redirects=True)
        header = h.headers
        content_type = header.get('content-type')
        if 'text' in content_type.lower():
            return False
        if 'html' in content_type.lower():
            return False
        return True
    
    def formatxmlstring(self, uglyxml):
        
        xmlstr = xml.dom.minidom.parseString(uglyxml)
        xml_pretty_str = xmlstr.toprettyxml()
        
        return xml_pretty_str


#    
if __name__ == '__main__':
    main(str(sys.argv[1]))

  
#print("Aconex- ADNOC Onshore Site!")
#projectsurl = 'https://mea.aconex.com/api/projects/'
#secretekey = '0331002e-a23a-46e9-b06c-26a4bdce9be1'
#username = 'dmadmin'
#password='Document001'
#
#
#mstrProjectid=1744831808
# 
#apiclient = DocumentRegister(projectsurl, secretekey, username, password)
# 
#response = apiclient.loadDocumentRegister(mstrProjectid)
# 
#
##response2=response2.encode('utf8')
#xmlcontent = response.text.encode('utf8')
#print(xmlcontent)
#elevations = xmltodict.parse(xmlcontent)
#print(elevations.keys())
#
#TotalResults = elevations['RegisterSearch']['@TotalResults']
#Documents = elevations['RegisterSearch']['SearchResults']['Document']
#print(Documents)
#
#values=[]
#for i in range(len(Documents)):
#    values.append(Documents[i])
#
#dfx = pd.DataFrame(values)
#
#norm_dfx= json_normalize(dfx.Attribute1)
#
#df_aconex = dfx.merge(norm_dfx, left_index=True, right_index=True)
#
#df_aconex.fillna('',inplace=True)
#
#column_names_dict = {'@DocumentId': 'DocumentId',
#        'AttributeTypeNames.AttributeTypeName': 'Project Code',
#        'AuthorisedBy': 'MOC Number',
#        'Category': 'Area',
#        'Comments': 'Project_Source_Doc_number',        
#        'Discipline': 'Discipline',
#        'DocumentNumber': 'Document No',
#        'DocumentStatus': 'Status',
#        'DocumentType': 'Type',
#        'Filename': 'File Name',
#        'FileSize': 'Size',
#        'FileType': 'File',
#        'ReviewStatus': 'Review Status',
#        'Revision': 'Revision',        
#        'Scale': 'Scale',
#        'SelectList1': 'Priority',
#        'SelectList10': 'Creator',
#        'SelectList2': 'Plant Area',
#        'SelectList3': 'Document Classification Code',
#        'SelectList4': 'Drawing Size',
#        'SelectList5': 'Action Type Code',
#        'SelectList8': 'Task Order',
#        'SelectList9': 'Contract Number',
#        'Title': 'Subject',
#        'DateApproved': 'Date Approved',
#        'DateCreated': 'Date Created',
#        'DateForReview': 'Date For Review',
#        'DateReviewed': 'Date Reviewed',
#        'RevisionDate': 'Revision Date',
#        'VersionNumber':'Version'
#        }
#
#df_aconex.rename(columns=column_names_dict, inplace = True)
#
#df_aconex['DocumentId'] = df_aconex['DocumentId'].astype('str')
#
#df_aconex['local_file_path'] = "D:/Temp/" + df_aconex['DocumentId'] + "." + df_aconex['File']
#
#df_aconex.drop(['Attribute1','AttributeType'], axis = 1, inplace=True)
#
#'''['DocumentId', 'DateApproved', 'MOC Number', 'Area',
#       'Project_Source_Doc_number', 'Current', 'DateCreated', 'DateForReview',
#       'DateReviewed', 'Discipline', 'Document No', 'Status', 'Type', 'Size',
#       'File', 'File Name', 'Review Status', 'Revision', 'Revision Date',
#       'Scale', 'Priority', 'Creator', 'Plant Area',
#       'Document Classification Code', 'Drawing Size', 'Action Type Code',
#       'Task Order', 'Contract Number', 'Subject', 'TrackingId', 'Version',
#       'Project Code', 'local_file_path']
#'''
#print(df_aconex.columns)
#
#
#
## format the date columns in dataframe
#date_cols = []
#for col_name, data_type in zip(df_aconex.columns, df_aconex.dtypes):
#    if 'Date' in col_name and data_type==object:
#        date_cols.append(col_name)
#
#print("Date Columns : ", date_cols)
#for col in date_cols:
#    #print(col)
#    df_aconex[col]= df_aconex[col].apply(lambda x: datetime.strptime(x, date_format))
#    #print(df_aconex[col])
#
#
## Filter drawings only
#dfx_drawings =  df_aconex[df_aconex['Type']=='Drawing']
#dfx_drawings =  dfx_drawings[ dfx_drawings['Review Status']=='Approved']
#
#file_name= ".\\output\\df_aconex_drawings_final.xlsx"
##with open(file_name, "wb") as f:
##    dfx_drawings.to_excel(f, sheet_name='Aconex Data', index = False)
#
## create excel writer object
#writer = pd.ExcelWriter(file_name)
## write dataframe to excel
#dfx_drawings.to_excel(writer, sheet_name='Aconex Data', index = False)
## save the excel
#writer.save()
#
#clean_target_file = ".\\output\\df_edms_drawings_ready_for_upload.xlsx"
## Prepare Data for EDMS upload
#clean_to_edms.execute(file_name, clean_target_file)
#
##dfx_drawings.to_excel(".\\input\\Aconex - metadata.xls", sheet_name='Aconex Data', index = False)
#
#for doc_id, file_path in dfx_drawings[['DocumentId','local_file_path']].itertuples(index=False):
#    print("Processiong Tracking : " + doc_id, file_path)     
#    response = apiclient.downloadContentFile(mstrProjectid, doc_id)
#    #response5=response5.encode('utf8')
#    print("Response file content type" , response.headers.get('content-type'))
#  
#    filename = Path(file_path)
#    file = open(filename, 'wb').write(response.content)
#    
#    print("Content file saved as : ", filename)
#   
#
#    #file.close()
    
