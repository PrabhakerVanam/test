# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module provides utility function to plot prediction and  
forecasting results obtained from the trained machine learning models.

@author: Prabhaker Reddy Vanam
"""

import os

import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.ticker as plticker

from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const
from aon.dlis.io import data_reader as reader
#from aon.dlis.postprocess import data_postprocessor as postproc

from pandas.plotting import register_matplotlib_converters
register_matplotlib_converters()

def plot_cqf_predictions(well_name, cqf_array, tdept, target_file_path):
    """This function plots the predicted target variable (CQF) computed by a model,
    along with the TDEP values if available.
    
    Parameters
    ----------
    :param well_name: WWell Name
    :param cqf_array: Cement Qualify Flag in 2-D array form
    :param tdept: TDEP array values for indexing
    :param target_file_path: Target file path to save the generated plot
    """
    print("Plotting for well %s " % (well_name))
    extent = [0, len(cqf_array) * .015, 0, len(cqf_array)]

    fig, ax = plt.subplots(nrows=1, ncols=1, sharey=False, figsize=(2, 25), constrained_layout=True)

    plotted = ax.imshow(cqf_array, cmap='viridis', vmin=1, vmax=3,
                        extent=extent,
                        interpolation='nearest', origin='lower', alpha=1.0)

    cb = fig.colorbar(plotted, ax=ax, location='top', pad=0.005, shrink=0.2, spacing='uniform', label='Quality')
    cb.ax.tick_params(labelsize=2)
    # cb.set_label("Quality")

    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=4)

    ax.invert_yaxis()
    ax.xaxis.set_major_locator(plticker.NullLocator())
    ax.xaxis.set_minor_locator(plticker.NullLocator())
    ax.xaxis.set_label_position('top')
    ax.xaxis.set_tick_params(width=0.0)
    ax.yaxis.set_tick_params(width=0.1)
    loc = plticker.MultipleLocator(base=25)
    ax.tick_params(labelsize=2)
    ax.yaxis.set_major_locator(loc)

    return fig

def paint_channel(ax, curve, y_axis, x_axis, **kwargs):
    """Plot an image channel into an axes using an index channel for the y-axis

    Parameters
    ----------
    :param ax: matplotlib.axes
    :param curve : numpy array  - The curve to be plotted
    :param index : numpy array  - The depth index as a Channel object (slower) or a numpy array (faster)
    :param **kwargs : dict      - Keyword arguments to be passed on to ax.imshow()
    """
    # Determine the extent of the image so that the pixel centres correspond with the correct axis values
    dx = np.mean(x_axis[1:] - x_axis[:-1])
    dy = np.mean(y_axis[1:] - y_axis[:-1])
    # Y - Top to Bottom
    # extent = (x_axis[0] - dx/2, x_axis[-1] + dx/2, y_axis[0] - dy/2, y_axis[-1] + dy/2)
    # Y - Bottom To Top
    extent = (x_axis[0] - dx / 2, x_axis[-1] + dx / 2, y_axis[-1] + dy / 2, y_axis[0] - dy / 2)

    # Determine the correct orientation of the image
    if y_axis[1] < y_axis[0]:  # Frame recorded from the bottom to the top of the well
        origin = 'lower'
    else:  # Frame recorded from the top to the bottom of the well
        origin = 'upper'

    return ax.imshow(curve, aspect='auto', origin=origin, extent=extent, **kwargs)


def plot_single_wave_form(frame, curvedata, channel_name, image_file_path):
    """Plot an wave image channel into an axes using an index channel for the y-axis

    Parameters
    -----------
    :param frame:
    :param curvedata:
    :param channel_name:
    :param image_file_path:
    :return:
    """
    wf1 = reader.get_channel(frame, channel_name)

    # Determine the maximum absolute value of WF1 and WF2 so that we can balance the colormap around 0
    wf_max = np.max(np.abs(curvedata[channel_name]))
    wf_lim = 0.12 * wf_max

    # Parameters for plotting the waveforms
    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic' #'viridis'
        'vmin': -wf_lim,
        'vmax': wf_lim,
    }

    wf_samples = np.arange(wf1.dimension[0])  # x values to use in plotting

    # Create figure and axes
    fig, axes = plt.subplots(nrows=1, ncols=1, sharey=True, figsize=(3.5, 18), constrained_layout=True)

    # Plot WF1 as an image
    ax = axes
    im = paint_channel(ax, curvedata[channel_name], curvedata[frame.index], wf_samples, **wf_pltargs)
    cbar = fig.colorbar(im, ax=ax, location='top')
    cbar.set_label(f'{wf1.name}: {wf1.long_name}')
    ax.set_ylabel('Depth $z$ [m]')
    ax.set_xlabel('Sample $k$')

    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.1)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)

    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    plt.savefig(image_file_path)

    return fig


def plot_single_cem_form(frame, curvedata, channel_name, image_file_path):
    """ Plot an CEMO image channel into an axes using an index channel for the y-axis

    Parameters
    ----------
    :param frame: Dlis frame
    :param curvedata: ndarray contains the Cemo data
    :param channel_name: Channel name in the frame
    :param image_file_path: File path to save Cemo plot
    :return:
    """
    cem = reader.get_channel(frame, channel_name)

    cem_data = pd.DataFrame(curvedata[channel_name])
    cem_data = cem_data[cem_data != -999.25].dropna()

    # Determine the maximum absolute value of cemo so that we can balance the colormap around 0
    # cem_max = np.max(np.abs(cem_data))
    # cem_lim = 0.25 * cem_max
    colors = ['red', 'deepskyblue', 'orange', 'turquoise', 'darkturquoise', 'lightseagreen', 'darkcyan', 'teal',
              'darkslategray', 'black']
    cmap = mpl.colors.ListedColormap(colors)
    # Parameters for plotting the cemo
    cem_pltargs = {
        'cmap': cmap,
        'vmin': -10.0,
        'vmax': 100,
    }
    wf_samples = np.arange(cem.dimension[0])

    # Create figure and axes
    fig, axes = plt.subplots(nrows=1, ncols=1, sharey=True, figsize=(3.5, 18), constrained_layout=True)

    # Plot WF1 as an image
    ax = axes
    im = paint_channel(ax, curvedata[channel_name], curvedata[frame.index], wf_samples, **cem_pltargs)
    cbar = fig.colorbar(im, ax=ax, location='top', shrink=0.99)
    cbar.set_label(f'{cem.name}: {cem.long_name}')
    ax.set_ylabel('Depth $z$ [m]')
    ax.set_xlabel('Sample $k$')

    ax.xaxis.set_tick_params(width=0.1)
    ax.yaxis.set_tick_params(width=0.1)
    ax.tick_params(axis="x", labelsize=2)
    ax.tick_params(axis="y", labelsize=2)
    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    ax.yaxis.set_major_locator(loc)

    plt.savefig(image_file_path)

    return fig


def plot_single_atc(frame, curvedata, atc_channel_names, image_file_path):
    """ Plot ATC channels into an axes using an index channel for the y-axis

    Parameters
    ----------
    :param frame: dlis's logical files frame
    :param curvedata: ndarray ATC channel data
    :param atc_channel_names: List of ATC channels names
    :param image_file_path: File path to save plot
    :return: fig
    """
    tdept_column = io_const.TDEP_COLUMN
    logs = pd.DataFrame(curvedata[[tdept_column] + atc_channel_names])
    logs = logs[logs != -999.25].dropna()

    fig, axs = plt.subplots(nrows=1, ncols=len(atc_channel_names), figsize=(3.5, 18), sharey=True)
    loc = plticker.MultipleLocator(base=25)  # this locator puts ticks at regular intervals
    color_list = ['green', 'red', 'blue', 'yellow', 'black', 'gray']

    for (ax, channel, color) in list(zip(axs, atc_channel_names, color_list)):
        ax.plot(logs[channel], logs[tdept_column], color=color, linewidth=0.4)
        ax.set_xlabel(channel, fontsize=2)
        ax.set_xlim(logs[channel].min(), logs[channel].max())

        ax.set_ylim(logs[tdept_column].min(), logs[tdept_column].max())

        ax.tick_params(axis="x", labelsize=2)
        ax.tick_params(axis="y", labelsize=4)

        ax.invert_yaxis()
        ax.xaxis.set_label_position('top')
        ax.xaxis.set_tick_params(width=0.1)
        ax.yaxis.set_tick_params(width=0.01)

        ax.tick_params(labelsize=2)
        ax.yaxis.set_major_locator(loc)

    axs[0].set_ylabel("Depth(ft)", fontsize=2)
    axs[0].yaxis.set_tick_params(width=0.1)

    # f.suptitle('{} - Well Log - by {}'.format(well_name, producer_name), fontsize=14,y=0.94)
    plt.savefig(image_file_path)

    return fig


def plot_well_casing(nda_values,  min_depth, max_depth,  file_path):
    """ This function generates 2D well casing plot.

    Parameters
    -----------
    :param nda_values: ndarray values to plot well casing
    :param file_path: Path to save the image

    :return:
    """
    wf_pltargs = {
        'cmap': plt.cm.Greys,  # plt.cm.Greys, #'seismic', #'viridis',
        'vmin': 0,
        'vmax': 2,
    }

    fig, axs = plt.subplots(nrows=1, ncols=1, sharey=True, figsize=(2, 50), constrained_layout=True)
    ylocator = mpl.ticker.MultipleLocator(base=25)

    # ax = fig.add_subplot(1,5,1)
    ax = axs
    ax.invert_yaxis()
    ax.yaxis.set_major_locator(ylocator)
    c2 = ax.imshow(nda_values, aspect='auto', origin='upper', extent=[0, 1, max_depth, min_depth], **wf_pltargs)
    cbar = fig.colorbar(c2, ax=ax, location='top', label='Well Image')

    plt.savefig(file_path, dpi=300)

    return fig


def plot_heatmaps(well_name, grid_search_df, realtime_df):
    """This function generates 2D heatmaps using grid-search calculations 
    performed for providing operating envelope using short-term forecasts. 
    These heatmaps have Choke settings on x-axis, and gas-lift rate on y-axis.

    Parameters
    ----------
    :param well_name: Name of the well
    :param grid_search_df: Pandas dataframe containing grid-search results
    :param realtime_df: Pandas dataframe with realtime sensor data, which is 
                        used for extracting current operating settings.     
    """
    plot_variables = [io_const.CUM_OIL_COLUMN, 
                      io_const.CUM_GAS_COLUMN, 
                      io_const.CUM_WATER_COLUMN, 
                      io_const.CUM_LIQUID_COLUMN, 
                      io_const.CUM_GOR_COLUMN, 
                      io_const.OIL_RATE_COLUMN, 
                      io_const.GAS_RATE_COLUMN, 
                      io_const.WATER_RATE_COLUMN, 
                      io_const.LIQUID_RATE_COLUMN,
                      io_const.WCT_COLUMN, 
                      io_const.GOR_COLUMN, 
                      io_const.RES_PRESSURE_COLUMN, 
                      io_const.NPV_COLUMN]
    for plot_var in plot_variables:
        pivot = grid_search_df.pivot(io_const.GL_RATE_COLUMN, 
                                     io_const.CHOKE_COLUMN, 
                                     plot_var)
        grid_values = pivot.values
        x_values = pivot.columns.tolist()
        y_values = pivot.index.tolist()
        x_max = np.max(x_values)
        x_min = 2. * x_max / ml_const.GRID_SEARCH_LENGTH
        y_max = np.max(y_values)
        y_min = np.min(y_values)
        fig = plt.figure(figsize=(8, 8))
        ax = plt.axes()
        img = ax.imshow(grid_values, cmap="jet", 
                        extent=(x_min, x_max, y_min, y_max), 
                        interpolation="nearest", 
                        aspect=(x_max / y_max))
        plt.colorbar(img, fraction=0.04525, pad=0.05)
        x = realtime_df[io_const.CHOKE_COLUMN].values.tolist()[-1]
        y = realtime_df[io_const.GL_RATE_COLUMN].values.tolist()[-1]
        plt.plot(x, y, "k*", markersize=12)
        ax.set(xlabel=io_const.CHOKE_COLUMN,
               ylabel=io_const.GL_RATE_COLUMN,
               title=well_name + ": " + plot_var + " - 30 Day Projections")
        for item in ([ax.title]):
            item.set_fontsize(16)
            item.set_weight("bold")
        for item in ([ax.xaxis.label, ax.yaxis.label]):
            item.set_fontsize(14)
            item.set_weight("bold")
        file_path = os.path.join(io_const.PLOTS_DIR, 
                                 well_name + "_" + plot_var + \
                                 io_const.GRID_SEARCH_PLOT_FILE_SUFFIX)
    
        fig.savefig(file_path, bbox_inches="tight", dpi=300)

