# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains constants, which are used during the various 
stages of machine learning model development.

@author: Prabhaker Reddy Vanam
"""

# Numerical constants for model development
RANDOM_SEED = 2459071
BLIND_TEST_FRACTION = 0.3
TS_BLIND_TEST_FRACTION = 0.1
VALIDATION_FRACTION = 0.15
NUM_FOLDS = 5
NUM_OIL_INPUT_COMBO = 8
BEST_OIL_COMBO = 7
NUM_BHP_BHT_COMBO = 6
BEST_BHP_BHT_COMBO = 5
NUM_PROSPER_COMBO = 2
NO_COMBO_CODE = 999
GLOBAL_STD_DEV_CUTOFF = 6.
LOCAL_STD_DEV_CUTOFF = 3.
LOCAL_RUNNING_WINDOW = 14
MONTHLY_RUNNING_WINDOW = 30
NO_FILTER_STD_DEV_CUTOFF = 1.e3
MIN_FLP_TARGET_VALUE = 0.1
ARIMAX_P = 14
ARIMAX_D = 1
ARIMAX_Q = 0
TS_MODEL_COMBO_CODE = "ts"
FORECAST_AGG_FREQ = 24

# Constants for calculating NPV or other objective function
MIN_CHOKE_INCH = 0.
MAX_CHOKE_INCH = 1.1
MIN_GL_RATE_MMSCF = 0.
MAX_GL_RATE_MMSCF = 2.
GRID_SEARCH_LENGTH = 50
OIL_COEFF = 50.
GAS_COEFF = -1000.
WATER_COEFF = -0.5

# Constants for diagnosing abnormal conditions
MAX_WATER_CUT = 20.
REL_OIL_RATE_DECLINE = 20.

# Constants defining model names
DATA_SCALER = "SCALER"
SVR_MODEL= "SVR"
NEURAL_NET_MODEL = "NN"
RANDOM_FOREST_MODEL = "RF"
LIGHTGBM_MODEL = "LIGHTGBM"
LINEAR_MODEL = "LM"
STACKED_MODEL = "STACKED"
RECURRENT_NEURAL_NET_MODEL = "RNN"
ARIMAX_MODEL = "ARIMAX"
COMPOSITE_MODEL_CODE = 0
