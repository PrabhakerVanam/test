# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains utility functions, which support creation of predictive
models during different stages of machine learning model development.

@author: Prabhaker Reddy Vanam
"""

import os

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from joblib import load
from matplotlib import pyplot as plt

from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const
from aon.dlis.model import predictive_models as pred_ml
from aon.dlis.preprocess import data_preprocessor as preproc
from aon.dlis.pred import prediction_helper as pred_helper

def get_oil_combo_columns(combo_code):
    """This function returns a list of data columns used for generating model 
    from the following combination mappings of input and output variables:

        * Combination 1:
            oil_rate = f(whp)

        * Combination 2:
            oil_rate = f(whp, bhp)

        * Combination 3:
            oil_rate = f(whp, flp, choke_dp)

        * Combination 4:
            oil_rate = f(whp, wht, flp, choke_dp)

        * Combination 5:
            oil_rate = f(whp, wht, flp, choke_dp, is_flowing)

            Note: Combination 5 has all surface variables.

        * Combination 6:
            oil_rate = f(whp, wht, bhp, bht, flp)

        * Combination 7:
            oil_rate = f(whp, wht, bhp, bht, flp, choke_dp, is_flowing)

        * Combination 8: 
            oil_rate = f(whp, wht, bhp, bht, flp, choke, choke_dp, is_flowing)
        
    Paramaters
    ----------
    :param combo_code: Integer code representing comboination of variables
    
    Return value(s)
    ---------------
    :return combo_columns: A list of columns for the combination of variables
    """
    combo_mapping = {}
    # Combination 1:
    # oil_rate = f(whp)
    combo_mapping[1] = [io_const.WHP_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    # Combination 2:
    # oil_rate = f(whp, bhp)
    combo_mapping[2] = [io_const.WHP_COLUMN, 
                 io_const.BHP_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    # Combination 3:
    # oil_rate = f(whp, flp, choke_dp)
    combo_mapping[3] = [io_const.WHP_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    # Combination 4:
    # oil_rate = f(whp, wht, flp, choke_dp)
    combo_mapping[4] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    # Combination 5:
    # oil_rate = f(whp, wht, flp, choke_dp, is_flowing)
    combo_mapping[5] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    # Combination 6:
    # oil_rate = f(whp, wht, bhp, bht, flp)
    combo_mapping[6] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.BHP_COLUMN, 
                 io_const.BHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    # Combination 7:
    # oil_rate = f(whp, wht, bhp, bht, flp,  
    #              choke_dp, is_flowing)
    combo_mapping[7] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.BHP_COLUMN, 
                 io_const.BHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    # Combination 8:
    # oil_rate = f(whp, wht, bhp, bht, flp, choke, 
    #              choke_dp, is_flowing)
    combo_mapping[8] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.BHP_COLUMN, 
                 io_const.BHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN, 
                 io_const.OIL_RATE_COLUMN]
    combo_columns = combo_mapping[combo_code]
    return combo_columns

def get_bhp_bht_combo_columns(combo_code, target_variable):
    """This function returns a list of data columns used for generating model 
    from the following combination mappings of input and output variables:
        
        * Combination 1:
            bhp = f(wht)
            
            bht = f(whp)

        * Combination 2:
            bhp = f(whp)
            
            bht = f(wht)

        * Combination 3:
            bhp = f(whp, wht)
            
            bht = f(whp, wht)

        * Combination 4:
            bhp = f(whp, wht, flp, choke_dp)
            
            bht = f(whp, wht, flp, choke_dp)

        * Combination 5:
            bhp = f(whp, wht, flp, choke_dp, is_flowing)
            
            bht = f(whp, wht, flp, choke_dp, is_flowing)

        * Combination 6:
            bhp = f(whp, wht, flp, choke_dp, choke, is_flowing)
            
            bht = f(whp, wht, flp, choke_dp, choke, is_flowing)
        
    Paramaters
    ----------
    :param combo_code: Integer code representing comboination of variables
    :param target_variable: The variable, which will be predicted by the model
    
    Return value(s)
    ---------------
    :return combo_columns: A list of columns for the combination of variables
    """
    combo_mapping = {}
    # Combination 1:
    # target_variable = f(whp or wht)
    if target_variable == io_const.BHT_COLUMN:
        combo_mapping[1] = [io_const.WHP_COLUMN, 
                     target_variable]
    elif target_variable == io_const.BHP_COLUMN:
        combo_mapping[1] = [io_const.WHT_COLUMN, 
                     target_variable]
    # Combination 2:
    # target_variable = f(wht or whp)
    if target_variable == io_const.BHP_COLUMN:
        combo_mapping[2] = [io_const.WHP_COLUMN, 
                     target_variable]
    elif target_variable == io_const.BHT_COLUMN:
        combo_mapping[2] = [io_const.WHT_COLUMN, 
                     target_variable]
    # Combination 3:
    # target_variable = f(whp, wht)
    combo_mapping[3] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 target_variable]
    # Combination 4:
    # target_variable = f(whp, wht, flp, choke_dp)
    combo_mapping[4] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 target_variable]
    # Combination 5:
    # target_variable = f(whp, wht, flp, choke_dp, 
    #                     is_flowing)
    combo_mapping[5] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN, 
                 target_variable]
    # Combination 6:
    # target_variable = f(whp, wht, flp, choke_dp, 
    #                     choke, is_flowing)
    combo_mapping[6] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.IS_WELL_FLOWING_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 target_variable]
    combo_columns = combo_mapping[combo_code]
    return combo_columns

def get_prosper_combo_columns(combo_code, target_variable):
    """This function returns a list of data columns used for generating models 
    from read from Prosper simulated data, based upon the combination code and 
    the target variable provided as parameters.
    
    Paramaters
    ----------
    :param combo_code: Integer code representing comboination of variables
    :param target_variable: The variable, which will be predicted by the model
    
    Return value(s)
    ---------------
    :return combo_columns: A list of columns for the combination of variables
    """
    combo_mapping = {}
    combo_mapping[1] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.FLT_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.CHOKE_DT_COLUMN, 
                 io_const.CHOKE_COLUMN]
    combo_mapping[2] = [io_const.WHP_COLUMN, 
                 io_const.WHT_COLUMN, 
                 io_const.FLP_COLUMN, 
                 io_const.FLT_COLUMN, 
                 io_const.CHOKE_DP_COLUMN, 
                 io_const.CHOKE_DT_COLUMN, 
                 io_const.CHOKE_COLUMN, 
                 io_const.CHP_COLUMN, 
                 io_const.GL_RATE_COLUMN]
    if target_variable == io_const.RES_PRESSURE_COLUMN or \
    target_variable == io_const.PROD_INDEX_COLUMN:
        combo_mapping[combo_code].append(io_const.BHP_COLUMN)
    combo_mapping[combo_code].append(target_variable)
    combo_columns = combo_mapping[combo_code]
    return combo_columns

def get_model_prefix(model_type, target_var, combo_code, scaled_var=None):
    """This function returns a prefix for generating the name of models to 
    be saved to file, for a particular combination code.

    Paramaters
    ----------
    :param model_type: Type of the model to be saved (e.g. scaler, svm etc.)
    :param target_var: Target variable being modeled
    :param combo_code: Integer code representing comboination of variables
    :param scaled_var: Input variable being scaled (optional, if not data scaler)
    
    Return value(s)
    ---------------
    :return model_prefix: Prefix for file name to save the model
    """
    model_prefix = target_var
    if scaled_var != None:
        model_prefix += io_const.MODEL_SEPARATOR + scaled_var 
    model_prefix += io_const.MODEL_SEPARATOR + model_type + \
    io_const.MODEL_SEPARATOR + io_const.MODEL_COMBO_PREFIX + str(combo_code)
    return model_prefix

def get_model_name(well_name, model_name_prefix, model_fold=None, 
                   scaled_var=None):
    """This function returns the name of a model to be saved to a file, based upon 
    the parameters passed.
    
    Parameters
    ----------
    :param well_name: Name of the well
    :param model_name_prefix: Prefix for the name of model
    :param model_fold: Fold in KFold this model belongs to
    :param scaled_var: Input variable being scaled (optional, if not data scaler)
    
    Return value(s)
    ---------------
    :return model_name: Name of the model to be saved to file
    """
    model_name = well_name + io_const.MODEL_SEPARATOR + model_name_prefix
    if model_fold != None:
        model_name += io_const.MODEL_SEPARATOR + io_const.MODEL_FOLD + \
        str(model_fold)
    if scaled_var != None:
        model_name += io_const.MODEL_SEPARATOR + scaled_var
    model_name += io_const.MODEL_NAME_SUFFIX
    return model_name

def get_keras_model_name(well_name, model_name_prefix, model_fold=None):
    """This function returns the name of a Keras model to be saved to a file, 
    based upon the parameters passed.
    
    Parameters
    ----------
    :param well_name: Name of the well
    :param model_name_prefix: Prefix for the name of model
    :param model_fold: Fold in KFold this model belongs to
    
    Return value(s)
    ---------------
    :return model_name: Name of the Keras model to be saved to file
    """
    model_name = well_name + io_const.MODEL_SEPARATOR + model_name_prefix
    if model_fold != None:
        model_name += io_const.MODEL_SEPARATOR + io_const.MODEL_FOLD + \
        str(model_fold) 
    model_name += io_const.KERAS_MODEL_SUFFIX
    return model_name

def get_lightgbm_model_name(well_name, model_name_prefix, model_fold=None):
    """This function returns the name of a LightGBM model to be saved to a file, 
    based upon the parameters passed.
    
    Parameters
    ----------
    :param well_name: Name of the well
    :param model_name_prefix: Prefix for the name of model
    :param model_fold: Fold in KFold this model belongs to
    
    Return value(s)
    ---------------
    :return model_name: Name of the LightGBM model to be saved to file
    """
    model_name = well_name + io_const.MODEL_SEPARATOR + model_name_prefix
    if model_fold != None:
        model_name += io_const.MODEL_SEPARATOR + io_const.MODEL_FOLD + \
        str(model_fold) 
    model_name += io_const.LGBM_MODEL_SUFFIX
    return model_name

def get_arimax_model_name(well_name, model_name_prefix, model_fold=None):
    """This function returns the name of a ARIMAX model to be saved to a file, 
    based upon the parameters passed.
    
    Parameters
    ----------
    :param well_name: Name of the well
    :param model_name_prefix: Prefix for the name of model
    :param model_fold: Fold in KFold this model belongs to (mostly None for ARIMAX)
    
    Return value(s)
    ---------------
    :return model_name: Name of the ARIMAX model to be saved to file
    """
    model_name = well_name + io_const.MODEL_SEPARATOR + model_name_prefix
    if model_fold != None:
        model_name += io_const.MODEL_SEPARATOR + io_const.MODEL_FOLD + \
        str(model_fold) 
    model_name += io_const.ARIMAX_MODEL_SUFFIX
    return model_name

def develop_models_kfold(df, well_name, xy_cols, model_type, 
                       num_folds, scaler_prefix, model_prefix, 
                       save_models=False, calc_feat_imp=False):
    """This python function develops machine learning (ML) models with KFold 
    cross-validation for the provided dataframe, by using provided names 
    of X and y columns in the dataframe. If instructed, it also saves the 
    developed models to files.
    
    Paramaters
    ----------
    :param df: Pandas dataframe with the values to model
    :param well_name: Name of the well
    :param xy_cols: List providing names of columns to be used as input 
                    features (X), and target variable (y; last column has target)
    :param model_type: Type of the model to develop (e.g. RF, etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param num_folds: Number of folds in KFold cross-validation
    :param scalar_prefix: Prefix to the names for saving data scalers to files
    :param model_prefix: Prefix to the names for saving ML models to files
    :param save_models: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance
    
    Return value(s)
    ---------------
    :return fold_r2: R^2 values from each fold in KFold CV
    :return test_r2: R^2 values from held out blind test data
    :return feat_imp_df_list: Pandas dataframe with feature importance scores 
                              and rankings
    """
    # Extract the Pandas dataframe rows, where all the columns have finite
    # values, and target column has non-zero values
    combo_df = df[xy_cols]
    # Filter out the rows, which have null values in the feature columns
    for xy_col in xy_cols:
        if xy_col != xy_cols[-1]:
            combo_df = combo_df[pd.notnull(combo_df[xy_col])]
            combo_df = combo_df[pd.notna(combo_df[xy_col])]
    combo_df = combo_df.reset_index(drop=True)
    # Scale the feature columns, and save data scaler objets
    combo_df = preproc.fit_scale_dataframe_columns(combo_df, well_name, 
                                                   scaler_prefix, True)
    # Split data into training and blind test sets
    train_X, test_X, train_y, test_y = \
    train_test_split(combo_df[xy_cols[:-1]], combo_df[xy_cols[-1]],  
                     test_size=ml_const.BLIND_TEST_FRACTION, 
                     random_state=ml_const.RANDOM_SEED)
    train_X = train_X.reset_index(drop=True)
    train_y = train_y.reset_index(drop=True)
    
    # Train the machine learning model with KFold cross-validations
    fold_r2, feat_imp_df_list = pred_ml.train_model_kfold(train_X, train_y, 
                                                          num_folds, 
                                                          well_name, model_type, 
                                                          io_const.MODEL_DIR, 
                                                          model_prefix, 
                                                          save_models=save_models, 
                                                          calc_feat_imp=calc_feat_imp)

    test_y_pred = predict_models_kfold(test_X, well_name, xy_cols[:-1], 
                                       num_folds, model_prefix, 
                                       scaler_prefix=scaler_prefix, 
                                       input_pre_scaled=True)
    mean_y_pred, _ = get_kfold_mean_std(test_y_pred, num_folds)

    # ADHOC Plotting
    fig = plt.figure()
    plt.scatter(test_y, test_y_pred[:,0], c="red", alpha=0.5)
    plt.scatter(test_y, test_y_pred[:,1], c="green", alpha=0.5)
    plt.scatter(test_y, test_y_pred[:,2], c="blue", alpha=0.5)
    plt.scatter(test_y, test_y_pred[:,3], c="cyan", alpha=0.5)
    plt.scatter(test_y, mean_y_pred, c="black", alpha=0.5)
    fig.suptitle(model_prefix)
    # END of ADHOC Plotting

    test_r2 = r2_score(test_y, mean_y_pred)
    return fold_r2, test_r2, feat_imp_df_list

def get_kfold_mean_std(kfold_preds, num_folds):
    """This function computes mean and standard deviation for each output row  
    in predictions generated by models trained using KFold cross-validation.
    
    Parameters
    ----------
    :param kfold_preds: np.ndarray with predicted values from each fold in 
                        KFold cross-validation arranged in columns
    :param num_folds: Number of folds in KFold cross-validation
    
    Return value(s)
    ---------------
    :return means: Row-wise mean values for each row in KFold CV predictions
    :return std_devs: Row-wise standard deviation values for each row in KFold 
                      CV predictions
    """
    means = None 
    std_devs = None
    if len(kfold_preds.shape) == 2 and kfold_preds.shape[1] != num_folds:
        kfold_preds = kfold_preds.reshape(-1, num_folds)
        means = np.mean(kfold_preds, axis=1)
        std_devs = np.std(kfold_preds, axis=1)
    elif len(kfold_preds.shape) == 3:
        means = np.mean(kfold_preds, axis=2)
        std_devs = np.std(kfold_preds, axis=2) 
    else:
        kfold_preds = kfold_preds.reshape(-1, num_folds)
        means = np.mean(kfold_preds, axis=1)
        std_devs = np.std(kfold_preds, axis=1)
        
    return means, std_devs

def get_kfold_mean_std_rescaled(kfold_preds, num_folds, well_name,  
                                scaler_prefix, output_var_name):
    """This function computes mean and standard deviation for each output row  
    in predictions generated by  models trained using KFold cross-validation. 
    Before computing mean and standard deviations, the values are rescaled to 
    the original data ranges.
    
    Parameters
    ----------
    :param kfold_preds: np.ndarray with predicted values from each fold in 
                        KFold cross-validation arranged in columns
    :param num_folds: Number of folds in KFold cross-validation
    :param well_name: Name of the well
    :param scalar_prefix: Prefix to the names for saved data scaler files
    :param output_var_name: Name of the output variable to rescale, compute 
                            means and standard deviations
    
    Return value(s)
    ---------------
    :return means: Row-wise mean values for each row in rescaled KFold cross-
                   validation predictions
    :return std_devs: Row-wise standard deviation values for each row in 
                      rescaled KFold cross-validation predictions
    """
    if kfold_preds.shape[1] != num_folds:
        kfold_preds = kfold_preds.reshape(-1, num_folds)
    scaler_name = get_model_name(well_name, scaler_prefix, 
                                 scaled_var=output_var_name)
    scaler_path = os.path.join(io_const.MODEL_DIR, scaler_name)
    scaler = load(scaler_path)
    kfold_preds = scaler.inverse_transform(kfold_preds)
    means = np.mean(kfold_preds, axis=1)
    std_devs = np.std(kfold_preds, axis=1)
    return means, std_devs
        
def predict_models_kfold(df, well_name, feat_cols, num_folds, model_prefix, 
                         scaler_prefix=None, input_pre_scaled=False):
    """This function uses trained machine learning (ML) models with 
    KFold cross-validation for generating prediction based on the provided 
    dataframe, and the names of feature columns in the dataframe.
    
    Paramaters
    ----------
    :param df: Pandas dataframe with input values
    :param well_name: Name of the well
    :param feat_cols: List providing names of columns to be used as input 
                      features (X)
    :param num_folds: Number of folds in KFold cross-validation
    :param model_prefix: Prefix to the names for saved ML model files
    :param scalar_prefix: Prefix to the names for saved data scaler files
    :param input_pre_scaled: Flag indicating whether input is already scaled
    
    Return value(s)
    ---------------
    :return pred_kfold: np.ndarray with predicted values from each fold in 
                        KFold cross-validation arranged in columns
    """
    # Extract the Pandas dataframe columns with input features
    input_df = None
    if feat_cols != None:
        input_df = df[feat_cols]
    else:
        input_df = df
    # Scale the feature columns, if not already scaled
    if input_pre_scaled != True:
        input_df = preproc.scale_feature_columns(input_df, well_name, 
                                                 scaler_prefix)
    # Use pre-trained machine learning with KFold cross-validations
    pred_kfold = pred_ml.predict_model_kfold_scaled_input(input_df, 
                                                          num_folds, 
                                                          well_name, 
                                                          io_const.MODEL_DIR, 
                                                          model_prefix)
    return pred_kfold

def postprocess_feature_importance(feat_imp_df_list):
    """This function prepares a final feature importance ranking by 
    aggregating ranking scores from all folds in a KFold cross-
    validation. The variable with a lower aggregate ranking has a 
    higher importance/weightage in the predictions made by the model.
    
    Parameters
    ----------
    :param feat_imp_df_list: List containing dataframes from each KFold 
                             with feature rankings
    Return value(s)
    ---------------
    :return feat_names: Feature names sorted in the order of importance
    :return rank_scores: Rank scores for the features sorted in ascending order
    """
    feat_names = feat_imp_df_list[0].index.values
    rank_scores = np.zeros(len(feat_names)).astype(np.int32)
    for feat_imp_df in feat_imp_df_list:
        #print(feat_imp_df)
        i = 0
        for feat_name in feat_names:
            rank_scores[i] += feat_imp_df.loc[feat_name, "Rank"]
            i += 1
    sort_idxs = np.argsort(rank_scores).tolist()
    feat_names = feat_names[sort_idxs]
    rank_scores = rank_scores[sort_idxs]
    return feat_names, rank_scores

def develop_oil_model_for_combo(well_name, model_df, combo_code, 
                                model_type, save_models=False, 
                                calc_feat_imp=False):
    """This function provides a wrapper for training a particular type of 
    machine learning (ML) model, e.g., RF, for predicting oil rates.
    
    Paramaters
    ----------
    :param well_name: Name of the well
    :param model_df: Pandas dataframe with the features and target values to 
                     model oil flow rates
    :param combo_code: Integer code indicating combination of input variables 
                       to use in the input feature for training the ML models
    :param model_type: Type of the model to develop (e.g. RF, etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param save_models: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance

    Return value(s)
    ---------------
    :return folds_r2: R^2 values from each fold in KFold CV
    :return test_r2: R^2 values from held out blind test data
    """
    xy_cols = get_oil_combo_columns(combo_code)
    scaler_prefix = get_model_prefix(ml_const.DATA_SCALER, 
                                     io_const.OIL_RATE_MODEL_PREFIX, 
                                     combo_code)
    model_prefix = get_model_prefix(model_type, 
                                    io_const.OIL_RATE_MODEL_PREFIX, 
                                    combo_code)
    folds_r2, test_r2, feat_imp_df_list = develop_models_kfold(model_df, well_name, 
                                                               xy_cols, model_type, 
                                                               ml_const.NUM_FOLDS, 
                                                               scaler_prefix, 
                                                               model_prefix, 
                                                               save_models=save_models, 
                                                               calc_feat_imp=calc_feat_imp)
    if calc_feat_imp and model_type == ml_const.RANDOM_FOREST_MODEL:
        feat_order, rank_scores = postprocess_feature_importance(feat_imp_df_list)
        print("Variable\tRank Score")
        for i in range(len(feat_order)):
            print("%s\t%f" % (feat_order[i], rank_scores[i]))
    return folds_r2, test_r2

def prepare_bhp_bht_model_for_combo(well_name, model_df, combo_code, 
                                    model_type, target_variable, 
                                    save_models=False, 
                                    calc_feat_imp=False):
    """This function provides a wrapper for training a particular type of 
    machine learning (ML) model, e.g., RF, for predicting BHP/BHT.
    
    Paramaters
    ----------
    :param well_name: Name of the well
    :param model_df: Pandas dataframe with the features and target values to 
                     model BHP/BHT
    :param combo_code: Integer code indicating combination of input variables 
                       to use in the input feature for training the ML models
    :param model_type: Type of the model to develop (e.g. nn, svm etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param target_variable: The variable, which will be predicted by the model
    :param save_models: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance

    Return value(s)
    ---------------
    :return folds_r2: R^2 values from each fold in KFold CV
    :return test_r2: R^2 values from held out blind test data
    """
    xy_cols = get_bhp_bht_combo_columns(combo_code, target_variable)
    prefix = None
    if target_variable == io_const.BHP_COLUMN:
        prefix = io_const.BHP_MODEL_PREFIX
    elif target_variable == io_const.BHT_COLUMN:
        prefix = io_const.BHT_MODEL_PREFIX
    scaler_prefix = get_model_prefix(ml_const.DATA_SCALER, prefix, combo_code)
    model_prefix = get_model_prefix(model_type, prefix, combo_code)
    folds_r2, test_r2, feat_imp_df_list = develop_models_kfold(model_df, well_name, 
                                                               xy_cols, model_type, 
                                                               ml_const.NUM_FOLDS, 
                                                               scaler_prefix, 
                                                               model_prefix, 
                                                               save_models=save_models, 
                                                               calc_feat_imp=calc_feat_imp)
    if calc_feat_imp and model_type == ml_const.RANDOM_FOREST_MODEL:
        feat_order, rank_scores = postprocess_feature_importance(feat_imp_df_list)
        print("Variable\tRank Score")
        for i in range(len(feat_order)):
            print("%s\t%f" % (feat_order[i], rank_scores[i]))
    return folds_r2, test_r2

def develop_oil_rate_models(well_test_data, model_type, save_model, 
                            calc_feat_imp):
    """This function generates machine learning regression models (e.g. RF) to 
    predict oil flow rates based upon the various combinations of the 
    surface, and bottomhole measured parameters. The function assumes a well 
    completed in a single reservoir zone.
    
    Parameters
    ----------
    :param well_test_data: A populated adnoc.wellopt.ds.data_structures.WellTestData object
    :param model_type: Type of the model to develop (e.g. RF, etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param save_model: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance
    """
    # In this function, we develop models to predict oil rates, based 
    # upon a combination of following variables:
    #       adnoc.wellopt.ds.data_structures.WellTestData.whp
    #       adnoc.wellopt.ds.data_structures.WellTestData.wht
    #       adnoc.wellopt.ds.data_structures.WellTestData.bhp
    #       adnoc.wellopt.ds.data_structures.WellTestData.bht
    #       adnoc.wellopt.ds.data_structures.WellTestData.flp
    #       adnoc.wellopt.ds.data_structures.WellTestData.choke
    #       adnoc.wellopt.ds.data_structures.WellTestData.choke_dp
    #       adnoc.wellopt.ds.data_structures.WellTestData.is_well_flowing
    # Combinations of input data considered during model development/training
    # Combination 1: whp
    # Combination 2: whp + bhp
    # Combination 3: whp + flp + choke_dp
    # Combination 4: whp + wht + flp + choke_dp
    # Combination 5: whp + wht + flp + choke_dp + is_flowing
    # Note: Combination 5 has all surface variables.
    # Combination 6: whp + wht + bhp + bht + flp
    # Combination 7: whp + wht + bhp + bht + flp +
    #                choke_dp + is_flowing
    # Combination 8: whp + wht + bhp + bht + flp + choke + 
    #                choke_dp + is_flowing
    well_name = well_test_data.well_name
    model_df = preproc.prepare_oil_model_dataframe(well_test_data)
    num_combos = ml_const.NUM_OIL_INPUT_COMBO
    for i in range(num_combos):
        combo_code = i + 1
        print("Oil Rate " + model_type + " Model for Combination %d." \
              % combo_code)
        folds_r2, test_r2 = develop_oil_model_for_combo(well_name, model_df, 
                                                        combo_code, 
                                                        model_type, 
                                                        save_models=save_model, 
                                                        calc_feat_imp=calc_feat_imp)
        print("R2 from KFolds: " + str(folds_r2))
        print("R2 from blind test: " + str(test_r2))

def develop_bhp_bht_models(well_test_data, model_type, target_variable, 
                           save_model, calc_feat_imp):
    """This function generates machine learning regression models (e.g. RF) to 
    predict BHP/BHT based upon the various combinations of the parameters 
    measured at the surface. The function assumes a well completed in a 
    single reservoir zone.

    Parameters
    ----------
    :param well_test_data: A populated adnoc.wellopt.ds.data_structures.WellTestData object
    :param model_type: Type of the model to develop (e.g. RF, etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param target_variable: The variable, which will be predicted by the model
    :param save_model: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance
    """
    # In this function, we develop models to predict BHP/BHT, based 
    # upon a combination of following variables:
    #       adnoc.wellopt.ds.data_structures.WellTestData.whp
    #       adnoc.wellopt.ds.data_structures.WellTestData.wht
    #       adnoc.wellopt.ds.data_structures.WellTestData.flp
    #       adnoc.wellopt.ds.data_structures.WellTestData.choke
    #       adnoc.wellopt.ds.data_structures.WellTestData.choke_dp
    #       adnoc.wellopt.ds.data_structures.WellTestData.is_well_flowing
    # Combinations of input data considered during model development/training
    # Combination 1: whp
    # Combination 2: wht
    # Combination 3: whp + wht
    # Combination 4: whp + wht + flp + choke_dp
    # Combination 5: whp + wht + flp + choke_dp + is_flowing
    # Combination 6: whp + wht + flp + choke_dp + choke +
    #                is_flowing
    well_name = well_test_data.well_name
    model_df = preproc.prepare_bhp_bht_model_dataframe(well_test_data, 
                                                       target_variable)
    num_combos = ml_const.NUM_BHP_BHT_COMBO
    for i in range(num_combos):
        combo_code = i + 1
        print(target_variable + " " + model_type + " Model for Combination %d." \
              % combo_code)
        folds_r2, test_r2 = prepare_bhp_bht_model_for_combo(well_name, model_df, 
                                                              combo_code, 
                                                              model_type,
                                                              target_variable, 
                                                              save_models=save_model, 
                                                              calc_feat_imp=calc_feat_imp)
        print("R2 from KFolds: " + str(folds_r2))
        print("R2 from blind test: " + str(test_r2))

def prepare_prosper_model_for_combo(well_name, model_df, combo_code, 
                                    model_type, target_variable, 
                                    save_models=False):
    """This function provides a wrapper for training a particular type of 
    machine learning (ML) model, e.g., RF, for the training data simulated 
    by Prosper nodal analysis.
    
    Paramaters
    ----------
    :param well_name: Name of the well
    :param model_df: Pandas dataframe with the features and target values to model
    :param combo_code: Integer code indicating combination of input variables 
                       to use in the input feature for training the ML models
    :param model_type: Type of the model to develop (e.g. RF, etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param target_variable: The variable, which will be predicted by the model
    :param save_models: Flag indicating whether or not save models to files

    Return value(s)
    ---------------
    :return folds_r2: R^2 values from each fold in KFold CV
    :return test_r2: R^2 values from held out blind test data
    """
    xy_cols = get_prosper_combo_columns(combo_code, target_variable)
    prefix = None
    if target_variable == io_const.OIL_RATE_COLUMN:
        prefix = io_const.OIL_RATE_MODEL_PREFIX
    elif target_variable == io_const.LIQ_RATE_COLUMN:
        prefix = io_const.LIQ_MODEL_PREFIX
    elif target_variable == io_const.GOR_COLUMN:
        prefix = io_const.GOR_MODEL_PREFIX
    elif target_variable == io_const.WATER_CUT_COLUMN:
        prefix = io_const.WCT_MODEL_PREFIX
    elif target_variable == io_const.BHP_COLUMN:
        prefix = io_const.BHP_MODEL_PREFIX
    elif target_variable == io_const.PROD_INDEX_COLUMN:
        prefix = io_const.PI_MODEL_PREFIX
    elif target_variable == io_const.RES_PRESSURE_COLUMNN:
        prefix = io_const.RES_PRESSURE_MODEL_PREFIX
    scaler_prefix = get_model_prefix(ml_const.DATA_SCALER, prefix, combo_code)
    model_prefix = get_model_prefix(model_type, prefix, combo_code)
    folds_r2, test_r2, feat_imp_df_list = develop_models_kfold(model_df, well_name, 
                                                               xy_cols, model_type, 
                                                               ml_const.NUM_FOLDS, 
                                                               scaler_prefix, 
                                                               model_prefix, 
                                                               save_models=save_models)
    return folds_r2, test_r2

def develop_prosper_based_models(prosper_well_data, model_type, target_variable, 
                                 save_model=False, calc_feat_imp=False):
    """This function generates machine learning regression models (e.g. RF) to 
    predict target variables based upon the various combinations of the input 
    parameters in the training data simulated by Prosper nodal analysis. 

    Parameters
    ----------
    :param prosper_well_data: A populated adnoc.wellopt.ds.data_structures.WellProsperData object
    :param model_type: Type of the model to develop (e.g. RF, etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param target_variable: The variable, which will be predicted by the model
    :param save_model: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance
    """
    well_name = prosper_well_data.well_name
    model_df = preproc.prepare_prosper_model_dataframe(prosper_well_data, 
                                                       target_variable)
    num_combos = ml_const.NUM_PROSPER_COMBO
    for i in range(num_combos):
        combo_code = i + 1
        print(target_variable + " " + model_type + " Model for Combination %d." \
              % combo_code)
        folds_r2, test_r2 = prepare_prosper_model_for_combo(well_name, model_df, 
                                                            combo_code, 
                                                            model_type, 
                                                            target_variable, 
                                                            save_models=save_model)
        print("R2 from KFolds: " + str(folds_r2))
        print("R2 from blind test: " + str(test_r2))

def develop_prediction_models(well_test_data, model_type, target_variable, 
                             save_model=False, calc_feat_imp=False):
    """This function generates machine learning regression models (e.g. RF) to 
    predict the defined output variable based upon the various combinations of 
    input variables. The function assumes a well completed in a single reservoir zone. 
    This function wraps the functionality for modeling Oil rates, BHP, and BHT.
    
    Parameters
    ----------
    :param well_test_data: A populated adnoc.wellopt.ds.data_structures.WellTestData object
    :param model_type: Type of the model to develop (e.g. RF, etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param target_variable: The variable, which will be predicted by the model
    :param save_models: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance
    """
    if target_variable == io_const.OIL_RATE_COLUMN:
        develop_oil_rate_models(well_test_data, model_type, save_model, 
                                calc_feat_imp)
    elif target_variable == io_const.BHP_COLUMN or \
    target_variable == io_const.BHT_COLUMN:
        develop_bhp_bht_models(well_test_data, model_type, target_variable, 
                                 save_model, calc_feat_imp)

def get_well_test_variables_list():
    """This function returns a list of target variables in the well test data, 
    which will be modeled using Machine Learning model stacking technique.
    
    Return value(s)
    ---------------
    :return test_variables: List of variables, which will be predicted by the models
    """
    test_variables = [io_const.RES_PRESSURE_COLUMN, 
                      io_const.LIQUID_RATE_COLUMN, 
                      io_const.OIL_RATE_COLUMN, 
                      io_const.WATER_RATE_COLUMN, 
                      io_const.GAS_RATE_COLUMN, 
                      io_const.GOR_COLUMN, 
                      io_const.WCT_COLUMN]
    return test_variables

def get_flow_variable_feature_col_names():
    """This function returns a list of feature columns derived from the well test data, 
    which will be used as input feature for Machine Learning model stacking technique to 
    develop flow rate prediction models.
    
    Return value(s)
    ---------------
    :return x_cols: List of feature column for generating stacked models of flow rates
    """
    x_cols = [io_const.WHP_COLUMN, io_const.WHP_SQ_COLUMN, io_const.WHT_COLUMN, 
              io_const.WHT_SQ_COLUMN, io_const.CHOKE_COLUMN, io_const.FLP_COLUMN, 
              io_const.CHOKE_DP_COLUMN, io_const.GL_RATE_COLUMN]
    return x_cols

def get_rate_variable_col_names():
    """This function returns a list of flow rate variables in the well test data, 
    which will be modeled using Machine Learning model stacking technique.
    
    Return value(s)
    ---------------
    :return rate_variables: List of flow rate variables, which will be predicted 
                           by the models
    """
    rate_variables = [io_const.LIQUID_RATE_COLUMN, io_const.OIL_RATE_COLUMN, 
                      io_const.WATER_RATE_COLUMN, io_const.GAS_RATE_COLUMN]
    return rate_variables

def get_nonrate_variable_col_names():
    """This function returns a list of non-flow rate variables in the well test 
    data, which will be modeled using Machine Learning model stacking technique.
    
    Return value(s)
    ---------------
    :return non_rate_variables: List of non-flow rate variables, which will 
                               be predicted by the models
    """
    non_rate_variables = [io_const.WCT_COLUMN, io_const.GOR_COLUMN, 
                          io_const.RES_PRESSURE_COLUMN]
    return non_rate_variables

def get_res_press_feature_col_names():
    """This function returns a list of feature columns derived from the well test data, 
    which will be used as input feature for Machine Learning model stacking technique to 
    develop reservoir pressure prediction models.
    
    Return value(s)
    ---------------
    :return x_cols: List of feature column for generating stacked models of reservoir 
                   pressure
    """
    x_cols = [io_const.WHP_COLUMN, 
              io_const.GL_RATE_COLUMN, 
              io_const.CUM_LIQUID_COLUMN, 
              io_const.CUM_GAS_COLUMN]
    return x_cols

def get_flp_feature_col_names():
    """This function returns a list of feature columns derived from the well test data or 
    realtime sensor data, which will be used as input feature for Machine Learning model 
    stacking technique to develop flowline pressure prediction models.
    
    Return value(s)
    ---------------
    :return x_cols: List of feature column for generating stacked models of flowline 
                   pressure
    """
    x_cols = [io_const.WHP_COLUMN, io_const.WHT_COLUMN, 
              io_const.CHOKE_COLUMN]
    return x_cols

def get_stacked_model_algo_list():
    """This function returns a list of Machine Learning algorithm used during 
    model stacking technique to develop prediction models.
    
    Return value(s)
    ---------------
    :return model_types: List of Machine Learning algorithm used during model stacking
    """
    model_types = [ml_const.RANDOM_FOREST_MODEL, 
                   ml_const.LIGHTGBM_MODEL, 
                   ml_const.LINEAR_MODEL]
    return model_types

def get_timeseries_training_variables():
    """This function returns a list of variables in the realtime sensor data, 
    which will be modeled using LSTMs to forecast future values in the timeseries.
    
    Return value(s)
    ---------------
    :return ts_variables: List of variables, which will be forecasted by LSTM
    """
    ts_variables = [io_const.WHP_COLUMN, 
                    io_const.WHT_COLUMN]
    return ts_variables

def populate_flp_choke_delta_pressure(well_name, model_df, well_test_df):
    """This function provides a wrapper, which first develops a model for 
    predicting flowline pressure. Then, using the developed model, it fills 
    in the missing values of flowline pressure in the well test data, and 
    subsequently populates the choke delta pressure column in the dataframe.
    
    Paramaters
    ----------
    :param well_name: Name of the well
    :param model_df: Pandas dataframe with the realtime sensor data
    :param well_test_df: Pandas dataframe with well test data

    Return value(s)
    ---------------
    :return well_test_df: Well test dataframe with filled missing values of 
                          flowline pressure, and populated choke delta pressure
    """
    x_cols = get_flp_feature_col_names()
    target_var = io_const.FLP_COLUMN
    model_types = get_stacked_model_algo_list()
    fold_r2 = develop_stacked_model(model_df, well_name, ml_const.NO_COMBO_CODE, 
                                    x_cols, target_var, ml_const.NUM_FOLDS, 
                                    model_types, 
                                    min_target_value=ml_const.MIN_FLP_TARGET_VALUE)
    print("FLP Model created to fill missing values. K-Fold R^2 values are: ")
    print(fold_r2)
    flp_preds, _, _ = pred_helper.generate_stacked_predictions(well_test_df, well_name, 
                                                               ml_const.NO_COMBO_CODE, 
                                                               x_cols, target_var, 
                                                               ml_const.NUM_FOLDS, 
                                                               model_types)
    
    idxs = well_test_df.index.tolist()
    i = 0
    for x in flp_preds:
        if ~pd.notnull(well_test_df.iloc[idxs[i]][io_const.FLP_COLUMN]) or \
        ~pd.notna(well_test_df.iloc[idxs[i]][io_const.FLP_COLUMN]):
            well_test_df.at[idxs[i], io_const.FLP_COLUMN] = flp_preds[i]
        i += 1
    
    well_test_df[io_const.CHOKE_DP_COLUMN] = well_test_df[io_const.WHP_COLUMN] - \
    well_test_df[io_const.FLP_COLUMN]
    well_test_df[well_test_df[io_const.CHOKE_DP_COLUMN] < 0.] = np.nan
    return well_test_df

def develop_stacked_model(model_df, well_name, combo_code, feat_cols, 
                          target_var, num_folds, model_types, min_target_value=None):
    """This function provides a wrapper for training a stacked machine learning (ML) 
    model, for the specified target variable using the provided training data.
    
    Paramaters
    ----------
    :param model_df: Pandas dataframe with the features and target values to model
    :param well_name: Name of the well
    :param combo_code: Integer code indicating combination of input variables 
                       to use in the input feature for training the ML models
    :param feat_cols: List providing names of columns to be used as input 
                      features (X)
    :param target_var: The variable, which will be predicted by the model
    :param num_folds: Number of folds in KFold cross-validation
    :param model_types: List of the model types to develop stacked model, names 
                       are defined in adnoc.wellopt.model.model_constants.

    :param min_target_value: Rows with target variable value below this will be 
                             dropped from training data. This variable should be 
                             defined in cases where well shut-in causes sensor 
                             readings affected by ambient conditions rather than 
                             physics of the system.

    Return value(s)
    ---------------
    :return fold_r2: R^2 values from each fold in KFold CV
    """
    feat_df = model_df.copy(deep=True)
    all_cols = [col_name for col_name in feat_cols]
    all_cols.append(target_var)
    for col_name in all_cols:
        feat_df = feat_df[pd.notnull(feat_df[col_name])]
        feat_df = feat_df[pd.notna(feat_df[col_name])]
    feat_df = feat_df.reset_index(drop=True)

    feat_df = feat_df[all_cols]
    scaler_prefix = get_model_prefix(ml_const.STACKED_MODEL, target_var, 
                                     combo_code)
    feat_df = preproc.fit_scale_dataframe_columns(feat_df, well_name, 
                                                  scaler_prefix, 
                                                  save_model=True)
    if min_target_value is not None:
        feat_df = feat_df[feat_df[target_var] > min_target_value]
    target_df = feat_df.copy(deep=True)[target_var] 
    feat_df = feat_df[feat_cols]

    stacked_feat = None
    for model_type in model_types:
        model_prefix = get_model_prefix(model_type, target_var, combo_code)
        fold_r2, _ = pred_ml.train_model_kfold(feat_df, target_df, 
                                               num_folds, 
                                               well_name, model_type, 
                                               io_const.MODEL_DIR, 
                                               model_prefix, 
                                               save_models=True, 
                                               calc_feat_imp=False)
        
        pred_y = predict_models_kfold(feat_df, well_name, feat_cols, 
                                      num_folds, model_prefix, 
                                      scaler_prefix=scaler_prefix, 
                                      input_pre_scaled=True)
        pred_y, _ = get_kfold_mean_std(pred_y, num_folds)
        
        if stacked_feat is None:
            stacked_feat = np.c_[pred_y]
        else:
            stacked_feat = np.c_[stacked_feat, pred_y]
    
    feat_df = pd.DataFrame(stacked_feat)
    model_prefix = get_model_prefix(ml_const.STACKED_MODEL, 
                                    target_var, combo_code)
    fold_r2, _ = pred_ml.train_model_kfold(feat_df, target_df, num_folds, 
                                           well_name, ml_const.STACKED_MODEL, 
                                           io_const.MODEL_DIR, model_prefix, 
                                           save_models=True, calc_feat_imp=False)
    
    y_stacked = predict_models_kfold(feat_df, well_name, None, 
                                     num_folds, model_prefix, 
                                     scaler_prefix=scaler_prefix, 
                                     input_pre_scaled=True)
    # ADHOC Plotting
    fig = plt.figure(figsize=(8, 8))
    plt.plot(target_df, y_stacked, "ro")
    fig.suptitle(target_var)
    # END of ADHOC Plotting
    return fold_r2

def develop_stacked_model_for_variable(well_name, feat_cols, target_var, 
                                       well_test_df, model_types):
    """This helper function provides entry point for training a stacked 
    Machine Learning model for a specific target variable.
    
    Paramaters
    ----------
    :param well_name: Name of the well
    :param feat_cols: List providing names of columns to be used as input 
                      features (X)
    :param target_var: The variable, which will be predicted by the model
    :param well_test_df: Pandas dataframe with well test data
    :param model_types: List of the model types to develop stacked model, names 
                       are defined in adnoc.wellopt.model.model_constants.

    Return value(s)
    ---------------
    :return fold_r2: R^2 values from each fold in KFold CV
    """
    xy_cols = [col_name for col_name in feat_cols]
    xy_cols.append(target_var + io_const.LAST_DATA_SUFFIX)
    fold_r2 = develop_stacked_model(well_test_df, well_name, ml_const.NO_COMBO_CODE, 
                                    xy_cols, target_var, ml_const.NUM_FOLDS, model_types)
    return fold_r2

def get_timeseries_feature_columns(target_var):
    """This function returns a list of feature columns derived from the realtime 
    sensor data, which will be used for generating input feature for LSTM models.
    
    Return value(s)
    ---------------
    :return feat_cols: List of feature columns for generating LSTM model inputs
    """
    feat_dict = {}
    feat_dict[io_const.WHP_COLUMN] = [io_const.CHOKE_COLUMN, 
             io_const.GL_RATE_COLUMN, 
             io_const.WHP_COLUMN]
    feat_dict[io_const.WHT_COLUMN] = [io_const.CHOKE_COLUMN, 
             io_const.GL_RATE_COLUMN, 
             io_const.WHT_COLUMN]
    return feat_dict[target_var]

def get_rnn_hyper_params(params_file_path):
    """This function reads the hyper-parameters for training RNN (LSTM) from 
    the parameter file, from the provided file path.
    
    Parameters
    ----------
    :param params_file_path: Path to the file with RNN hyper-parameters
    
    Return value(s)
    ---------------
    :return num_hidden: List containing humber of neurons in LSTM layers
    :return batch_size: Batch size for training LSTM
    :return num_epochs: Number of epochs for training
    :return patience: Number of epochs to wait before training in early-stopping
    :return lookback: Number of time-steps to lookback in LSTM model
    :return lookahead: Number of time-steps to forecast in multi-step LSTM model
    :return dropout: Value for dropout in LSTM layer connections
    """
    lookback = None
    with open(params_file_path, "r") as fp:
        line = fp.readline()
        while line:
            values = line.split(":")
            values[0] = values[0].strip()
            values[1] = values[1].strip()
            if values[0] == io_const.RNN_NUM_HIDDEN_PARAM:
                num_hidden = preproc.str_to_int32(values[1].split(","))
            elif values[0] == io_const.RNN_BATCH_SIZE_PARAM:
                batch_size = int(values[1])
            elif values[0] == io_const.RNN_NUM_EPOCHS_PARAM:
                num_epochs = int(values[1])
            elif values[0] == io_const.RNN_PATIENCE_PARAM:
                patience = int(values[1])
            elif values[0] == io_const.RNN_LOOKBACK_PARAM:
                lookback = int(values[1])
            elif values[0] == io_const.RNN_LOOKAHEAD_PARAM:
                lookahead = int(values[1])
            elif values[0] == io_const.RNN_DROPOUT_PARAM:
                dropout = float(values[1])
            line = fp.readline()

    return num_hidden, batch_size, num_epochs, patience, lookback, lookahead, dropout

def train_forecast_model(well_name, realtime_df, target_var, data_pitch, 
                         model_type):
    """This function trains target forecasting models for the provided 
    realtime data. Internally, a Recurrent Neural Network (RNN) with 
    Long Short-Tem Memory (LSTM) or Stacked Model is trained using the 
    timeseries data extracted from the realtime well data.
    NOTE: These models were not used in the final forecasting models. Instead, 
    ARIMAX models generated in a separate module were used for forecasting.
    
    Parameters
    ----------
    :param well_name: Name of the well
    :param realtime_df: A Pandas dataframe populated with realtime well data
    :param target_var: The target variable that model will forecast
    :param data_pitch: Data pitch in number of hours to consider it continuous
    :param model_type: Type of timeseries modeling algorithm to use
    """
    # Path to file containing hyper-parameters
    params_file_path = os.path.join(io_const.PARAMS_DIR, 
                                    io_const.TIMESERIES_PARAMS_FILE_NAME)
    # Read lookback window from the file containing hyper-parameters
    _, _, _, _, lookback, lookahead, _ = get_rnn_hyper_params(params_file_path)
    
    features = None
    targets = None
    if model_type == ml_const.RECURRENT_NEURAL_NET_MODEL:
        features, targets = preproc.prepare_timeseries_input_for_rnn(well_name, 
                                                                     realtime_df, 
                                                                     lookback, 
                                                                     lookahead, 
                                                                     target_var, 
                                                                     data_pitch)
    elif model_type == ml_const.STACKED_MODEL:
        features, targets = preproc.prepare_timeseries_input_for_stacking(well_name, 
                                                                          realtime_df, 
                                                                          lookback, 
                                                                          target_var, 
                                                                          data_pitch)

    # Split data into training and blind test sets
    train_X, test_X, train_y, test_y = \
    preproc.split_timeseries_data(features, targets, 
                                  ml_const.TS_BLIND_TEST_FRACTION)
    
    # Train the machine learning model with KFold cross-validations
    model_prefix = get_model_prefix(model_type, 
                                    target_var, 
                                    ml_const.TS_MODEL_COMBO_CODE)
    
    fold_r2, _ = pred_ml.train_model_kfold(train_X, train_y, 
                                           ml_const.NUM_FOLDS, 
                                           well_name, 
                                           model_type,
                                           io_const.MODEL_DIR, 
                                           model_prefix, 
                                           save_models=True, 
                                           calc_feat_imp=False, 
                                           params_file_path=params_file_path)
    print("K-Fold R^2 :" + str(fold_r2))

    test_y_pred = pred_ml.predict_model_kfold_scaled_input(test_X, 
                                                           ml_const.NUM_FOLDS, 
                                                           well_name, 
                                                           io_const.MODEL_DIR, 
                                                           model_prefix)

    mean_y_pred, _ = get_kfold_mean_std(test_y_pred, ml_const.NUM_FOLDS)

    mean_y_pred = mean_y_pred.T
    # ADHOC Plotting
    fig = plt.figure()
    plt.scatter(test_y, mean_y_pred, c="black", alpha=0.5)
    fig.suptitle(model_prefix)
    # END of ADHOC Plotting
    test_r2 = r2_score(test_y, mean_y_pred)
    fig.savefig("./" + model_prefix + ".png", dpi=300)
    plt.close()
    print("Blind-test R^2 :" + str(test_r2))

def diagnose_abnormal_conditions(forecast_df):
    """This function uses the dataframe containing short-term forecasts to 
    diagnose an abnormal decline in oil production rate, or abnormal increase 
    in water cut. If an abnormality os detected, a message is shown in the 
    console.
    
    Paramaters
    ----------
    :param forecast_df: Pandas dataframe with short-term forecasts
    """
    wct = forecast_df[io_const.WCT_COLUMN + \
                      io_const.PRED_MEAN_SUFFIX].values.tolist()
    max_wct = np.max(wct)
    oil_rate = forecast_df[io_const.OIL_RATE_COLUMN + \
                           io_const.PRED_MEAN_SUFFIX].values.tolist()
    oil_rate_decline = oil_rate[0] - oil_rate[-1]
    pct_oil_rate_decline = 0.
    if oil_rate_decline > 0:
        pct_oil_rate_decline = oil_rate_decline * 100. / oil_rate[0]
    if max_wct > ml_const.MAX_WATER_CUT:
        print("Max. WCT forecasted to exceed %d %% in the next %d days " 
              % (ml_const.MAX_WATER_CUT, ml_const.MONTHLY_RUNNING_WINDOW))
        print("under the current operating conditions.")
    elif pct_oil_rate_decline > ml_const.REL_OIL_RATE_DECLINE:
        print("Oil rate forcasted to decline more than %d %% in the next %d days" 
              % (ml_const.REL_OIL_RATE_DECLINE, ml_const.MONTHLY_RUNNING_WINDOW))
        print("under the current operating conditions.")
    else:
        print("No abnormal pattern observed in Oil or Water production forecast.")
