# -*- coding: utf-8 -*-
"""
Created on Monday June 29 08:437:11 2020

This Python module contains functions, which create predictive models using 
implementations provided in Scikit-learn and Keras libraries.

@author: Prabhaker Reddy Vanam
"""

import os

import numpy as np
import pandas as pd

from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor as RF
from sklearn.linear_model import LinearRegression as LR
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import KFold
from sklearn.metrics import r2_score
from sklearn.base import clone
from joblib import dump
from joblib import load
from keras.models import load_model

from aon.dlis.io import io_constants as io_const
from aon.dlis.model import model_constants as ml_const
from aon.dlis.model import model_helper as helper
from aon.dlis.model import timeseries_models as time_ml


def train_lightgbm(X_train, y_train, X_valid, y_valid):
    """This function trains a LightGBM model using the provided training and 
    validation data.
    
    Parameters
    ----------
    :param X_train: Farture matrix from training data
    :param y_train: Target variable from training data
    :param X_valid: Farture matrix from validation data
    :param y_valid: Target variable from validation data
    
    Return value(s)
    ---------------
    :return lgbm_model: Trained LightGBM model
    """
    # Create training dataset
    train_data = lgbm.Dataset(X_train, y_train)
    valid_data = lgbm.Dataset(X_valid, y_valid, reference=train_data)
    
    # Parameters for training LightGBM
    params = {"boosting_type": "gbdt", 
              "objective": "regression", 
              "metric": {"l2", "l1"}, 
              "num_leaves": 50, 
              "learning_rate": 0.005, 
              "feature_fraction": 0.9, 
              "bagging_fraction": 0.8, 
              "bagging_freq": 5,
              "min_data": 1, 
              "min_data_in_bin": 1, 
              "verbose": -1}
    lgbm_model = lgbm.train(params, train_data, 
                            num_boost_round=5000, 
                            valid_sets=valid_data, 
                            early_stopping_rounds=100, 
                            verbose_eval=False)
    return lgbm_model

def train_model_kfold(X, y, num_folds, well_name, model_type,  
                      model_dir, model_name_prefix, save_models=False, 
                      calc_feat_imp=False, params_file_path=None):
    """This function trains machine learning models with KFold cross validation. 
    The model for each fold is saved to a file, if indicated by the provided 
    boolean flag.
    
    Parameters
    ----------
    :param X: Input feature matrix
    :param y: Target variable values
    :param num_folds: Number of folds in KFold cross-validation
    :param well_name: Name of the well
    :param model_type: Type of the model to develop (e.g. nn, svm etc.), names 
                       are defined in adnoc.wellopt.model.model_constants.
    :param model_dir: Path to the diretory for saving models
    :param model_name_prefix: Prefix to the names of files to save models
    :param save_models: Flag indicating whether or not save models to files
    :param calc_feat_imp: Flag indicating whether to calculate feature 
                          importance
    :param params_file_path: File containing hyper-parameter values, used in 
                             case of LSTM RNNs
    
    Return value(s)
    ---------------
    :return kfold_r2: R^2 values from each fold in KFold CV
    :return feat_imp_df_list: Pandas dataframe with feature importance scores 
                              and rankings
    """
    kfold = KFold(n_splits=num_folds, shuffle=True, 
                  random_state=ml_const.RANDOM_SEED)
    kfold_r2 = []
    feat_imp_df_list = []
    k = 1
    is_dataframe = isinstance(X, pd.DataFrame)
    for train_index, valid_index in kfold.split(X):
        X_train = None
        y_train = None
        X_valid = None
        y_valid = None
        if is_dataframe:
            X_train, X_valid = X.iloc[train_index], X.iloc[valid_index]
            y_train, y_valid = y.iloc[train_index], y.iloc[valid_index]
        else:
            X_train, X_valid = X[train_index], X[valid_index]
            y_train, y_valid = y[train_index], y[valid_index]
        model = None
        if model_type == ml_const.SVR_MODEL:
            # Build the Support Vector Regression model
            model = SVR()
        elif model_type == ml_const.NEURAL_NET_MODEL:
            # Build a Neural Network (Multilayer Perceptron) model
            num_hidden = 5 * X.shape[1]
            model = MLPRegressor(hidden_layer_sizes=(num_hidden, 
                                                     num_hidden, 
                                                     num_hidden, ), 
                                 activation="relu", 
                                 learning_rate_init=0.0001, 
                                 max_iter=10000, 
                                 random_state=ml_const.RANDOM_SEED, 
                                 early_stopping=True)
        elif model_type == ml_const.RANDOM_FOREST_MODEL:
            # Build a Random Forest Regressor model
            model = RF(n_estimators=500, random_state=ml_const.RANDOM_SEED)
        elif model_type == ml_const.LIGHTGBM_MODEL:
            # Build a LightGBM model
            model = train_lightgbm(X_train, y_train, X_valid, y_valid)
        elif model_type == ml_const.LINEAR_MODEL or \
        model_type == ml_const.STACKED_MODEL:
            # Build a Linear Regression model
            model = LR()
        elif model_type == ml_const.RECURRENT_NEURAL_NET_MODEL:
            # Build the Long Short-Term Memory (LSTM) RNN model
            model = time_ml.build_lstm_model(X_train, y_train, 
                                             params_file_path, 
                                             X_valid=X_valid, 
                                             y_valid=y_valid)
        
        # FIt the model, if it's not an RNN
        if model_type != ml_const.RECURRENT_NEURAL_NET_MODEL and \
        model_type != ml_const.LIGHTGBM_MODEL:
            model.fit(X_train, y_train)

        # If model is RandomForestRegressor, get feature importance 
        # ranking, if instructed to do so.
        if model_type == ml_const.RANDOM_FOREST_MODEL and \
        calc_feat_imp:
            feat_imp_df = get_feature_importances(model, X_train, y_train)
            feat_imp_df_list.append(feat_imp_df)

        y_pred = None

        if model_type == ml_const.LIGHTGBM_MODEL:
            # If it's a LightGBM model, use the best iteration for predictions
            y_pred = model.predict(X_valid, num_iteration=model.best_iteration)
        else:
            y_pred = model.predict(X_valid)

        # Compute R^2 values using validation data and predicted values
        r2 = r2_score(y_valid, y_pred)
        kfold_r2.append(r2)
        # Save developed model if indicated
        if save_models:
            if model_type == ml_const.RECURRENT_NEURAL_NET_MODEL:
                model_name = helper.get_keras_model_name(well_name, 
                                                         model_name_prefix, 
                                                         model_fold=k)
                model_path = os.path.join(io_const.MODEL_DIR, model_name)
                print(model_path)
                model.save(model_path)
            elif model_type == ml_const.LIGHTGBM_MODEL:
                model_name = helper.get_lightgbm_model_name(well_name, 
                                                            model_name_prefix, 
                                                            model_fold=k)
                model_path = os.path.join(io_const.MODEL_DIR, model_name)
                model.save_model(model_path, num_iteration=model.best_iteration)
            else:
                model_name = helper.get_model_name(well_name, 
                                                   model_name_prefix, 
                                                   model_fold=k)
                model_path = os.path.join(io_const.MODEL_DIR, model_name)
                dump(model, model_path)
        k += 1
    return kfold_r2, feat_imp_df_list

def predict_model_kfold_scaled_input(X, num_folds, well_name, model_dir, 
                                   model_name_prefix):
    """This function uses saved pre-trained machine learning models with 
    KFold cross-validation to compute predicted values for the provided 
    input feature matrix.
    
    Parameters
    ----------
    :param X: Input feature matrix
    :param num_folds: Number of folds in KFold cross-validation
    :param well_name: Name of the well
    :param model_dir: Path to the diretory for saving models
    :param model_name_prefix: Prefix to the names of saved model files
    
    Return value(s)
    ---------------
    :return pred_kfold: np.ndarray with predicted values from each fold in 
                        KFold cross-validation arranged in columns
    """
    pred_target = []
    for k in range(num_folds):
        model = None
        is_lgbm = False
        if ml_const.RECURRENT_NEURAL_NET_MODEL in model_name_prefix:
            model_name = helper.get_keras_model_name(well_name, 
                                                     model_name_prefix, 
                                                     model_fold=(k + 1))
            model_path = os.path.join(io_const.MODEL_DIR, model_name)
            model = load_model(model_path)
        elif ml_const.LIGHTGBM_MODEL in model_name_prefix:
            is_lgbm = True
            model_name = helper.get_lightgbm_model_name(well_name, 
                                                        model_name_prefix, 
                                                        model_fold=(k + 1))
            model_path = os.path.join(io_const.MODEL_DIR, model_name)
            model = lgbm.Booster(model_file=model_path)
        else:
            model_name = helper.get_model_name(well_name, model_name_prefix, 
                                               model_fold=(k + 1))
            model_path = os.path.join(io_const.MODEL_DIR, model_name)
            model = load(model_path)
        pred = None
        if is_lgbm:
            pred = model.predict(X, num_iteration=model.best_iteration)
        else:
            pred = model.predict(X)
        pred_target.append(pred)
    pred_kfold = np.array(pred_target).T
    return pred_kfold

def get_feature_importances(rf_model, X_train, y_train):
    """This function computes drop-column feature importances using 
    RandomForestRegressor model, along with the training X and y data, and 
    returns a data frame with columns with Feature and Importance sorted by 
    feature importance.
    
    Parameters
    ----------
    :param rf_model: A scikit-learn RandomForestRegressor model
    :param X_train: Farture matrix from training data
    :param y_train: Target variable from training data
    
    Return value(s)
    ---------------
    :return feat_imp_col: Pandas dataframe with drop-column feature importance
    """
    rf_ = clone(rf_model)
    rf_.random_state = ml_const.RANDOM_SEED
    rf_.oob_score = True
    rf_.fit(X_train, y_train)
    baseline = rf_.oob_score_
    imp = []
    col_names = X_train.columns
    if len(col_names) > 1:
        for col in X_train.columns:
            rf_ = clone(rf_model)
            rf_.random_state = ml_const.RANDOM_SEED
            rf_.oob_score = True
            rf_.fit(X_train.drop(col, axis=1), y_train)
            drop_in_score = baseline - rf_.oob_score_
            imp.append(drop_in_score)
    else:
        imp.append(1.0) # For a single input feature, importance is always 1
    feat_imp = np.array(imp)
    feat_imp_df = pd.DataFrame(data={"Feature":X_train.columns, 
                                     "Importance":feat_imp})
    feat_imp_df = feat_imp_df.sort_values("Importance", ascending=False)
    feat_imp_df.reset_index(drop=True, inplace=True)
    feat_imp_df["Rank"] = feat_imp_df.index.values
    feat_imp_df = feat_imp_df.set_index("Feature")
    return feat_imp_df
