# -*- coding: utf-8 -*-
"""
Created on Wed Jun 17 12:53:04 2020

This Python script provides an entry-point for building machine learning
prediction models for BAKER Cement Bond Logs. The methods extracts dlis files,
develop machine learning models by considering several combinations of the
ATC channels, and develop predictive models for
Cement Bond Quality (CQF). This script can be executed from Spyder IDE, or
from a Windows command prompt as > python entry_dlis_baker.py

Note:
    Training and predictions should run separately. Please don't provide \
    both training and prediction flags as True at the same time.

Usage:
    Following commands assume that dlis/data is provided for BAKER,
    and we are generating predictions for the Cement quality.

    Execute this file from command-line using following commands:

        * Training

        python entry_dlis_baker.py -dlis XXX.dlis -input_csv Well_Locations.csv \
        -tr True -pr False -df False -dft False

@author: Prabhaker Reddy Vanam
"""
import os
import sys
import pandas as pd
import numpy as np
import dlisio
from aon.dlis.io import data_reader as reader
from aon.dlis.model import model_constants as ml_const
from aon.dlis.io import io_constants as io_const
from aon.dlis.io import plot_cement_bond_log as plot_cbl

import logging

np.random.seed(ml_const.RANDOM_SEED)

# Set encodings for dlisio
dlisio.set_encodings(['latin1'])

training_data_dir = ""

logical_file_info_dict = {}


def main(dlis_file='xyz.dlis'):

    print(dlis_file)

    training_data_dir = os.path.join(io_const.BASE_DATA_DIR, io_const.TRAINING_DATA_DIR)

    print(training_data_dir)

    extract_dlis(dlis_file)


def extract_dlis(source_dlis_file):

    duplicate_channel_list = []

    source_dlis_file = source_dlis_file.replace('/', '\\\\')

    dlis_summary = pd.DataFrame(columns=io_const.SUMMARY_DF_COLUMN_LIST)

    with dlisio.load(source_dlis_file) as files:

        print(files.describe())

        is_casing_plotted = False

        for lfile in files:
            # print(lfile.describe())

            problematic_list = lfile.problematic

            # check for duplicate channels to skip by the code
            if len(problematic_list) > 0:

                print("Its Problematic files : {}".format(problematic_list))

                prob_channel_list = [x[0] for x in problematic_list]

                for dup_chn in prob_channel_list:

                    prob_channel_name = dup_chn.name
                    # print(prob_channel_name)

                    if prob_channel_name not in duplicate_channel_list:

                        duplicate_channel_list.append(prob_channel_name)

            # Validate columns
            lfile_channels: list = reader.get_all_channel_names_of_logical_file(lfile, duplicate_channel_list)

            # 1. Validate required channels
            channel_missing = False

            for (ch, ch_i) in zip(io_const.SBT_CHANNEL_SET, io_const.SBT_CHANNEL_SET_I):

                print((lfile_channels.count(ch), lfile_channels.count(ch_i)))

                if ch not in lfile_channels and ch_i not in lfile_channels:
                    channel_missing = True

                if channel_missing:
                    break

            if not channel_missing:

                print("All required channels exist in the logical file  {} ".format(lfile.describe()))

                parameter_table = reader.summarize(lfile.parameters, name='Name', long_name='Long name',
                                                   values='Value(s)', zones='Zone(s)')

                zone_table = reader.summarize(lfile.zones, name='Name', minimum='Minimum', maximum='Maximum')

                # parameter_table['Value(s)'] = parameter_table['Value(s)'].apply(lambda x: str(x).strip('[]'))
                parameter_table['Zone(s)'] = parameter_table['Zone(s)'].apply(lambda x: str(x).strip('[]'))

                # Hide parameters containing names; see the privacy note in the Introduction. Comment out these lines
                # to show them.
                exclude_mask = ~parameter_table['Name'].isin(['RR1', 'WITN', 'ENGI'])

                parameter_table = parameter_table[exclude_mask]

                well_name = 'NOT EXISTS'
                exists = 'WN' in parameter_table["Name"].values
                if exists:
                    well_name = parameter_table[parameter_table["Name"] == "WN"]['Value(s)'].values[0]

                company_name = 'NOT EXISTS'
                exists = 'CN' in parameter_table["Name"].values
                if exists:
                    company_name = parameter_table[parameter_table["Name"] == "CN"]['Value(s)'].values[0]

                producer_name = 'NOT EXISTS'
                exists = 'LCNM' in parameter_table["Name"].values
                if exists:
                    producer_name = parameter_table[parameter_table["Name"] == "LCNM"]['Value(s)'].values[0]

                set_name = 'NOT EXISTS'
                exists = 'SET' in parameter_table["Name"].values
                if exists:
                    set_name = parameter_table[parameter_table["Name"] == "SET"]['Value(s)'].values[0]

                field_name = 'NOT EXISTS'
                exists = 'FN' in parameter_table["Name"].values
                if exists:
                    field_name = parameter_table[parameter_table["Name"] == "FN"]['Value(s)'].values[0]

                # extract Casing data from header (Params and Zones)
                cs_table = parameter_table[parameter_table['Name'].str.startswith("CS")]
                cs_table['Value(s)'] = cs_table['Value(s)'].apply(lambda x: str(x).strip('[]'))
                cs_table['Zone(s)'] = cs_table['Zone(s)'].apply(lambda x: str(x).strip('Zone()'))

                cs_table = cs_table.merge(zone_table, left_on='Zone(s)', right_on='Name')

                well_name = str(well_name).strip('[]')
                company_name = str(company_name).strip('[]')
                set_name = str(set_name).strip('[]')
                producer_name = str(producer_name).strip('[]')

                if not is_casing_plotted:
                    max_depth, min_depth, casing_df = reader.get_casing_plot_data(cs_table)

                    casing_plot_path = "{}\\{}_{}_{}".format(io_const.OUTPUT_DATA_DIR, well_name, company_name,
                                                             io_const.CASING_PLOT_FILE_SUFFIX)
                    # casing_df = reader.prepare_casing_plot_data(casing18_min, casing18_max, casing13_min,
                    # casing13_max, casing9_min, casing9_max, casing7_min, casing7_max)
                    plot_cbl.plot_well_casing(casing_df.values, min_depth, max_depth, casing_plot_path)

                    is_casing_plotted = True

                channel_table = reader.summarize(lfile.channels, name='Name', long_name='Long name', units='Units',
                                                 dimension='Dimension', frame='Frame')
                channel_table.sort_values('Name')

                tool_table = reader.summarize(lfile.tools, name='Name', generic_name='Generic name',
                                              trademark_name='Trademark name', description='Description')
                tool_table.sort_values('Name')
                print(tool_table)

                print(list(io_const.HEADER_PARAM_LIST))
                header_info = parameter_table.loc[parameter_table['Name'].isin(list(io_const.HEADER_PARAM_LIST))].\
                    drop(columns='Zone(s)', axis=1)
                print(header_info)

                problematic_list = lfile.problematic

                if len(problematic_list) > 0:

                    print("Its Problematic files : {}".format(problematic_list))
                    prob_channel_list = [x[0] for x in problematic_list]

                    for dup_chn in prob_channel_list:
                        prob_channel_name = dup_chn.name
                        # print(prob_channel_name)

                        if prob_channel_name not in duplicate_channel_list:
                            duplicate_channel_list.append(prob_channel_name)

                origin, *origin_tail = lfile.origins

                if len(origin_tail):
                    logging.warning('Logical file contains multiple origins')

                for origin in lfile.origins:

                    origin.describe()

                    file_number = origin.file_nr
                    producer_name = origin.producer_name
                    well_name = origin.well_name
                    #copy_no = origin.copynumber
                    #org_no = origin.origin
                    field_name = origin.field_name
                    #namespace_name = origin.namespace_name

                for frm in lfile.frames:

                    index_channel = next(ch for ch in frm.channels if ch.name == frm.index)
                    print(f'Frame {frm.name}:')
                    print(frm.index)

                    try:
                        frm_curves = frm.curves(strict=False)
                        curve_index = reader.index_of(frm)

                        print(frm_curves.shape)
                    except Exception as e:
                        logging.error("ERROR in reading curve data.... : {}".format(e))

                    try:
                        selected_curves_names = reader.get_channel_names(frm, duplicate_channel_list)
                        print(selected_curves_names)

                        selected_curves_data = frm_curves[selected_curves_names]

                        # print("*********************************************************")
                        df_curves = pd.DataFrame(selected_curves_data, index=frm_curves[frm.index])
                        # print(df_curves.head())

                        total_records = df_curves.shape

                        cemo_wave_channel_names: list = reader.get_wave_channel_name(frm, duplicate_channel_list)
                        # print(cemo_wave_channel_names)

                        if len(cemo_wave_channel_names) > 1:

                            for channel_name in cemo_wave_channel_names:

                                print("Processing : {}".format(channel_name))

                                cs_wave_data = frm_curves[channel_name]

                                df_wave_data = pd.DataFrame(cs_wave_data, index=frm_curves[frm.index])
                                df_wave_data[io_const.TDEP_COLUMN] = df_wave_data.index
                                # df_wave_data.reset_index(drop=True)
                                df_wave_data.head()
                                # save wave data
                                cemo_wave_file_name = "{}\\{}_{}_{}_{}_{}_{}_{}_data.csv".format(io_const.OUTPUT_DATA_DIR,
                                                                                       field_name, well_name,
                                                                                       producer_name, set_name,
                                                                                       frm.name, total_records,
                                                                                       channel_name.lower())
                                print("Saving wave data to : {} ".format(cemo_wave_file_name))

                                with open(cemo_wave_file_name, "w") as f:
                                    df_wave_data.to_csv(f)

                                print("{} Multi dimensional DataFrame Saved to CSV : {}".format(channel_name,
                                                                                                cemo_wave_file_name))

                        else:

                            logging.warning("No Multi dimensional columns found in the frame/logical file")

                        df_full_data = df_curves.copy()

                        print("*********************************************************")
                        channel_file_name = "{}\\{}_{}_{}_{}_{}_{}{}".format(io_const.OUTPUT_DATA_DIR, field_name, well_name,
                                                                       producer_name, set_name, frm.name,
                                                                       total_records, io_const.CHANNEL_DATA_CSV_SUFFIX)
                        with open(channel_file_name, "w") as f:
                            df_full_data.to_csv(f)

                        print("DataFrame Saved to CSV : {}" + channel_file_name)

                        param_file_name = "{}\\{}_{}_{}_{}_{}_{}{}".format(io_const.OUTPUT_DATA_DIR, field_name, well_name,
                                                                             producer_name, set_name, frm.name,
                                                                             total_records, io_const.HEADER_CSV_SUFFIX)
                        with open(param_file_name, "w") as f:
                            parameter_table.to_csv(f)

                        zone_file_name = "{}\\{}_{}_{}_{}_{}_{}{}".format(io_const.OUTPUT_DATA_DIR, field_name, well_name,
                                                                            producer_name, set_name, frm.name,
                                                                            total_records, io_const.ZONE_DATA_CSV_SUFFIX)
                        with open(zone_file_name, "w") as f:
                            zone_table.to_csv(f)

                        depth_range = (df_curves.index[0], df_curves.index[-1])
                        logical_file_info_dict = {'Field Name': field_name, 'Well Name': well_name,
                                                  'Company': company_name, 'Producer Name': producer_name,
                                                  'Set Name': set_name, 'Frame Name': frm.name,
                                                  'Total Rows and Columns': total_records, 'Depth Range': depth_range,
                                                  'Column Names': list(df_curves.columns) + list(
                                                      cemo_wave_channel_names)}
                        print(logical_file_info_dict)

                        dlis_summary = dlis_summary.append(logical_file_info_dict, ignore_index=True)

                        summary_file_name = f"{io_const.OUTPUT_DATA_DIR }\\{field_name}_{well_name}_{producer_name}" \
                                            f"{io_const.SUMMARY_DATA_CSV_SUFFIX}"

                    except Exception as e:
                        # print("*********************************************************")
                        logging.error("Got Error with dlisio library.... : {}".format(e))

                    # Convert the index to metres if needed
                    if curve_index.units == '0.1 in':
                        frm_curves[frm.index] *= 0.00254

                    print("----------------1--------------------")
                    print('Shape of depth index curve array:', frm_curves[frm.index].shape)

                    channel_names = lfile_channels #reader.get_all_channel_names(frm, duplicate_channel_list)
                    print("channel_names", channel_names)
                    try:
                        cemo_channel_name = 'CEMO'
                        wave_channel_name = 'WAVE'

                        if channel_names.count('CEMO.I') > 0:
                            cemo_channel_name = 'CEMO.I'
                        print("---------------2-----------------")
                        print('Shape of CEMO curve array:       {}'.format(frm_curves[cemo_channel_name].shape))

                        if channel_names.count('WAVE.I') > 0:
                            wave_channel_name = 'WAVE.I'

                        print('Shape of WAVE curve array:        {}'.format(frm_curves[wave_channel_name].shape))
                        print("---------------3-----------------")
                        # Plot wave data with single column
                        cemo_plot_file_name = "{}\\{}_{}_{}_{}_{}".format(io_const.OUTPUT_DATA_DIR, field_name,
                                                                          well_name,
                                                                          producer_name, file_number,
                                                                          io_const.CEMO_PLOT_FILE_SUFFIX)
                        plot_cbl.plot_single_cem_form(frm, frm_curves, cemo_channel_name, cemo_plot_file_name)
                        print("---------------4-----------------")
                        # Plot wave data with single column
                        wave_plot_file_name = "{}\\{}_{}_{}_{}_{}".format(io_const.OUTPUT_DATA_DIR, field_name,
                                                                          well_name,
                                                                          producer_name, file_number,
                                                                          io_const.WAVE_PLOT_FILE_SUFFIX)
                        plot_cbl.plot_single_wave_form(frm, frm_curves, wave_channel_name, wave_plot_file_name)
                        print("---------------5-----------------")
                        # Plot ATC data with single column
                        atc_plot_file_name = "{}\\{}_{}_{}_{}_{}".format(io_const.OUTPUT_DATA_DIR, field_name,
                                                                         well_name,
                                                                         producer_name, file_number,
                                                                         io_const.ATC_PLOT_FILE_SUFFIX)
                        atc_channel_names = []
                        try:
                            print("Validate ATC channels...")
                            for (atc_ch, atc_i_ch) in zip(io_const.ATC_COLUMN_LIST, io_const.ATC_I_COLUMN_LIST):
                                print(atc_ch, atc_i_ch)
                                if atc_ch in channel_names:
                                    atc_channel_names = io_const.ATC_COLUMN_LIST
                                    break
                                elif atc_i_ch in channel_names:
                                    atc_channel_names = io_const.ATC_I_COLUMN_LIST
                                    break

                            print(atc_channel_names)

                            if len(atc_channel_names) > 0:
                                print("Plot ATC channels")
                                plot_cbl.plot_single_atc(frm, frm_curves, atc_channel_names, atc_plot_file_name)
                                # plot_single_atc_form(frameB0, curvesB0, atc_channel_names, atc_file_name)
                            else:
                                logging.warning("ATC channels not found in the logical file.")

                        except Exception as e:
                            logging.error(f"ERROR while plotting the ATC data....{e}")

                    except Exception as e:
                        logging.error(f"ERROR while plotting the WAVE data....{e}")
            else:
                logging.warning("Required Channels are missing.")

            with open(summary_file_name , "w") as f:
                dlis_summary.to_csv(f)


print("Done!")

if __name__ == "__main__":
    main(str(sys.argv[1]))
